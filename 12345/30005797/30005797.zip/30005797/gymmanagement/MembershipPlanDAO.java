package gymmanagement;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MembershipPlanDAO {

    // Add a new membership plan
    public void addMembershipPlan(MembershipPlan plan) throws SQLException {
        String query = "INSERT INTO membership_plan (name, duration_months, price_per_month) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, plan.getName());
            stmt.setString(2, plan.getDescription());
            stmt.setDouble(3, plan.getPricePerMonth());
            stmt.executeUpdate();
        }
    }

    // Retrieve a membership plan by ID
    public MembershipPlan getMembershipPlan(int planId) throws SQLException {
        String query = "SELECT * FROM membership_plan WHERE plan_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, planId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new MembershipPlan(
                            rs.getInt("plan_id"),
                            rs.getString("name"),
                            rs.getInt("duration_months"),
                            rs.getDouble("price_per_month")
                    );
                }
            }
        }
        return null;
    }

    // Update an existing membership plan
    public void updateMembershipPlan(MembershipPlan plan) throws SQLException {
        String query = "UPDATE membership_plan SET name = ?, duration_months = ?, price_per_month = ? WHERE plan_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, plan.getName());
            stmt.setString(2, plan.getDescription());
            stmt.setDouble(3, plan.getPricePerMonth());
            stmt.setInt(4, plan.getPlanId());
            stmt.executeUpdate();
        }
    }

    // Delete a membership plan by ID
    public void deleteMembershipPlan(int planId) throws SQLException {
        String query = "DELETE FROM membership_plan WHERE plan_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, planId);
            stmt.executeUpdate();
        }
    }

    // Retrieve all membership plans
    public List<MembershipPlan> getAllMembershipPlans() throws SQLException {
        List<MembershipPlan> plans = new ArrayList<>();
        String query = "SELECT * FROM membership_plan";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                plans.add(new MembershipPlan(
                        rs.getInt("plan_id"),
                        rs.getString("name"),
                        rs.getInt("duration_months"),
                        rs.getDouble("price_per_month")
                ));
            }
        }
        return plans;
    }
}
