package gymmanagement;

public class Trainer {
    private int trainerId;
    private String name;
    private String email;
    private String phoneNumber;
    private String speciality;

    public Trainer(String name, String specialty, String email) {}

    public Trainer(int trainerId, String name, String email, String phoneNumber, String speciality) {
        this.trainerId = trainerId;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.speciality = speciality;
    }

    public Trainer(int id, String name, String specialty, String email) {
    }

    public int getTrainerId() {
        return trainerId;
    }

    public void setTrainerId(int trainerId) {
        this.trainerId = trainerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }
}
