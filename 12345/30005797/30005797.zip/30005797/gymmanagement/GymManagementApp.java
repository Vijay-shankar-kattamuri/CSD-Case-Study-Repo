package gymmanagement;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GymManagementApp {

    private static Scanner scanner = new Scanner(System.in);
    private static MemberDAO memberDAO = new MemberDAO();
    private static TrainerDAO trainerDAO = new TrainerDAO();
    private static MembershipPlanDAO membershipPlanDAO = new MembershipPlanDAO();
    private static int Id;

    public static void main(String[] args) {
        while (true) {
            System.out.println("Gym Management System");
            System.out.println("1. Member Management");
            System.out.println("2. Trainer Management");
            System.out.println("3. Membership Plan Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageMembers();
                    break;
                case 2:
                    manageTrainers();
                    break;
                case 3:
                    manageMembershipPlans();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageMembers() {
        while (true) {
            System.out.println("Member Management");
            System.out.println("1. Add Member");
            System.out.println("2. View Member");
            System.out.println("3. Update Member");
            System.out.println("4. Delete Member");
            System.out.println("5. List All Members");
            System.out.println("6. Back");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addMember();
                    break;
                case 2:
                    viewMember();
                    break;
                case 3:
                    updateMember();
                    break;
                case 4:
                    deleteMember();
                    break;
                case 5:
                    listAllMembers();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageTrainers() {
        while (true) {
            System.out.println("Trainer Management");
            System.out.println("1. Add Trainer");
            System.out.println("2. View Trainer");
            System.out.println("3. Update Trainer");
            System.out.println("4. Delete Trainer");
            System.out.println("5. List All Trainers");
            System.out.println("6. Back");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addTrainer();
                    break;
                case 2:
                    viewTrainer();
                    break;
                case 3:
                    updateTrainer();
                    break;
                case 4:
                    deleteTrainer();
                    break;
                case 5:
                    listAllTrainers();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageMembershipPlans() {
        while (true) {
            System.out.println("Membership Plan Management");
            System.out.println("1. Create Plan");
            System.out.println("2. View Plan");
            System.out.println("3. Update Plan");
            System.out.println("4. Delete Plan");
            System.out.println("5. List All Plans");
            System.out.println("6. Back");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createPlan();
                    break;
                case 2:
                    viewPlan();
                    break;
                case 3:
                    updatePlan();
                    break;
                case 4:
                    deletePlan();
                    break;
                case 5:
                    listAllPlans();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addMember() {
        System.out.print("Enter member name: ");
        String name = scanner.nextLine();
        System.out.print("Enter member email: ");
        String email = scanner.nextLine();
        Member member = new Member(name, email);
        try {
            memberDAO.addMember(member);
            System.out.println("Member added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error adding member.");
        }
    }

    private static void viewMember() {
        System.out.print("Enter member ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        try {
            Member member = memberDAO.getMember(id);
            if (member != null) {
                System.out.println("Member Details: " + member);
            } else {
                System.out.println("Member not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error retrieving member.");
        }
    }

    private static void updateMember() {
        System.out.print("Enter member ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new member name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new member email: ");
        String email = scanner.nextLine();
        Member member = new Member(id, name, email);
        try {
            memberDAO.updateMember(member);
            System.out.println("Member updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating member.");
        }
    }

    private static void deleteMember() {
        System.out.print("Enter member ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        try {
            memberDAO.deleteMember(id);
            System.out.println("Member deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting member.");
        }
    }

    private static void listAllMembers() {
        try {
            List<Member> members = memberDAO.getAllMembers();
            for (Member member : members) {
                System.out.println(member);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error retrieving members.");
        }
    }

    private static void addTrainer() {
        System.out.print("Enter trainer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter trainer Description: ");
        String Description = scanner.nextLine();
        System.out.print("Enter trainer email: ");
        String email = scanner.nextLine();
        Trainer trainer = new Trainer(Id,name, Description, email);
        try {
            trainerDAO.addTrainer(trainer);
            System.out.println("Trainer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error adding trainer.");
        }
    }

    private static void viewTrainer() {
        System.out.print("Enter trainer ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        try {
            Trainer trainer = trainerDAO.getTrainer(id);
            if (trainer != null) {
                System.out.println("Trainer Details: " + trainer);
            } else {
                System.out.println("Trainer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error retrieving trainer.");
        }
    }

    private static void updateTrainer() {
        System.out.print("Enter trainer ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new trainer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new trainer specialty: ");
        String specialty = scanner.nextLine();
        System.out.print("Enter new trainer email: ");
        String email = scanner.nextLine();
        Trainer trainer = new Trainer(id, name, specialty, email);
        try {
            trainerDAO.updateTrainer(trainer);
            System.out.println("Trainer updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating trainer.");
        }
    }

    private static void deleteTrainer() {
        System.out.print("Enter trainer ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        try {
            trainerDAO.deleteTrainer(id);
            System.out.println("Trainer deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting trainer.");
        }
    }

    private static void listAllTrainers() {
        try {
            List<Trainer> trainers = trainerDAO.getAllTrainers();
            for (Trainer trainer : trainers) {
                System.out.println(trainer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error retrieving trainers.");
        }
    }

    private static void createPlan() {
        System.out.print("Enter plan name: ");
        String name = scanner.nextLine();
        System.out.print("Enter plan description: ");
        String description = scanner.nextLine();
        System.out.print("Enter plan price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        MembershipPlan plan = new MembershipPlan( Id,name, Description, price);
        try {
            membershipPlanDAO.addMembershipPlan(plan);
            System.out.println("Membership plan created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error creating membership plan.");
        }
    }

    private static void viewPlan() {
        System.out.print("Enter plan ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        try {
            MembershipPlan plan = membershipPlanDAO.getMembershipPlan(id);
            if (plan != null) {
                System.out.println("Membership Plan Details: " + plan);
            } else {
                System.out.println("Membership Plan not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error retrieving membership plan.");
        }
    }

    private static void updatePlan() {
        System.out.print("Enter plan ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new plan name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new plan description: ");
        String description = scanner.nextLine();
        System.out.print("Enter new plan price: ");
        double price = scanner.nextDouble();
        //scanner.nextLine(); // Consume newline
        MembershipPlan plan = new MembershipPlan( Id ,name, description, price);
        try {
            membershipPlanDAO.updateMembershipPlan(plan);
            System.out.println("Membership plan updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating membership plan.");
        }
    }

    private static void deletePlan() {
        System.out.print("Enter plan ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        try {
            membershipPlanDAO.deleteMembershipPlan(id);
            System.out.println("Membership plan deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting membership plan.");
        }
    }

    private static void listAllPlans() {
        try {
            List<MembershipPlan> plans = membershipPlanDAO.getAllMembershipPlans();
            for (MembershipPlan plan : plans) {
                System.out.println(plan);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error retrieving membership plans.");
        }
    }
}
