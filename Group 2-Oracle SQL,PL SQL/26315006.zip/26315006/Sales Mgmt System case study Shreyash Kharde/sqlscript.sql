REM   Script: Final Sub
REM   SQL/PL

-- Create Customers Table
CREATE TABLE Products ( 
    PRODUCT_ID NUMBER PRIMARY KEY, 
    PRODUCT_NAME VARCHAR2(100), 
    DESCRIPTION CLOB, 
    PRICE NUMBER, 
    AVAILABLE_QUANTITY NUMBER 
);


-- Create Products Table
CREATE TABLE Products ( 
    PRODUCT_ID NUMBER PRIMARY KEY, 
    PRODUCT_NAME VARCHAR2(100), 
    DESCRIPTION CLOB, 
    PRICE NUMBER, 
    AVAILABLE_QUANTITY NUMBER 
);



-- Create SalesOrders Table
CREATE TABLE SalesOrders ( 
    ORDER_ID NUMBER PRIMARY KEY, 
    CUSTOMER_ID NUMBER, 
    PRODUCT_ID NUMBER, 
    QUANTITY NUMBER, 
    ORDER_DATE DATE, 
    STATUS VARCHAR2(50), 
    CONSTRAINT fk_customer FOREIGN KEY (CUSTOMER_ID) REFERENCES Customers(CUSTOMER_ID), 
    CONSTRAINT fk_product FOREIGN KEY (PRODUCT_ID) REFERENCES Products(PRODUCT_ID) 
);


-- Insert Sample Data into Customers

INSERT INTO Customers VALUES (1, 'John', 'Doe', 'john.doe@example.com', '1234567890');

INSERT INTO Customers VALUES (2, 'Jane', 'Smith', 'jane.smith@example.com', '0987654321');

INSERT INTO Customers VALUES (3, 'Harre', 'Uopp', 'harre.uopp@example.com', '987654321');

INSERT INTO Customers VALUES (4, 'Uaure', 'Iodn', 'uaure.iodn@example.com', '997654321');

INSERT INTO Customers VALUES (5, 'Ranne', 'Mitsh', 'ranne.mitsh@example.com', '787654321');

-- Insert Sample Data into Products
INSERT INTO Products VALUES (1, 'Laptop', 'High performance laptop', 1000, 50);

INSERT INTO Products VALUES (2, 'Smartphone', 'Latest model smartphone', 800, 100);

INSERT INTO Products VALUES (3, 'Tv', 'Latest model tv', 900, 100);

INSERT INTO Products VALUES (4, 'AC', 'Latest model ac', 700, 125);

INSERT INTO Products VALUES (5, 'Fridge', 'Latest model fridge', 800, 50);

-- Insert Sample Data into SalesOrders
INSERT INTO SalesOrders VALUES (1, 1, 1, 2, SYSDATE, 'Pending');

INSERT INTO SalesOrders VALUES (2, 2, 2, 1, SYSDATE, 'Completed');

INSERT INTO SalesOrders VALUES (3, 3, 3, 2, SYSDATE, 'Completed');

INSERT INTO SalesOrders VALUES (4, 4, 4, 1, SYSDATE, 'Pending');

INSERT INTO SalesOrders VALUES (5, 5, 5, 2, SYSDATE, 'Completed');

-- Procedure for Customer Management
CREATE OR REPLACE PROCEDURE manage_customer ( 
    p_customer_id IN NUMBER, 
    p_first_name IN VARCHAR2, 
    p_last_name IN VARCHAR2, 
    p_email IN VARCHAR2, 
    p_phone_number IN VARCHAR2, 
    p_action IN VARCHAR2 
) IS 
BEGIN 
    IF p_action = 'INSERT' THEN 
        INSERT INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER) 
        VALUES (p_customer_id, p_first_name, p_last_name, p_email, p_phone_number); 
    ELSIF p_action = 'UPDATE' THEN 
        UPDATE Customers 
        SET FIRST_NAME = p_first_name, 
            LAST_NAME = p_last_name, 
            EMAIL = p_email, 
            PHONE_NUMBER = p_phone_number 
        WHERE CUSTOMER_ID = p_customer_id; 
    ELSIF p_action = 'DELETE' THEN 
        DELETE FROM Customers WHERE CUSTOMER_ID = p_customer_id; 
    END IF; 
END; 
/

-- Procedure for Inventory Tracking
CREATE OR REPLACE PROCEDURE update_inventory ( 
    p_product_id IN NUMBER, 
    p_quantity IN NUMBER, 
    p_action IN VARCHAR2 
) IS 
BEGIN 
    IF p_action = 'UPDATE' THEN 
        UPDATE Products 
        SET AVAILABLE_QUANTITY = AVAILABLE_QUANTITY - p_quantity 
        WHERE PRODUCT_ID = p_product_id; 
    END IF; 
END; 

/


-- Procedure for Sales Order Processing
CREATE OR REPLACE PROCEDURE manage_sales_order ( 
    p_order_id IN NUMBER, 
    p_customer_id IN NUMBER, 
    p_product_id IN NUMBER, 
    p_quantity IN NUMBER, 
    p_order_date IN DATE, 
    p_status IN VARCHAR2, 
    p_action IN VARCHAR2 
) IS 
BEGIN 
    IF p_action = 'INSERT' THEN 
        INSERT INTO SalesOrders (ORDER_ID, CUSTOMER_ID, PRODUCT_ID, QUANTITY, ORDER_DATE, STATUS) 
        VALUES (p_order_id, p_customer_id, p_product_id, p_quantity, p_order_date, p_status); 
    ELSIF p_action = 'UPDATE' THEN 
        UPDATE SalesOrders 
        SET CUSTOMER_ID = p_customer_id, 
            PRODUCT_ID = p_product_id, 
            QUANTITY = p_quantity, 
            ORDER_DATE = p_order_date, 
            STATUS = p_status 
        WHERE ORDER_ID = p_order_id; 
    ELSIF p_action = 'DELETE' THEN 
        DELETE FROM SalesOrders WHERE ORDER_ID = p_order_id; 
    END IF; 
END;
/


--Test Inventory Tracking:
EXEC update_inventory(1, 5, 'UPDATE')


--Test Sales Order Processing:
BEGIN 
    manage_sales_order(3, 3, 3, 2, SYSDATE,'INSERT', 'Completed'); 
    manage_sales_order(3, 1, 1, 2, SYSDATE,'UPDATE', 'Completed'); 
    manage_sales_order(4, 1, 1, 2, SYSDATE,'DELETE', 'Completed'); 
END;
/


--Test Customer Management:
BEGIN 
    manage_customer(3,'INSERT', 'Alice', 'Wonderland', 'alice.wonderland@example.com', '1122334455'); 
    manage_customer(3, 'UPDATE',  'Alice', 'Wonder', 'alice.wonder@example.com', '1122334466'); 
    manage_customer(3,'DELETE',  NULL, NULL, NULL, NULL); 
END;
/

