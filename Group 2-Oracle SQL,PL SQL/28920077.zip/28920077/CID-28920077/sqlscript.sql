REM   Script: Reservation Management
REM    Reservation Management System

CREATE TABLE Reservations ( 
    RESERVATION_ID NUMBER PRIMARY KEY, 
    CUSTOMER_ID NUMBER NOT NULL, 
    TRANSPORT_TYPE VARCHAR2(50) NOT NULL, 
    BOOKING_DATE DATE NOT NULL, 
    STATUS VARCHAR2(50) NOT NULL 
);

CREATE TABLE BookingProcessings ( 
    PROCESSING_ID NUMBER PRIMARY KEY, 
    RESERVATION_ID NUMBER NOT NULL, 
    PROCESSING_DATE DATE NOT NULL, 
    DECISION VARCHAR2(50) NOT NULL, 
    REMARKS VARCHAR2(255), 
    FOREIGN KEY (RESERVATION_ID) REFERENCES Reservations(RESERVATION_ID) 
);

CREATE TABLE TravelReports ( 
    REPORT_ID NUMBER PRIMARY KEY, 
    REPORT_DATE DATE NOT NULL, 
    TOTAL_RESERVATIONS NUMBER NOT NULL, 
    CONFIRMED_BOOKINGS NUMBER NOT NULL, 
    CANCELLED_BOOKINGS NUMBER NOT NULL, 
    PENDING_REQUESTS NUMBER NOT NULL 
);

INSERT INTO Reservations (RESERVATION_ID, CUSTOMER_ID, TRANSPORT_TYPE, BOOKING_DATE, STATUS) 
VALUES (1, 101, 'Railway', TO_DATE('2024-07-01', 'YYYY-MM-DD'), 'Pending');

INSERT INTO Reservations (RESERVATION_ID, CUSTOMER_ID, TRANSPORT_TYPE, BOOKING_DATE, STATUS) 
VALUES (2, 102, 'Airline', TO_DATE('2024-07-02', 'YYYY-MM-DD'), 'Confirmed');

INSERT INTO Reservations (RESERVATION_ID, CUSTOMER_ID, TRANSPORT_TYPE, BOOKING_DATE, STATUS) 
VALUES (3, 103, 'Railway', TO_DATE('2024-07-03', 'YYYY-MM-DD'), 'Cancelled');

INSERT INTO BookingProcessings (PROCESSING_ID, RESERVATION_ID, PROCESSING_DATE, DECISION, REMARKS) 
VALUES (1, 1, TO_DATE('2024-07-01', 'YYYY-MM-DD'), 'Pending', 'Awaiting confirmation');

INSERT INTO BookingProcessings (PROCESSING_ID, RESERVATION_ID, PROCESSING_DATE, DECISION, REMARKS) 
VALUES (2, 2, TO_DATE('2024-07-02', 'YYYY-MM-DD'), 'Confirmed', 'Confirmed by airline');

INSERT INTO BookingProcessings (PROCESSING_ID, RESERVATION_ID, PROCESSING_DATE, DECISION, REMARKS) 
VALUES (3, 3, TO_DATE('2024-07-03', 'YYYY-MM-DD'), 'Cancelled', 'Cancelled by customer');

CREATE OR REPLACE PROCEDURE manage_reservation ( 
    p_action IN VARCHAR2, 
    p_reservation_id IN NUMBER, 
    p_customer_id IN NUMBER DEFAULT NULL, 
    p_transport_type IN VARCHAR2 DEFAULT NULL, 
    p_booking_date IN DATE DEFAULT NULL, 
    p_status IN VARCHAR2 DEFAULT NULL 
) IS 
BEGIN 
    IF p_action = 'INSERT' THEN 
        INSERT INTO Reservations (RESERVATION_ID, CUSTOMER_ID, TRANSPORT_TYPE, BOOKING_DATE, STATUS) 
        VALUES (p_reservation_id, p_customer_id, p_transport_type, p_booking_date, p_status); 
    ELSIF p_action = 'UPDATE' THEN 
        UPDATE Reservations 
        SET CUSTOMER_ID = p_customer_id, 
            TRANSPORT_TYPE = p_transport_type, 
            BOOKING_DATE = p_booking_date, 
            STATUS = p_status 
        WHERE RESERVATION_ID = p_reservation_id; 
    ELSIF p_action = 'DELETE' THEN 
        DELETE FROM Reservations WHERE RESERVATION_ID = p_reservation_id; 
    END IF; 
END; 
/

CREATE OR REPLACE PROCEDURE process_booking ( 
    p_processing_id IN NUMBER, 
    p_reservation_id IN NUMBER, 
    p_processing_date IN DATE, 
    p_decision IN VARCHAR2, 
    p_remarks IN VARCHAR2 DEFAULT NULL 
) IS 
BEGIN 
    INSERT INTO BookingProcessings (PROCESSING_ID, RESERVATION_ID, PROCESSING_DATE, DECISION, REMARKS) 
    VALUES (p_processing_id, p_reservation_id, p_processing_date, p_decision, p_remarks); 
 
    UPDATE Reservations 
    SET STATUS = p_decision 
    WHERE RESERVATION_ID = p_reservation_id; 
END; 
/

CREATE OR REPLACE PROCEDURE generate_travel_report ( 
    p_report_id IN NUMBER, 
    p_report_date IN DATE 
) IS 
    v_total_reservations NUMBER; 
    v_confirmed_bookings NUMBER; 
    v_cancelled_bookings NUMBER; 
    v_pending_requests NUMBER; 
BEGIN 
    SELECT COUNT(*) INTO v_total_reservations FROM Reservations; 
    SELECT COUNT(*) INTO v_confirmed_bookings FROM Reservations WHERE STATUS = 'Confirmed'; 
    SELECT COUNT(*) INTO v_cancelled_bookings FROM Reservations WHERE STATUS = 'Cancelled'; 
    SELECT COUNT(*) INTO v_pending_requests FROM Reservations WHERE STATUS = 'Pending'; 
 
    INSERT INTO TravelReports (REPORT_ID, REPORT_DATE, TOTAL_RESERVATIONS, CONFIRMED_BOOKINGS, CANCELLED_BOOKINGS, PENDING_REQUESTS) 
    VALUES (p_report_id, p_report_date, v_total_reservations, v_confirmed_bookings, v_cancelled_bookings, v_pending_requests); 
END; 
/

BEGIN 
    manage_reservation('INSERT', 4, 104, 'Airline', TO_DATE('2024-07-04', 'YYYY-MM-DD'), 'Pending'); 
    manage_reservation('UPDATE', 4, 104, 'Airline', TO_DATE('2024-07-04', 'YYYY-MM-DD'), 'Confirmed'); 
    manage_reservation('DELETE', 4); 
END; 
/

BEGIN 
    process_booking(4, 1, TO_DATE('2024-07-05', 'YYYY-MM-DD'), 'Confirmed', 'Confirmed by railway'); 
END; 
/

BEGIN 
    generate_travel_report(1, TO_DATE('2024-07-06', 'YYYY-MM-DD')); 
END; 
/

