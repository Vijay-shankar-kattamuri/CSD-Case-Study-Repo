CREATE OR REPLACE PROCEDURE TrackTransaction (
    p_transaction_id IN NUMBER,
    p_account_id IN NUMBER,
    p_transaction_date IN DATE,
    p_amount IN NUMBER,
    p_description IN VARCHAR2
) AS
    account_balance NUMBER;
BEGIN
    -- Insert the transaction
    INSERT INTO AccountTransactions (TRANSACTION_ID, ACCOUNT_ID, TRANSACTION_DATE, AMOUNT, DESCRIPTION)
    VALUES (p_transaction_id, p_account_id, p_transaction_date, p_amount, p_description);

    -- Update the account balance
    UPDATE FinancialAccounts
    SET BALANCE = BALANCE + p_amount
    WHERE ACCOUNT_ID = p_account_id;

    -- Fetch the updated balance
    SELECT BALANCE
    INTO account_balance
    FROM FinancialAccounts
    WHERE ACCOUNT_ID = p_account_id;

    -- Output the details of the transaction
    DBMS_OUTPUT.PUT_LINE('Transaction ID: ' || p_transaction_id);
    DBMS_OUTPUT.PUT_LINE('Account ID: ' || p_account_id);
    DBMS_OUTPUT.PUT_LINE('Transaction Date: ' || TO_CHAR(p_transaction_date, 'YYYY-MM-DD'));
    DBMS_OUTPUT.PUT_LINE('Amount: ' || p_amount);
    DBMS_OUTPUT.PUT_LINE('Description: ' || p_description);
    DBMS_OUTPUT.PUT_LINE('Updated Account Balance: ' || account_balance);
END;
/
SET SERVEROUTPUT ON;

BEGIN
    TrackTransaction(25, 8, TO_DATE('2023-08-15', 'YYYY-MM-DD'), 1000, 'Deposit');
END;
/

