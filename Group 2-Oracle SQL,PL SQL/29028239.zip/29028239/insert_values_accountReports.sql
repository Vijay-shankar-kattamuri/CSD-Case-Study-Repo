INSERT INTO AccountReports (REPORT_ID, REPORT_DATE, ACCOUNT_BALANCES, TRANSACTION_SUMMARY, MONTHLY_STATEMENT) 
VALUES 
(
    1, 
    TO_DATE('2023-06-30', 'YYYY-MM-DD'), 
    'Account ID: 1, Balance: 10800' || CHR(10) || 
    'Account ID: 2, Balance: 20700' || CHR(10) || 
    'Account ID: 3, Balance: 15400' || CHR(10) || 
    'Account ID: 4, Balance: 25500', 
    'Transaction ID: 1, Account ID: 1, Date: 2023-01-05, Amount: 500, Description: Deposit' || CHR(10) || 
    'Transaction ID: 2, Account ID: 1, Date: 2023-01-10, Amount: -200, Description: Withdrawal' || CHR(10) || 
    'Transaction ID: 3, Account ID: 2, Date: 2023-02-10, Amount: 1000, Description: Deposit' || CHR(10) || 
    'Transaction ID: 4, Account ID: 2, Date: 2023-02-15, Amount: -500, Description: Withdrawal', 
    'Account Balances:' || CHR(10) || 
    'Account ID: 1, Balance: 1300' || CHR(10) || 
    'Account ID: 2, Balance: 1500' || CHR(10) || 
    'Account ID: 3, Balance: 1900' || CHR(10) || 
    'Account ID: 4, Balance: 2900' || CHR(10) || 
    'Transaction Summary:' || CHR(10) || 
    'Transaction ID: 1, Account ID: 1, Date: 2023-01-05, Amount: 500, Description: Deposit' || CHR(10) || 
    'Transaction ID: 2, Account ID: 1, Date: 2023-01-10, Amount: -200, Description: Withdrawal' || CHR(10) || 
    'Transaction ID: 3, Account ID: 2, Date: 2023-02-10, Amount: 1000, Description: Deposit' || CHR(10) || 
    'Transaction ID: 4, Account ID: 2, Date: 2023-02-15, Amount: -500, Description: Withdrawal'
);


