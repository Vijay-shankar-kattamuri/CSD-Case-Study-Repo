INSERT INTO FinancialAccounts VALUES (1, 101, 'Savings', TO_DATE('2023-01-01', 'YYYY-MM-DD'), 10080);
INSERT INTO FinancialAccounts VALUES (2, 102, 'Checking', TO_DATE('2023-02-01', 'YYYY-MM-DD'), 20700);
INSERT INTO FinancialAccounts VALUES (3, 103, 'Savings', TO_DATE('2023-03-01', 'YYYY-MM-DD'), 15400);
INSERT INTO FinancialAccounts VALUES (4, 104, 'Checking', TO_DATE('2023-04-01', 'YYYY-MM-DD'), 25500);
INSERT INTO FinancialAccounts VALUES (5, 105, 'Savings', TO_DATE('2023-05-01', 'YYYY-MM-DD'), 30100);
INSERT INTO FinancialAccounts VALUES (6, 106, 'Checking', TO_DATE('2023-06-01', 'YYYY-MM-DD'), 40900);
INSERT INTO FinancialAccounts VALUES (7, 107, 'Savings', TO_DATE('2023-07-01', 'YYYY-MM-DD'), 56000);

