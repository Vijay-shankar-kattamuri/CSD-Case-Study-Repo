import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            CustomerDAO customerDAO = new CustomerDAO(connection);
            ProductDAO productDAO = new ProductDAO(connection);
            OrderDAO orderDAO = new OrderDAO(connection);

            while (true) {
                System.out.println("Welcome to Order Management System");
                System.out.println("1. Manage Customers");
                System.out.println("2. Manage Products");
                System.out.println("3. Place an Order");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline character

                switch (choice) {
                    case 1:
                        manageCustomers(customerDAO, scanner);
                        break;
                    case 2:
                        manageProducts(productDAO, scanner);
                        break;
                    case 3:
                        placeOrder(orderDAO, customerDAO, productDAO, scanner);
                        break;
                    case 4:
                        System.out.println("Exiting the application. Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option.");
                }
            }
        } catch (SQLException ex) {
            System.out.println("An error occurred while connecting to the database: " + ex.getMessage());
        }
    }

    private static void manageCustomers(CustomerDAO customerDAO, Scanner scanner) {
        while (true) {
            System.out.println("\nCustomer Management Menu:");
            System.out.println("1. Add a new customer");
            System.out.println("2. View all customers");
            System.out.println("3. Update customer information");
            System.out.println("4. Delete a customer");
            System.out.println("5. Go back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline character

            switch (choice) {
                case 1:
                    addNewCustomer(customerDAO, scanner);
                    break;
                case 2:
                    viewAllCustomers(customerDAO);
                    break;
                case 3:
                    updateCustomer(customerDAO, scanner);
                    break;
                case 4:
                    deleteCustomer(customerDAO, scanner);
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static void addNewCustomer(CustomerDAO customerDAO, Scanner scanner) {
        System.out.println("\nEnter customer details:");
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Address: ");
        String address = scanner.nextLine();

        Customer newCustomer = new Customer();
        newCustomer.setName(name);
        newCustomer.setEmail(email);
        newCustomer.setPhone(phone);
        newCustomer.setAddress(address);

        try {
            customerDAO.addCustomer(newCustomer);
            System.out.println("Customer added successfully.");
        } catch (SQLException ex) {
            System.out.println("Error adding customer: " + ex.getMessage());
        }
    }

    private static void viewAllCustomers(CustomerDAO customerDAO) {
        try {
            List<Customer> customers = customerDAO.getAllCustomers();
            System.out.println("\nAll Customers:");
            for (Customer customer : customers) {
                System.out.println(customer.getCustomerId() + ". " + customer.getName() + " - " + customer.getEmail());
            }
        } catch (SQLException ex) {
            System.out.println("Error fetching customers: " + ex.getMessage());
        }
    }

    private static void updateCustomer(CustomerDAO customerDAO, Scanner scanner) {
        System.out.print("\nEnter customer ID to update: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline character

        try {
            Customer existingCustomer = customerDAO.getCustomerById(customerId);
            if (existingCustomer != null) {
                System.out.println("Current details:");
                System.out.println("Name: " + existingCustomer.getName());
                System.out.println("Email: " + existingCustomer.getEmail());
                System.out.println("Phone: " + existingCustomer.getPhone());
                System.out.println("Address: " + existingCustomer.getAddress());

                System.out.println("\nEnter new details:");
                System.out.print("Name (Press Enter to keep current): ");
                String name = scanner.nextLine();
                if (!name.isEmpty()) {
                    existingCustomer.setName(name);
                }
                System.out.print("Email (Press Enter to keep current): ");
                String email = scanner.nextLine();
                if (!email.isEmpty()) {
                    existingCustomer.setEmail(email);
                }
                System.out.print("Phone (Press Enter to keep current): ");
                String phone = scanner.nextLine();
                if (!phone.isEmpty()) {
                    existingCustomer.setPhone(phone);
                }
                System.out.print("Address (Press Enter to keep current): ");
                String address = scanner.nextLine();
                if (!address.isEmpty()) {
                    existingCustomer.setAddress(address);
                }

                customerDAO.updateCustomer(existingCustomer);
                System.out.println("Customer updated successfully.");
            } else {
                System.out.println("Customer with ID " + customerId + " not found.");
            }
        } catch (SQLException ex) {
            System.out.println("Error updating customer: " + ex.getMessage());
        }
    }

    private static void deleteCustomer(CustomerDAO customerDAO, Scanner scanner) {
        System.out.print("\nEnter customer ID to delete: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline character

        try {
            customerDAO.deleteCustomer(customerId);
            System.out.println("Customer deleted successfully.");
        } catch (SQLException ex) {
            System.out.println("Error deleting customer: " + ex.getMessage());
        }
    }

    private static void manageProducts(ProductDAO productDAO, Scanner scanner) {
        while (true) {
            System.out.println("\nProduct Management Menu:");
            System.out.println("1. Add a new product");
            System.out.println("2. View all products");
            System.out.println("3. Update product information");
            System.out.println("4. Delete a product");
            System.out.println("5. Go back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline character

            switch (choice) {
                case 1:
                    addNewProduct(productDAO, scanner);
                    break;
                case 2:
                    viewAllProducts(productDAO);
                    break;
                case 3:
                    updateProduct(productDAO, scanner);
                    break;
                case 4:
                    deleteProduct(productDAO, scanner);
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static void addNewProduct(ProductDAO productDAO, Scanner scanner) {
        System.out.println("\nEnter product details:");
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Category: ");
        String category = scanner.nextLine();
        System.out.print("Price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();  // Consume newline character
        System.out.print("Stock Quantity: ");
        int stockQuantity = scanner.nextInt();
        scanner.nextLine();  // Consume newline character

        Product newProduct = new Product();
        newProduct.setName(name);
        newProduct.setCategory(category);
        newProduct.setPrice(price);
        newProduct.setStockQuantity(stockQuantity);

        try {
            productDAO.addProduct(newProduct);
            System.out.println("Product added successfully.");
        } catch (SQLException ex) {
            System.out.println("Error adding product: " + ex.getMessage());
        }
    }

    private static void viewAllProducts(ProductDAO productDAO) {
        try {
            List<Product> products = productDAO.getAllProducts();
            System.out.println("\nAll Products:");
            for (Product product : products) {
                System.out.println(product.getProductId() + ". " + product.getName() + " - " + product.getCategory() + " - $" + product.getPrice());
            }
        } catch (SQLException ex) {
            System.out.println("Error fetching products: " + ex.getMessage());
        }
    }

    private static void updateProduct(ProductDAO productDAO, Scanner scanner) {
        System.out.print("\nEnter product ID to update: ");
        int productId = scanner.nextInt();
        scanner.nextLine();  // Consume newline character

        try {
            Product existingProduct = productDAO.getProductById(productId);
            if (existingProduct != null) {
                System.out.println("Current details:");
                System.out.println("Name: " + existingProduct.getName());
                System.out.println("Category: " + existingProduct.getCategory());
                System.out.println("Price: $" + existingProduct.getPrice());
                System.out.println("Stock Quantity: " + existingProduct.getStockQuantity());

                System.out.println("\nEnter new details:");
                System.out.print("Name (Press Enter to keep current): ");
                String name = scanner.nextLine();
                if (!name.isEmpty()) {
                    existingProduct.setName(name);
                }
                System.out.print("Category (Press Enter to keep current): ");
                String category = scanner.nextLine();
                if (!category.isEmpty()) {
                    existingProduct.setCategory(category);
                }
                System.out.print("Price (Press Enter to keep current): ");
                String priceStr = scanner.nextLine();
                if (!priceStr.isEmpty()) {
                    double price = Double.parseDouble(priceStr);
                    existingProduct.setPrice(price);
                }
                System.out.print("Stock Quantity (Press Enter to keep current): ");
                String stockQuantityStr = scanner.nextLine();
                if (!stockQuantityStr.isEmpty()) {
                    int stockQuantity = Integer.parseInt(stockQuantityStr);
                    existingProduct.setStockQuantity(stockQuantity);
                }

                productDAO.updateProduct(existingProduct);
                System.out.println("Product updated successfully.");
            } else {
                System.out.println("Product with ID " + productId + " not found.");
            }
        } catch (SQLException ex) {
            System.out.println("Error updating product: " + ex.getMessage());
        }
    }

    private static void deleteProduct(ProductDAO productDAO, Scanner scanner) {
        System.out.print("\nEnter product ID to delete: ");
        int productId = scanner.nextInt();
        scanner.nextLine();  // Consume newline character

        try {
            productDAO.deleteProduct(productId);
            System.out.println("Product deleted successfully.");
        } catch (SQLException ex) {
            System.out.println("Error deleting product: " + ex.getMessage());
        }
    }

    private static void placeOrder(OrderDAO orderDAO, CustomerDAO customerDAO, ProductDAO productDAO, Scanner scanner) {
        try {
            System.out.println("\nPlacing a New Order:");

            // Select customer
            System.out.println("Available Customers:");
            List<Customer> customers = customerDAO.getAllCustomers();
            for (Customer customer : customers) {
                System.out.println(customer.getCustomerId() + ". " + customer.getName());
            }
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();
            scanner.nextLine();  // Consume newline character

            Customer customer = customerDAO.getCustomerById(customerId);
            if (customer == null) {
                System.out.println("Customer with ID " + customerId + " not found.");
                return;
            }

            // Select products
            System.out.println("\nAvailable Products:");
            List<Product> products = productDAO.getAllProducts();
            for (Product product : products) {
                System.out.println(product.getProductId() + ". " + product.getName() + " - $" + product.getPrice() + " - Stock: " + product.getStockQuantity());
            }

            Order newOrder = new Order();
            newOrder.setCustomer(customer);
            newOrder.setOrderDate(new Date()); // Set current date as order date
            newOrder.setStatus("Pending"); // Initial status of the order

            while (true) {
                System.out.print("\nEnter product ID to add to order (0 to finish): ");
                int productId = scanner.nextInt();
                if (productId == 0) {
                    break;
                }
                scanner.nextLine();  // Consume newline character

                Product product = productDAO.getProductById(productId);
                if (product == null) {
                    System.out.println("Product with ID " + productId + " not found. Please try again.");
                    continue;
                }

                System.out.print("Enter quantity: ");
                int quantity = scanner.nextInt();
                scanner.nextLine();  // Consume newline character

                if (quantity <= 0 || quantity > product.getStockQuantity()) {
                    System.out.println("Invalid quantity. Please enter a valid quantity.");
                    continue;
                }

                OrderItem orderItem = new OrderItem();
                orderItem.setProduct(product);
                orderItem.setQuantity(quantity);
                orderItem.setPrice(product.getPrice() * quantity);
                newOrder.addOrderItem(orderItem);
            }

            // Place order
            orderDAO.placeOrder(newOrder);
            System.out.println("Order placed successfully.");
        } catch (SQLException ex) {
            System.out.println("Error placing order: " + ex.getMessage());
        }
    }
}
