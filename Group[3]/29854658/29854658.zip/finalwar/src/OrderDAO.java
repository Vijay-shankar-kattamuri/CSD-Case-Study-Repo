import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {
    private Connection connection;

    public OrderDAO(Connection connection) {
        this.connection = connection;
    }

    public void placeOrder(Order order) throws SQLException {
        String insertOrderQuery = "INSERT INTO orders (customer_id, order_date, status) VALUES (?, ?, ?)";
        String insertOrderItemQuery = "INSERT INTO order_item (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";

        try (PreparedStatement orderStmt = connection.prepareStatement(insertOrderQuery, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement orderItemStmt = connection.prepareStatement(insertOrderItemQuery)) {

            connection.setAutoCommit(false);

            // Insert order
            orderStmt.setInt(1, order.getCustomer().getCustomerId());  // Assuming Customer has getCustomerId() method
            orderStmt.setDate(2, new java.sql.Date(order.getOrderDate().getTime()));
            orderStmt.setString(3, order.getStatus());
            orderStmt.executeUpdate();

            // Retrieve generated order ID
            ResultSet generatedKeys = orderStmt.getGeneratedKeys();
            int orderId = -1;
            if (generatedKeys.next()) {
                orderId = generatedKeys.getInt(1);
            } else {
                throw new SQLException("Failed to place order, no ID obtained.");
            }

            // Insert order items
            for (OrderItem orderItem : order.getOrderItems()) {
                orderItemStmt.setInt(1, orderId);
                orderItemStmt.setInt(2, orderItem.getProduct().getProductId());  // Assuming Product has getProductId() method
                orderItemStmt.setInt(3, orderItem.getQuantity());
                orderItemStmt.setDouble(4, orderItem.getPrice());
                orderItemStmt.addBatch();
            }

            orderItemStmt.executeBatch();
            connection.commit();

        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    // Other methods (getAllOrders, getOrderById, updateOrderStatus, cancelOrder) remain unchanged
}
