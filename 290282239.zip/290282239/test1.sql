SET SERVEROUTPUT ON;
BEGIN
    -- Test inserting and updating more accounts
    ManageAccount(8, 108, 'Savings', TO_DATE('2023-08-01', 'YYYY-MM-DD'), 6000);
    ManageAccount(8, 108, 'Checking', TO_DATE('2023-08-01', 'YYYY-MM-DD'), 6500);
    ManageAccount(9, 109, 'Savings', TO_DATE('2023-09-01', 'YYYY-MM-DD'), 7000);
    ManageAccount(9, 109, 'Checking', TO_DATE('2023-09-01', 'YYYY-MM-DD'), 7500);
END;
/