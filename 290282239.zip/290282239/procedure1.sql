CREATE OR REPLACE PROCEDURE ManageAccount (
    p_account_id IN NUMBER,
    p_customer_id IN NUMBER,
    p_account_type IN VARCHAR2,
    p_opening_date IN DATE,
    p_balance IN NUMBER
) AS
    account_rec FinancialAccounts%ROWTYPE;
BEGIN
    BEGIN
        -- Attempt to insert the new account
        INSERT INTO FinancialAccounts (ACCOUNT_ID, CUSTOMER_ID, ACCOUNT_TYPE, OPENING_DATE, BALANCE)
        VALUES (p_account_id, p_customer_id, p_account_type, p_opening_date, p_balance);
        
        -- Output inserted values
        dbms_output.put_line('Inserted Account: ' || p_account_id || ', Customer: ' || p_customer_id || ', Type: ' || p_account_type || ', Date: ' || p_opening_date || ', Balance: ' || p_balance);
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            -- Update the existing account if a duplicate is found
            UPDATE FinancialAccounts
            SET CUSTOMER_ID = p_customer_id,
                ACCOUNT_TYPE = p_account_type,
                OPENING_DATE = p_opening_date,
                BALANCE = p_balance
            WHERE ACCOUNT_ID = p_account_id;
            
            -- Fetch the updated row for output
            SELECT *
            INTO account_rec
            FROM FinancialAccounts
            WHERE ACCOUNT_ID = p_account_id;
            
            -- Output updated values
            dbms_output.put_line('Updated Account: ' || account_rec.ACCOUNT_ID || ', Customer: ' || account_rec.CUSTOMER_ID || ', Type: ' || account_rec.ACCOUNT_TYPE || ', Date: ' || account_rec.OPENING_DATE || ', Balance: ' || account_rec.BALANCE);
    END;
END;
/