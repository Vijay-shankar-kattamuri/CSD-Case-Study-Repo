SET SERVEROUTPUT ON;
BEGIN
    -- Test tracking transactions
    TrackTransaction(41, 7, TO_DATE('2023-09-15', 'YYYY-MM-DD'), 1000, 'Deposit');
    TrackTransaction(42, 8, TO_DATE('2023-09-16', 'YYYY-MM-DD'), 1500, 'Withdrawal');
    TrackTransaction(43, 9, TO_DATE('2023-09-17', 'YYYY-MM-DD'), 2000, 'Deposit');
END;
/
