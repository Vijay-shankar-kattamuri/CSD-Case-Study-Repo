
package feedbackmanagement;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerManagement {
    private Connection connection;

    public CustomerManagement(Connection connection) {
        this.connection = connection;
    }

    public void addCustomer(Scanner scanner) {
        try {
            System.out.println("Enter customer name:");
            String customerName = scanner.nextLine();
            System.out.println("Enter email:");
            String email = scanner.nextLine();

            String query = "INSERT INTO Customer (customer_name, email) VALUES (?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, customerName);
            pstmt.setString(2, email);
            pstmt.executeUpdate();
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewCustomerDetails(Scanner scanner) {
        try {
            System.out.println("Enter customer ID:");
            int customerId = scanner.nextInt();
            scanner.nextLine(); 
            String query = "SELECT * FROM Customer WHERE customer_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Customer Name: " + rs.getString("customer_name"));
                System.out.println("Email: " + rs.getString("email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCustomerDetails(Scanner scanner) {
        try {
            System.out.println("Enter customer ID:");
            int customerId = scanner.nextInt();
            scanner.nextLine(); 
            System.out.println("Enter new customer name:");
            String customerName = scanner.nextLine();
            System.out.println("Enter new email:");
            String email = scanner.nextLine();

            String query = "UPDATE Customer SET customer_name = ?, email = ? WHERE customer_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, customerName);
            pstmt.setString(2, email);
            pstmt.setInt(3, customerId);
            pstmt.executeUpdate();
            System.out.println("Customer details updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCustomer(Scanner scanner) {
        try {
            System.out.println("Enter customer ID:");
            int customerId = scanner.nextInt();
            scanner.nextLine(); 
            String query = "DELETE FROM Customer WHERE customer_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, customerId);
            pstmt.executeUpdate();
            System.out.println("Customer deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}



