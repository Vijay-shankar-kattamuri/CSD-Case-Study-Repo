
package feedbackmanagement;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class FeedbackManagement {
    private Connection connection;

    public FeedbackManagement(Connection connection) {
        this.connection = connection;
    }

    public void recordNewFeedback(Scanner scanner) {
        try {
            System.out.println("Enter customer ID:");
            int customerId = scanner.nextInt();
            scanner.nextLine(); 
            System.out.println("Enter feedback text:");
            String feedbackText = scanner.nextLine();
            System.out.println("Enter status:");
            String status = scanner.nextLine();

            String query = "INSERT INTO Feedback (customer_id, feedback_date, feedback_text, status) VALUES (?, CURDATE(), ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, customerId);
            pstmt.setString(2, feedbackText);
            pstmt.setString(3, status);
            pstmt.executeUpdate();
            System.out.println("Feedback recorded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewFeedbackDetails(Scanner scanner) {
        try {
            System.out.println("Enter feedback ID:");
            int feedbackId = scanner.nextInt();
            scanner.nextLine(); 
            String query = "SELECT * FROM Feedback WHERE feedback_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, feedbackId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.println("Feedback ID: " + rs.getInt("feedback_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Feedback Date: " + rs.getDate("feedback_date"));
                System.out.println("Feedback Text: " + rs.getString("feedback_text"));
                System.out.println("Status: " + rs.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateFeedbackStatus(Scanner scanner) {
        try {
            System.out.println("Enter feedback ID:");
            int feedbackId = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter new status:");
            String status = scanner.nextLine();

            String query = "UPDATE Feedback SET status = ? WHERE feedback_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, status);
            pstmt.setInt(2, feedbackId);
            pstmt.executeUpdate();
            System.out.println("Feedback status updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteFeedback(Scanner scanner) {
        try {
            System.out.println("Enter feedback ID:");
            int feedbackId = scanner.nextInt();
            scanner.nextLine(); 
            String query = "DELETE FROM Feedback WHERE feedback_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, feedbackId);
            pstmt.executeUpdate();
            System.out.println("Feedback deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}



