
package feedbackmanagement;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class MainApplication {
    private static Connection connection;
    private static CustomerManagement customerManagement;
    private static FeedbackManagement feedbackManagement;
    private static AnalysisManagement analysisManagement;
    private static ResponseManagement responseManagement;

    public static void main(String[] args) {
        try {
            connection = DatabaseConnection.getConnection();
            customerManagement = new CustomerManagement(connection);
            feedbackManagement = new FeedbackManagement(connection);
            analysisManagement = new AnalysisManagement(connection);
            responseManagement = new ResponseManagement(connection);

            Scanner scanner = new Scanner(System.in);
            boolean exit = false;

            while (!exit) {
                System.out.println("Customer Feedback Management System");
                System.out.println("1. Customer Management");
                System.out.println("2. Feedback Management");
                System.out.println("3. Analysis Management");
                System.out.println("4. Response Management");
                System.out.println("5. Exit");

                int choice = scanner.nextInt();
                scanner.nextLine(); 

                switch (choice) {
                    case 1:
                        manageCustomer(scanner);
                        break;
                    case 2:
                        manageFeedback(scanner);
                        break;
                    case 3:
                        manageAnalysis(scanner);
                        break;
                    case 4:
                        manageResponse(scanner);
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void manageCustomer(Scanner scanner) {
        boolean exit = false;
        while (!exit) {
            System.out.println("Customer Management");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer Details");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    customerManagement.addCustomer(scanner);
                    break;
                case 2:
                    customerManagement.viewCustomerDetails(scanner);
                    break;
                case 3:
                    customerManagement.updateCustomerDetails(scanner);
                    break;
                case 4:
                    customerManagement.deleteCustomer(scanner);
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageFeedback(Scanner scanner) {
        boolean exit = false;
        while (!exit) {
            System.out.println("Feedback Management");
            System.out.println("1. Record New Feedback");
            System.out.println("2. View Feedback Details");
            System.out.println("3. Update Feedback Status");
            System.out.println("4. Delete Feedback");
            System.out.println("5. Back");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    feedbackManagement.recordNewFeedback(scanner);
                    break;
                case 2:
                    feedbackManagement.viewFeedbackDetails(scanner);
                    break;
                case 3:
                    feedbackManagement.updateFeedbackStatus(scanner);
                    break;
                case 4:
                    feedbackManagement.deleteFeedback(scanner);
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

 private static void manageAnalysis(Scanner scanner) {
    boolean exit = false;
    while (!exit) {
        System.out.println("Analysis Management");
        System.out.println("1. Add Analysis");
        System.out.println("2. View Analysis Reports");
        System.out.println("3. Back");

        int choice = scanner.nextInt();
        scanner.nextLine(); 

        switch (choice) {
            case 1:
                analysisManagement.addAnalysis(scanner); 
                break;
            case 2:
                analysisManagement.viewAnalysisReports(scanner);
                break;
            case 3:
                exit = true;
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}


   private static void manageResponse(Scanner scanner) {
    boolean exit = false;
    while (!exit) {
        System.out.println("Response Management");
        System.out.println("1. Add Response");
        System.out.println("2. View Response History");
        System.out.println("3. Back");

        int choice = scanner.nextInt();
        scanner.nextLine(); 

        switch (choice) {
            case 1:
                responseManagement.addResponse(scanner); 
                break;
            case 2:
                responseManagement.viewResponseHistory(scanner);
                break;
            case 3:
                exit = true;
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}

}







