Project Description
This project is a menu-based console application designed to manage a hospital information system. It assesses your proficiency in Core Java, MySQL, and JDBC by enabling CRUD (Create, Read, Update, Delete) operations for patients and doctors, and providing functionality for scheduling appointments.

Functionalities
1. Patient Management
Add a new patient
View patient details
Update patient information
Delete a patient
2. Doctor Management
Add a new doctor
View doctor details
Update doctor information
Delete a doctor
3. Appointment Scheduling
Display list of available doctors
Display list of patients
Schedule an appointment for a patient with a doctor
Update the appointment record in the database
Validate that the selected doctor is available
Validate that the selected patient doesn't have overlapping appointments
Database Schema
Patient Table
patient_id (Primary Key)
name
date_of_birth
gender
contact_number
Doctor Table
doctor_id (Primary Key)
name
specialization
contact_number
Appointment Table
appointment_id (Primary Key)
doctor_id (Foreign Key references Doctor Table)
patient_id (Foreign Key references Patient Table)
appointment_date
appointment_time
Requirements
Develop a menu-based console application using Core Java.
Use JDBC for interactions with the MySQL database.
Implement menu options for CRUD operations for patients and doctors, and appointment scheduling.
Ensure that the application updates the appointment records appropriately.
Handle exceptions effectively and provide user-friendly error messages.
Ensure the application code is clean, well-documented, and follows standard coding conventions.
Setup Instructions
Prerequisites
Java Development Kit (JDK) installed
MySQL Server and MySQL Workbench installed
An Integrated Development Environment (IDE), preferably IntelliJ IDEA
Database Setup
Open MySQL Workbench and connect to your MySQL server.
Create a new database named hospital_db.
Use the following SQL scripts to create the required tables:
sql
Copy code
CREATE DATABASE hospital_db;

USE hospital_db;

CREATE TABLE Patient (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    gender VARCHAR(10),
    contact_number VARCHAR(15)
);

CREATE TABLE Doctor (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(50),
    contact_number VARCHAR(15)
);

CREATE TABLE Appointment (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id INT,
    patient_id INT,
    appointment_date DATE,
    appointment_time TIME,
    FOREIGN KEY (doctor_id) REFERENCES Doctor(doctor_id),
    FOREIGN KEY (patient_id) REFERENCES Patient(patient_id)
);
Project Setup
Clone the repository from GitHub:
sh
Copy code
git clone <repository_link>
Open the project in IntelliJ IDEA.
Add the MySQL JDBC Driver to the project:
Download the MySQL Connector/J from here.
Add the JAR file to your project libraries.
Configure the database connection in the project:
Update the database connection details (URL, username, password) in the DatabaseConnection.java file.
Running the Application
Open the main class file HospitalManagementSystem.java.
Run the main method to start the application.
Use the console menu to navigate through the different functionalities.
Usage Instructions
Main Menu Options
Patient Management
Add Patient
View Patient
Update Patient
Delete Patient
Doctor Management
Add Doctor
View Doctor
Update Doctor
Delete Doctor
Appointment Scheduling
Display Available Doctors
Display Patients
Schedule Appointment
Update Appointment
Exception Handling
The application handles SQL and input exceptions, providing user-friendly error messages for issues such as invalid input, database connection errors, and constraint violations.