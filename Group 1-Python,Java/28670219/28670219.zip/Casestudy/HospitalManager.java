import java.util.HashMap;
import java.util.Scanner;

public class HospitalManager {
    private HashMap<Integer, Patient> patients = new HashMap<>();
    private HashMap<Integer, Bed> beds = new HashMap<>();

    public HospitalManager(int numberOfBeds) {
        for (int i = 1; i <= numberOfBeds; i++) {
            beds.put(i, new Bed(i));
        }
    }

    public void admitPatient(Patient p, int bedNumber) throws Exception {
        if (!beds.containsKey(bedNumber) || beds.get(bedNumber).isOccupied()) {
            throw new Exception("Bed is not available.");
        }
        patients.put(p.getId(), p);
        beds.get(bedNumber).setOccupied(true);
        System.out.println("Patient admitted: " + p);
    }

    public void dischargePatient(int patientId) {
        if (patients.containsKey(patientId)) {
            Patient patient = patients.get(patientId);
            patient.setDischargeDate(java.time.LocalDate.now().toString());
            patients.remove(patientId);
            for (Bed bed : beds.values()) {
                if (bed.isOccupied()) {
                    bed.setOccupied(false);
                    break;
                }
            }
            System.out.println("Patient discharged: " + patient);
        } else {
            System.out.println("Patient ID not found.");
        }
    }

    public void updatePatientDetails(int patientId, Patient updatedPatient) {
        if (patients.containsKey(patientId)) {
            patients.put(patientId, updatedPatient);
            System.out.println("Patient details updated: " + updatedPatient);
        } else {
            System.out.println("Patient ID not found.");
        }
    }

    public void searchPatient(String keyword) {
        for (Patient patient : patients.values()) {
            if (patient.getName().contains(keyword) || String.valueOf(patient.getId()).contains(keyword) ||
                patient.getDiagnosis().contains(keyword)) {
                System.out.println(patient);
            }
        }
    }

    public void assignBed(int patientId, int bedNumber) throws Exception {
        if (!patients.containsKey(patientId)) {
            throw new Exception("Patient ID not found.");
        }
        if (!beds.containsKey(bedNumber) || beds.get(bedNumber).isOccupied()) {
            throw new Exception("Bed is not available.");
        }
        beds.get(bedNumber).setOccupied(true);
        System.out.println("Bed assigned: " + beds.get(bedNumber));
    }

    public void displayBeds() {
        for (Bed bed : beds.values()) {
            System.out.println(bed);
        }
    }
}
