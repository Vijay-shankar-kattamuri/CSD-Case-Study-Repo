import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HospitalManager hospitalManager = new HospitalManager(10); // Assuming the hospital has 10 beds

        while (true) {
            System.out.println("                       * * * * * Hospital Management System * * * * *        ");
            System.out.println("1. Admit Patient");
            System.out.println("2. Discharge Patient");
            System.out.println("3. Update Patient Details");
            System.out.println("4. Search Patient");
            System.out.println("5. Assign Bed");
            System.out.println("6. Display Beds");
            System.out.println("7. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Patient ID: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Patient Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Patient Age: ");
                        int age = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Patient Gender: ");
                        String gender = scanner.nextLine();
                        System.out.print("Enter Diagnosis: ");
                        String diagnosis = scanner.nextLine();
                        System.out.print("Enter Treatment: ");
                        String treatment = scanner.nextLine();
                        System.out.print("Enter Admission Date (YYYY-MM-DD): ");
                        String admissionDate = scanner.nextLine();
                        System.out.print("Enter Bed Number: ");
                        int bedNumber = scanner.nextInt();

                        Patient patient = new Patient(id, name, age, gender, diagnosis, treatment, admissionDate);
                        hospitalManager.admitPatient(patient, bedNumber);
                        break;

                    case 2:
                        System.out.print("Enter Patient ID to discharge: ");
                        int dischargeId = scanner.nextInt();
                        hospitalManager.dischargePatient(dischargeId);
                        break;

                    case 3:
                        System.out.print("Enter Patient ID to update: ");
                        int updateId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter updated Patient Name: ");
                        String updatedName = scanner.nextLine();
                        System.out.print("Enter updated Patient Age: ");
                        int updatedAge = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter updated Patient Gender: ");
                        String updatedGender = scanner.nextLine();
                        System.out.print("Enter updated Diagnosis: ");
                        String updatedDiagnosis = scanner.nextLine();
                        System.out.print("Enter updated Treatment: ");
                        String updatedTreatment = scanner.nextLine();
                        System.out.print("Enter updated Admission Date (YYYY-MM-DD): ");
                        String updatedAdmissionDate = scanner.nextLine();
                        System.out.print("Enter updated Discharge Date (YYYY-MM-DD): ");
                        String updatedDischargeDate = scanner.nextLine();

                        Patient updatedPatient = new Patient(updateId, updatedName, updatedAge, updatedGender, updatedDiagnosis, updatedTreatment, updatedAdmissionDate);
                        updatedPatient.setDischargeDate(updatedDischargeDate);
                        hospitalManager.updatePatientDetails(updateId, updatedPatient);
                        break;

                    case 4:
                        System.out.print("Enter search patientId: ");
                        String keyword = scanner.nextLine();
                        hospitalManager.searchPatient(keyword);
                        break;

                    case 5:
                        System.out.print("Enter Patient ID to assign bed: ");
                        int assignId = scanner.nextInt();
                        System.out.print("Enter Bed Number to assign: ");
                        int assignBedNumber = scanner.nextInt();
                        hospitalManager.assignBed(assignId, assignBedNumber);
                        break;

                    case 6:
                        hospitalManager.displayBeds();
                        break;

                    case 7:
                        System.out.println("Exiting...");
                        scanner.close();
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
