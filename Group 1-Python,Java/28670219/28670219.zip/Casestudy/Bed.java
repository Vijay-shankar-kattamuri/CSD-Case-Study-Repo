public class Bed {
    private int bedNumber;
    private boolean occupied;

    public Bed(int bedNumber) {
        this.bedNumber = bedNumber;
        this.occupied = false;
    }

    // Getters and Setters

    public int getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(int bedNumber) {
        this.bedNumber = bedNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    @Override
    public String toString() {
        return "Bed Number: " + bedNumber + ", Occupied: " + occupied;
    }
}
