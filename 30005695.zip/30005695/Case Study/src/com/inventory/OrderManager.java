package com.inventory;

import java.sql.*;
import java.util.Scanner;

public class OrderManager {

    public void manageOrders(Scanner scanner) {
        while (true) {
            System.out.println("\nOrder Management");
            System.out.println("1. Place Order");
            System.out.println("2. View Order Details");
            System.out.println("3. Cancel Order");
            System.out.println("4. List Orders for a Product");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    placeOrder(scanner);
                    break;
                case 2:
                    viewOrderDetails(scanner);
                    break;
                case 3:
                    cancelOrder(scanner);
                    break;
                case 4:
                    listOrdersForProduct(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void placeOrder(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Enter supplier ID: ");
        int supplierId = scanner.nextInt();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();

        try (Connection conn = getConnection()) {
        	
            // Check if enough quantity is available
        	
        	
            String checkStockSql = "SELECT quantity_in_stock FROM Product WHERE product_id = ?";
            
            PreparedStatement checkStockStmt = conn.prepareStatement(checkStockSql);
            checkStockStmt.setInt(1, productId);
            ResultSet rs = checkStockStmt.executeQuery();
            
            if (rs.next()) {
                int currentStock = rs.getInt("quantity_in_stock");
                if (currentStock < quantity) {
                    System.out.println("Not enough stock available.");
                    return;
                }
            } 
            else {
                System.out.println("Product not found.");
                return;
            }

            // Place the order
            String sql = "INSERT INTO `Order` (product_id, supplier_id, order_date, quantity, status) VALUES (?, ?, CURDATE(), ?, 'placed')";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, productId);
            pstmt.setInt(2, supplierId);
            pstmt.setInt(3, quantity);
            pstmt.executeUpdate();

            // Update the stock
            String updateStockSql = "UPDATE Product SET quantity_in_stock = quantity_in_stock - ? WHERE product_id = ?";
            PreparedStatement updateStockStmt = conn.prepareStatement(updateStockSql);
            updateStockStmt.setInt(1, quantity);
            updateStockStmt.setInt(2, productId);
            updateStockStmt.executeUpdate();

            System.out.println("Order placed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void viewOrderDetails(Scanner scanner) {
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();

        try (Connection conn = getConnection()) {
            String sql = "SELECT * FROM `Order` WHERE order_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next())
            {
                System.out.println("Order ID: " + rs.getInt("order_id"));
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                System.out.println("Order Date: " + rs.getDate("order_date"));
                System.out.println("Quantity: " + rs.getInt("quantity"));
                System.out.println("Status: " + rs.getString("status"));
            } 
            else {
                System.out.println("Order not found.");
            }
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void cancelOrder(Scanner scanner) {
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();

        try (Connection conn = getConnection()) {
            // Check if the order exists and is placed
            String checkOrderSql = "SELECT * FROM `Order` WHERE order_id = ? AND status = 'placed'";
            PreparedStatement checkOrderStmt = conn.prepareStatement(checkOrderSql);
            checkOrderStmt.setInt(1, orderId);
            ResultSet rs = checkOrderStmt.executeQuery();
            if (rs.next())
            {
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");

                // Cancel the order
                String cancelOrderSql = "UPDATE `Order` SET status = 'canceled' WHERE order_id = ?";
                PreparedStatement cancelOrderStmt = conn.prepareStatement(cancelOrderSql);
                cancelOrderStmt.setInt(1, orderId);
                cancelOrderStmt.executeUpdate();

                // Update the stock
                String updateStockSql = "UPDATE Product SET quantity_in_stock = quantity_in_stock + ? WHERE product_id = ?";
                PreparedStatement updateStockStmt = conn.prepareStatement(updateStockSql);
                updateStockStmt.setInt(1, quantity);
                updateStockStmt.setInt(2, productId);
                updateStockStmt.executeUpdate();

                System.out.println("Order canceled successfully.");
            } 
            else 
            {
                System.out.println("Order not found or already canceled.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void listOrdersForProduct(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();

        try (Connection conn = getConnection()) {
            String sql = "SELECT * FROM `Order` WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println("Order ID: " + rs.getInt("order_id"));
                System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                System.out.println("Order Date: " + rs.getDate("order_date"));
                System.out.println("Quantity: " + rs.getInt("quantity"));
                System.out.println("Status: " + rs.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/retailstoredb";
        String user = "root";
        String password = "Amey@123";
        return DriverManager.getConnection(url, user, password);
    }
}
