package com.inventory;


import java.util.Scanner;

public class InventoryManagementSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductManager productManager = new ProductManager();
        SupplierManager supplierManager = new SupplierManager();
        OrderManager orderManager = new OrderManager();

        while (true) {
            System.out.println("\nInventory Management System");
            System.out.println("1. Manage Products");
            System.out.println("2. Manage Suppliers");
            System.out.println("3. Manage Orders");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    productManager.manageProducts(scanner);
                    break;
                case 2:
                    supplierManager.manageSuppliers(scanner);
                    break;
                case 3:
                    orderManager.manageOrders(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
