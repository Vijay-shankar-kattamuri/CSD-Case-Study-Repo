package com.inventory;

import java.sql.*;
import java.util.Scanner;

public class SupplierManager {

    public void manageSuppliers(Scanner scanner) {
        while (true) {
            System.out.println("\nSupplier Management");
            System.out.println("1. Add Supplier");
            System.out.println("2. View Supplier Details");
            System.out.println("3. Update Supplier");
            System.out.println("4. Delete Supplier");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addSupplier(scanner);
                    break;
                case 2:
                    viewSupplierDetails(scanner);
                    break;
                case 3:
                    updateSupplier(scanner);
                    break;
                case 4:
                    deleteSupplier(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void addSupplier(Scanner scanner) {
        System.out.print("Enter supplier name: ");
        String name = scanner.next();
        System.out.print("Enter contact information: ");
        String contactInfo = scanner.next();
        System.out.print("Enter address: ");
        String address = scanner.next();

        try (Connection conn = getConnection()) {
            String sql = "INSERT INTO Supplier (name, contact_information, address) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, contactInfo);
            pstmt.setString(3, address);
            pstmt.executeUpdate();
            System.out.println("Supplier added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void viewSupplierDetails(Scanner scanner) {
        System.out.print("Enter supplier ID: ");
        int supplierId = scanner.nextInt();

        try (Connection conn = getConnection()) {
            String sql = "SELECT * FROM Supplier WHERE supplier_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, supplierId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Contact Information: " + rs.getString("contact_information"));
                System.out.println("Address: " + rs.getString("address"));
            } else {
                System.out.println("Supplier not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateSupplier(Scanner scanner) {
        System.out.print("Enter supplier ID: ");
        int supplierId = scanner.nextInt();
        System.out.print("Enter new name: ");
        String name = scanner.next();
        System.out.print("Enter new contact information: ");
        String contactInfo = scanner.next();
        System.out.print("Enter new address: ");
        String address = scanner.next();

        try (Connection conn = getConnection()) {
            String sql = "UPDATE Supplier SET name = ?, contact_information = ?, address = ? WHERE supplier_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, contactInfo);
            pstmt.setString(3, address);
            pstmt.setInt(4, supplierId);
            pstmt.executeUpdate();
            System.out.println("Supplier updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteSupplier(Scanner scanner) {
        System.out.print("Enter supplier ID: ");
        int supplierId = scanner.nextInt();

        try (Connection conn = getConnection()) {
            String sql = "DELETE FROM Supplier WHERE supplier_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, supplierId);
            pstmt.executeUpdate();
            System.out.println("Supplier deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/retailstoredb";
        String user = "root";
        String password = "Amey@123";
        return DriverManager.getConnection(url, user, password);
    }
}