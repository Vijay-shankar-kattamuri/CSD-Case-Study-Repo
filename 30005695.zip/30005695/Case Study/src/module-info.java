/**
 * 
 */
/**
 * 
 */
module InventorySystem {
	requires java.sql;
}