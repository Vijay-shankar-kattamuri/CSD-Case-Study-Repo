package com.example.ecommerce;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;


import com.example.ecommerce.dao.CustomerDAO;
import com.example.ecommerce.dao.OrderDAO;
import com.example.ecommerce.dao.ProductDAO;
import com.example.ecommerce.model.Customer;
import com.example.ecommerce.model.Order;
import com.example.ecommerce.model.Product;


public class MainApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductDAO productDAO = new ProductDAO();
        CustomerDAO customerDAO = new CustomerDAO();
        OrderDAO orderDAO = new OrderDAO();

        while (true) {
            System.out.println("1. Add Product");
            System.out.println("2. View Product");
            System.out.println("3. List All Products");
            System.out.println("4. Update Product");
            System.out.println("5. Delete Product");
            System.out.println("6. Add Customer");
            System.out.println("7. View Customer");
            System.out.println("8. List All Customers");
            System.out.println("9. Update Customer");
            System.out.println("10. Delete Customer");
            System.out.println("11. Add Order");
            System.out.println("12. View Order");
            System.out.println("13. List All Orders");
            System.out.println("14. Update Order");
            System.out.println("15. Delete Order");
            System.out.println("16. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter product name: ");
                    String productName = scanner.next();
                    System.out.print("Enter product description: ");
                    String productDescription = scanner.next();
                    System.out.print("Enter product price: ");
                    double productPrice = scanner.nextDouble();
                    System.out.print("Enter product quantity: ");
                    int productQuantity = scanner.nextInt();
                    System.out.print("Enter product category: ");
                    String productCategory = scanner.next();
                    Product newProduct = new Product(0, productName, productDescription, productPrice, productQuantity, productCategory);
                    try {
                        productDAO.addProduct(newProduct);
                        System.out.println("Product added successfully!");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 2:
                    System.out.print("Enter product ID: ");
                    int productId = scanner.nextInt();
                    Product product = productDAO.viewProduct(productId);
                    if (product != null) {
                        System.out.println(product);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case 3:
                    List<Product> products = productDAO.selectAllProducts();
                    products.forEach(System.out::println);
                    break;
                case 4:
                    System.out.print("Enter product ID: ");
                    int updateProductId = scanner.nextInt();
                    System.out.print("Enter new product name: ");
                    String updateProductName = scanner.next();
                    System.out.print("Enter new product description: ");
                    String updateProductDescription = scanner.next();
                    System.out.print("Enter new product price: ");
                    double updateProductPrice = scanner.nextDouble();
                    System.out.print("Enter new product quantity: ");
                    int updateProductQuantity = scanner.nextInt();
                    System.out.print("Enter new product category: ");
                    String updateProductCategory = scanner.next();
                    Product updateProduct = new Product(updateProductId, updateProductName, updateProductDescription, updateProductPrice, updateProductQuantity, updateProductCategory);
                    try {
                        if (productDAO.updateProduct(updateProduct)) {
                            System.out.println("Product updated successfully!");
                        } else {
                            System.out.println("Product not found.");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 5:
                    System.out.print("Enter product ID to delete: ");
                    int deleteProductId = scanner.nextInt();
                    try {
                        if (productDAO.deleteProduct(deleteProductId)) {
                            System.out.println("Product deleted successfully!");
                        } else {
                            System.out.println("Product not found.");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 6:
                    System.out.print("Enter customer name: ");
                    String customerName = scanner.next();
                    System.out.print("Enter customer email: ");
                    String customerEmail = scanner.next();
                    System.out.print("Enter customer address: ");
                    String customerAddress = scanner.next();
                    System.out.print("Enter customer phone number: ");
                    String customerPhone = scanner.next();
                    Customer newCustomer = new Customer(0, customerName, customerEmail, customerAddress, customerPhone);
                    try {
                        customerDAO.addCustomer(newCustomer);
                        System.out.println("Customer added successfully!");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 7:
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    Customer customer = customerDAO.viewCustomer(customerId);
                    if (customer != null) {
                        System.out.println(customer);
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;
                case 8:
                    List<Customer> customers = customerDAO.selectAllCustomers();
                    customers.forEach(System.out::println);
                    break;
                case 9:
                    System.out.print("Enter customer ID: ");
                    int updateCustomerId = scanner.nextInt();
                    System.out.print("Enter new customer name: ");
                    String updateCustomerName = scanner.next();
                    System.out.print("Enter new customer email: ");
                    String updateCustomerEmail = scanner.next();
                    System.out.print("Enter new customer address: ");
                    String updateCustomerAddress = scanner.next();
                    System.out.print("Enter new customer phone number: ");
                    String updateCustomerPhone = scanner.next();
                    Customer updateCustomer = new Customer(updateCustomerId, updateCustomerName, updateCustomerEmail, updateCustomerAddress, updateCustomerPhone);
                    try {
                        if (customerDAO.updateCustomer(updateCustomer)) {
                            System.out.println("Customer updated successfully!");
                        } else {
                            System.out.println("Customer not found.");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 10:
                    System.out.print("Enter customer ID to delete: ");
                    int deleteCustomerId = scanner.nextInt();
                    try {
                        if (customerDAO.deleteCustomer(deleteCustomerId)) {
                            System.out.println("Customer deleted successfully!");
                        } else {
                            System.out.println("Customer not found.");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 11:
                    System.out.print("Enter customer ID: ");
                    int orderCustomerId = scanner.nextInt();
                    System.out.print("Enter product ID: ");
                    int orderProductId = scanner.nextInt();
                    System.out.print("Enter quantity: ");
                    int orderQuantity = scanner.nextInt();
                    System.out.print("Enter order date (YYYY-MM-DD): ");
                    String orderDateStr = scanner.next();
                    LocalDate orderDate = LocalDate.parse(orderDateStr);
                    System.out.print("Enter order status: ");
                    String orderStatus = scanner.next();
                    Order newOrder = new Order(0, orderCustomerId, orderProductId, orderQuantity, orderDate, orderStatus);
                    try {
                        orderDAO.addOrder(newOrder);
                        System.out.println("Order added successfully!");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 12:
                    System.out.print("Enter order ID: ");
                    int orderId = scanner.nextInt();
                    Order order = orderDAO.viewOrder(orderId);
                    if (order != null) {
                        System.out.println(order);
                    } else {
                        System.out.println("Order not found.");
                    }
                    break;
                case 13:
                    List<Order> orders = orderDAO.selectAllOrders();
                    orders.forEach(System.out::println);
                    break;
                case 14:
                    System.out.print("Enter order ID: ");
                    int updateOrderId = scanner.nextInt();
                    System.out.print("Enter new customer ID: ");
                    int updateOrderCustomerId = scanner.nextInt();
                    System.out.print("Enter new product ID: ");
                    int updateOrderProductId = scanner.nextInt();
                    System.out.print("Enter new quantity: ");
                    int updateOrderQuantity = scanner.nextInt();
                    System.out.print("Enter new order date (YYYY-MM-DD): ");
                    String updateOrderDateStr = scanner.next();
                    LocalDate updateOrderDate = LocalDate.parse(updateOrderDateStr);
                    System.out.print("Enter new order status: ");
                    String updateOrderStatus = scanner.next();
                    Order updateOrder = new Order(updateOrderId, updateOrderCustomerId, updateOrderProductId, updateOrderQuantity, updateOrderDate, updateOrderStatus);
                    try {
                        if (orderDAO.updateOrder(updateOrder)) {
                            System.out.println("Order updated successfully!");
                        } else {
                            System.out.println("Order not found.");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 15:
                    System.out.print("Enter order ID to delete: ");
                    int deleteOrderId = scanner.nextInt();
                    try {
                        if (orderDAO.deleteOrder(deleteOrderId)) {
                            System.out.println("Order deleted successfully!");
                        } else {
                            System.out.println("Order not found.");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 16:
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
