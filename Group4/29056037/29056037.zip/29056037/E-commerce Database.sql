create database ecommerce;
use ecommerce;

create table product(
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    quantity_available INT NOT NULL,
    category VARCHAR(50)
);

create table customer(
customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    phone_number VARCHAR(15) NOT NULL
);

CREATE TABLE Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);

insert into product(name,description,price,quantity_available,category)
values
('Laptop', 'High-performance laptop with SSD storage', 1200.00, 10, 'Electronics'),
    ('Smartphone', 'Latest model with dual cameras', 800.00, 15, 'Electronics'),
    ('Headphones', 'Noise-canceling wireless headphones', 150.00, 20, 'Electronics'),
    ('Desk Lamp', 'Adjustable LED desk lamp with touch control', 35.99, 25, 'Home & Office'),
    ('Backpack', 'Waterproof laptop backpack with USB charging port', 49.99, 30, 'Fashion & Accessories');

insert into customer(name,email,address,phone_number)
values
('John', 'john.doe@example.com', 'Hinjwadi phase-1,pune', '+123456789'),
('Jack', 'jane.smith@example.com', 'Deccan,Gymkhana,pune', '7798691302'),
('Justin', 'justin262@example.com','Malbaar Hill,Mumbai',  '8923415670');

INSERT INTO orders (customer_id, product_id, quantity, status)
VALUES
    (1, 1, 2, 'Pending'),   
    (2, 3, 1, 'Pending'),   
    (3, 2, 1, 'Pending');   
