CREATE DATABASE ecommerce;

USE ecommerce;

CREATE TABLE Product (
    product_id INT AUTO_INCREMENT PRIMARY KEY,sys_config
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    quantity_available INT NOT NULL,
    category VARCHAR(50)
);

CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    address TEXT,
    phone_number VARCHAR(15)
);

CREATE TABLE Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);

USE ecommerce;

-- Insert values into the Product table
INSERT INTO Product (name, description, price, quantity_available, category) VALUES
('Laptop', 'A high-performance laptop', 999.99, 10, 'Electronics'),
('Smartphone', 'Latest model smartphone', 699.99, 20, 'Electronics'),
('Headphones', 'Noise-cancelling headphones', 199.99, 15, 'Accessories'),
('Book', 'A bestseller book', 19.99, 50, 'Books'),
('Coffee Maker', 'Automatic coffee maker', 49.99, 25, 'Home Appliances');

-- Insert values into the Customer table
INSERT INTO Customer (name, email, address, phone_number) VALUES
('John Doe', 'john.doe@example.com', '123 Elm Street', '123-456-7890'),
('Jane Smith', 'jane.smith@example.com', '456 Oak Street', '234-567-8901'),
('Michael Brown', 'michael.brown@example.com', '789 Pine Street', '345-678-9012'),
('Emily Davis', 'emily.davis@example.com', '101 Maple Avenue', '456-789-0123'),
('Sarah Wilson', 'sarah.wilson@example.com', '202 Birch Lane', '567-890-1234');

-- Insert values into the Orders table
INSERT INTO Orders (customer_id, product_id, quantity, status) VALUES
(1, 1, 1, 'Processing'),
(2, 2, 2, 'Shipped'),
(3, 3, 1, 'Delivered'),
(4, 4, 5, 'Cancelled'),
(5, 5, 1, 'Processing');

select * from Orders;
select * from product;
select * from customer;