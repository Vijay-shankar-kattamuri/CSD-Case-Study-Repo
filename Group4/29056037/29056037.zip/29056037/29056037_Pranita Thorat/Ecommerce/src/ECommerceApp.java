import java.sql.*;
import java.util.Scanner;

public class ECommerceApp {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Manage Products");
            System.out.println("2. Manage Customers");
            System.out.println("3. Manage Orders");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageProducts();
                    break;
                case 2:
                    manageCustomers();
                    break;
                case 3:
                    manageOrders();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void manageProducts() {
        while (true) {
            System.out.println("1. Add Product");
            System.out.println("2. View Product");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    viewProduct();
                    break;
                case 3:
                    updateProduct();
                    break;
                case 4:
                    deleteProduct();
                    break;
                case 5:
                    return; // Go back to main menu
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void manageCustomers() {
        while (true) {
            System.out.println("1. Register Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    registerCustomer();
                    break;
                case 2:
                    viewCustomer();
                    break;
                case 3:
                    updateCustomer();
                    break;
                case 4:
                    deleteCustomer();
                    break;
                case 5:
                    return; // Go back to main menu
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void manageOrders() {
        while (true) {
            System.out.println("1. Place Order");
            System.out.println("2. View Order");
            System.out.println("3. Update Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    placeOrder();
                    break;
                case 2:
                    viewOrder();
                    break;
                case 3:
                    updateOrder();
                    break;
                case 4:
                    cancelOrder();
                    break;
                case 5:
                    return; // Go back to main menu
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // Product Methods
    private static void addProduct() {
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product description: ");
        String description = scanner.nextLine();
        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter quantity available: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter product category: ");
        String category = scanner.nextLine();

        String query = "INSERT INTO Product (name, description, price, quantity_available, category) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setDouble(3, price);
            stmt.setInt(4, quantity);
            stmt.setString(5, category);
            stmt.executeUpdate();
            System.out.println("Product added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding product: " + e.getMessage());
        }
    }

    private static void viewProduct() {
        System.out.print("Enter product ID to view: ");
        int productId = scanner.nextInt();

        String query = "SELECT * FROM Product WHERE product_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Quantity Available: " + rs.getInt("quantity_available"));
                System.out.println("Category: " + rs.getString("category"));
            } else {
                System.out.println("Product not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing product: " + e.getMessage());
        }
    }

    private static void updateProduct() {
        System.out.print("Enter product ID to update: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new product name (or leave blank to keep current): ");
        String name = scanner.nextLine();
        System.out.print("Enter new product description (or leave blank to keep current): ");
        String description = scanner.nextLine();
        System.out.print("Enter new product price (or enter -1 to keep current): ");
        double price = scanner.nextDouble();
        System.out.print("Enter new quantity available (or enter -1 to keep current): ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new product category (or leave blank to keep current): ");
        String category = scanner.nextLine();

        String query = "UPDATE Product SET name = COALESCE(NULLIF(?, name), name), " +
                       "description = COALESCE(NULLIF(?, description), description), " +
                       "price = COALESCE(NULLIF(?, price), price), " +
                       "quantity_available = COALESCE(NULLIF(?, quantity_available), quantity_available), " +
                       "category = COALESCE(NULLIF(?, category), category) " +
                       "WHERE product_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name.isEmpty() ? null : name);
            stmt.setString(2, description.isEmpty() ? null : description);
            stmt.setDouble(3, price == -1 ? null : price);
            stmt.setInt(4, quantity == -1 ? null : quantity);
            stmt.setString(5, category.isEmpty() ? null : category);
            stmt.setInt(6, productId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Product updated successfully.");
            } else {
                System.out.println("Product not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating product: " + e.getMessage());
        }
    }

    private static void deleteProduct() {
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();

        String query = "DELETE FROM Product WHERE product_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, productId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Product deleted successfully.");
            } else {
                System.out.println("Product not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting product: " + e.getMessage());
        }
    }

    // Customer Methods
    private static void registerCustomer() {
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();
        System.out.print("Enter customer phone number: ");
        String phoneNumber = scanner.nextLine();

        String query = "INSERT INTO Customer (name, email, address, phone_number) VALUES (?, ?, ?, ?)";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, address);
            stmt.setString(4, phoneNumber);
            stmt.executeUpdate();
            System.out.println("Customer registered successfully.");
        } catch (SQLException e) {
            System.out.println("Error registering customer: " + e.getMessage());
        }
    }

    private static void viewCustomer() {
        System.out.print("Enter customer ID to view: ");
        int customerId = scanner.nextInt();

        String query = "SELECT * FROM Customer WHERE customer_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Address: " + rs.getString("address"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing customer: " + e.getMessage());
        }
    }

    private static void updateCustomer() {
        System.out.print("Enter customer ID to update: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new customer name (or leave blank to keep current): ");
        String name = scanner.nextLine();
        System.out.print("Enter new customer email (or leave blank to keep current): ");
        String email = scanner.nextLine();
        System.out.print("Enter new customer address (or leave blank to keep current): ");
        String address = scanner.nextLine();
        System.out.print("Enter new customer phone number (or leave blank to keep current): ");
        String phoneNumber = scanner.nextLine();

        String query = "UPDATE Customer SET name = COALESCE(NULLIF(?, name), name), " +
                       "email = COALESCE(NULLIF(?, email), email), " +
                       "address = COALESCE(NULLIF(?, address), address), " +
                       "phone_number = COALESCE(NULLIF(?, phone_number), phone_number) " +
                       "WHERE customer_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name.isEmpty() ? null : name);
            stmt.setString(2, email.isEmpty() ? null : email);
            stmt.setString(3, address.isEmpty() ? null : address);
            stmt.setString(4, phoneNumber.isEmpty() ? null : phoneNumber);
            stmt.setInt(5, customerId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer updated successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating customer: " + e.getMessage());
        }
    }

    private static void deleteCustomer() {
        System.out.print("Enter customer ID to delete: ");
        int customerId = scanner.nextInt();

        String query = "DELETE FROM Customer WHERE customer_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting customer: " + e.getMessage());
        }
    }

    // Order Methods
    private static void placeOrder() {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "INSERT INTO Order (customer_id, product_id, quantity, order_date, status) " +
                       "VALUES (?, ?, ?, NOW(), 'Pending')";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            stmt.setInt(2, productId);
            stmt.setInt(3, quantity);
            stmt.executeUpdate();
            System.out.println("Order placed successfully.");
        } catch (SQLException e) {
            System.out.println("Error placing order: " + e.getMessage());
        }
    }

    private static void viewOrder() {
        System.out.print("Enter order ID to view: ");
        int orderId = scanner.nextInt();

        String query = "SELECT * FROM Order WHERE order_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Order ID: " + rs.getInt("order_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Quantity: " + rs.getInt("quantity"));
                System.out.println("Order Date: " + rs.getTimestamp("order_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Order not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing order: " + e.getMessage());
        }
    }

    private static void updateOrder() {
        System.out.print("Enter order ID to update: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new status (or leave blank to keep current): ");
        String status = scanner.nextLine();

        String query = "UPDATE Order SET status = COALESCE(NULLIF(?, status), status) WHERE order_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, status.isEmpty() ? null : status);
            stmt.setInt(2, orderId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Order updated successfully.");
            } else {
                System.out.println("Order not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating order: " + e.getMessage());
        }
    }

    private static void cancelOrder() {
        System.out.print("Enter order ID to cancel: ");
        int orderId = scanner.nextInt();

        String query = "UPDATE Order SET status = 'Cancelled' WHERE order_id = ?";

        try (Connection conn = DataConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Order cancelled successfully.");
            } else {
                System.out.println("Order not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error cancelling order: " + e.getMessage());
        }
    }
}