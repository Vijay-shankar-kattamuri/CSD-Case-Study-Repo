-- Create the database
CREATE DATABASE employee_management;

-- Use the created database
USE employee_management;

-- Create Employee table
DROP TABLE IF EXISTS Employee;

CREATE TABLE Employee (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    position VARCHAR(50)
);

-- Create Shift table
CREATE TABLE Shift (
    shift_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT,
    shift_date DATE,
    start_time TIME,
    end_time TIME,
    FOREIGN KEY (employee_id) REFERENCES Employee(employee_id)
);

-- Create Salary table
CREATE TABLE Salary (
    salary_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT,
    salary_amount DECIMAL(10, 2),
    payment_date DATE,
    FOREIGN KEY (employee_id) REFERENCES Employee(employee_id)
);

-- Insert sample employees into Employee table
INSERT INTO Employee (name, email, phone, position)
VALUES
('John Doe', 'john.doe@example.com', '555-1234', 'Software Engineer'),
('Jane Smith', 'jane.smith@example.com', '555-5678', 'Project Manager'),
('Emily Davis', 'emily.davis@example.com', '555-8765', 'Designer');

-- Insert sample shifts into Shift table
INSERT INTO Shift (employee_id, shift_date, start_time, end_time)
VALUES
(1, '2024-07-21', '09:00:00', '17:00:00'), -- John Doe's shift
(2, '2024-07-21', '10:00:00', '18:00:00'), -- Jane Smith's shift
(3, '2024-07-21', '11:00:00', '19:00:00'); -- Emily Davis's shift

-- Insert sample salaries into Salary table
INSERT INTO Salary (employee_id, salary_amount, payment_date)
VALUES
(1, 7500.00, '2024-07-15'), -- Salary for John Doe
(2, 8500.00, '2024-07-15'), -- Salary for Jane Smith
(3, 6500.00, '2024-07-15'); -- Salary for Emily Davis

select * from Employee;


