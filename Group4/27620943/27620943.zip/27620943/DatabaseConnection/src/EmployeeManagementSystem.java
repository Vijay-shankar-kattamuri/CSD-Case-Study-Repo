import java.sql.*;
import java.util.Scanner;

public class EmployeeManagementSystem {

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nEmployee Management System");
            System.out.println("1. Add Employee");
            System.out.println("2. View Employee");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Assign Shift");
            System.out.println("6. View Shift");
            System.out.println("7. Update Shift");
            System.out.println("8. Delete Shift");
            System.out.println("9. Set Salary");
            System.out.println("10. View Salary");
            System.out.println("11. Update Salary");
            System.out.println("12. Delete Salary");
            System.out.println("13. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1: addEmployee(); break;
                case 2: viewEmployee(); break;
                case 3: updateEmployee(); break;
                case 4: deleteEmployee(); break;
                case 5: assignShift(); break;
                case 6: viewShift(); break;
                case 7: updateShift(); break;
                case 8: deleteShift(); break;
                case 9: setSalary(); break;
                case 10: viewSalary(); break;
                case 11: updateSalary(); break;
                case 12: deleteSalary(); break;
                case 13: System.exit(0); break;
                default: System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addEmployee() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter position: ");
        String position = scanner.nextLine();

        String sql = "INSERT INTO Employee (name, email, phone, position) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.setString(4, position);

            pstmt.executeUpdate();
            System.out.println("Employee added successfully.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewEmployee() {
        System.out.print("Enter employee ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        String sql = "SELECT * FROM Employee WHERE employee_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("ID: " + rs.getInt("employee_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone: " + rs.getString("phone"));
                System.out.println("Position: " + rs.getString("position"));
            } else {
                System.out.println("Employee not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateEmployee() {
        System.out.print("Enter employee ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter new position: ");
        String position = scanner.nextLine();

        String sql = "UPDATE Employee SET name = ?, email = ?, phone = ?, position = ? WHERE employee_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.setString(4, position);
            pstmt.setInt(5, id);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee updated successfully.");
            } else {
                System.out.println("Employee not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteEmployee() {
        System.out.print("Enter employee ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        String sql = "DELETE FROM Employee WHERE employee_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee deleted successfully.");
            } else {
                System.out.println("Employee not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void assignShift() {
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter shift date (YYYY-MM-DD): ");
        String shiftDate = scanner.nextLine();

        System.out.print("Enter start time (HH:MM:SS): ");
        String startTime = scanner.nextLine();

        System.out.print("Enter end time (HH:MM:SS): ");
        String endTime = scanner.nextLine();

        String sql = "INSERT INTO Shift (employee_id, shift_date, start_time, end_time) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, employeeId);
            pstmt.setDate(2, Date.valueOf(shiftDate));
            pstmt.setTime(3, Time.valueOf(startTime));
            pstmt.setTime(4, Time.valueOf(endTime));

            pstmt.executeUpdate();
            System.out.println("Shift assigned successfully.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewShift() {
        System.out.print("Enter shift ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        String sql = "SELECT * FROM Shift WHERE shift_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Shift ID: " + rs.getInt("shift_id"));
                System.out.println("Employee ID: " + rs.getInt("employee_id"));
                System.out.println("Shift Date: " + rs.getDate("shift_date"));
                System.out.println("Start Time: " + rs.getTime("start_time"));
                System.out.println("End Time: " + rs.getTime("end_time"));
            } else {
                System.out.println("Shift not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateShift() {
        System.out.print("Enter shift ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new shift date (YYYY-MM-DD): ");
        String shiftDate = scanner.nextLine();

        System.out.print("Enter new start time (HH:MM:SS): ");
        String startTime = scanner.nextLine();

        System.out.print("Enter new end time (HH:MM:SS): ");
        String endTime = scanner.nextLine();

        String sql = "UPDATE Shift SET employee_id = ?, shift_date = ?, start_time = ?, end_time = ? WHERE shift_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, employeeId);
            pstmt.setDate(2, Date.valueOf(shiftDate));
            pstmt.setTime(3, Time.valueOf(startTime));
            pstmt.setTime(4, Time.valueOf(endTime));
            pstmt.setInt(5, id);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Shift updated successfully.");
            } else {
                System.out.println("Shift not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteShift() {
        System.out.print("Enter shift ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        String sql = "DELETE FROM Shift WHERE shift_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Shift deleted successfully.");
            } else {
                System.out.println("Shift not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void setSalary() {
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter salary amount: ");
        double salaryAmount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter payment date (YYYY-MM-DD): ");
        String paymentDate = scanner.nextLine();

        String sql = "INSERT INTO Salary (employee_id, salary_amount, payment_date) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, employeeId);
            pstmt.setDouble(2, salaryAmount);
            pstmt.setDate(3, Date.valueOf(paymentDate));

            pstmt.executeUpdate();
            System.out.println("Salary set successfully.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewSalary() {
        System.out.print("Enter salary ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        String sql = "SELECT * FROM Salary WHERE salary_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Salary ID: " + rs.getInt("salary_id"));
                System.out.println("Employee ID: " + rs.getInt("employee_id"));
                System.out.println("Salary Amount: " + rs.getDouble("salary_amount"));
                System.out.println("Payment Date: " + rs.getDate("payment_date"));
            } else {
                System.out.println("Salary not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateSalary() {
        System.out.print("Enter salary ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new salary amount: ");
        double salaryAmount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new payment date (YYYY-MM-DD): ");
        String paymentDate = scanner.nextLine();

        String sql = "UPDATE Salary SET employee_id = ?, salary_amount = ?, payment_date = ? WHERE salary_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, employeeId);
            pstmt.setDouble(2, salaryAmount);
            pstmt.setDate(3, Date.valueOf(paymentDate));
            pstmt.setInt(4, id);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Salary updated successfully.");
            } else {
                System.out.println("Salary not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteSalary() {
        System.out.print("Enter salary ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        String sql = "DELETE FROM Salary WHERE salary_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Salary deleted successfully.");
            } else {
                System.out.println("Salary not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
