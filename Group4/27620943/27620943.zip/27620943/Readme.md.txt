# Employee Management System

## Overview

The Employee Management System is a console-based Java application that allows users to manage employee records, shifts, and salaries in a retail business. This project demonstrates proficiency in Core Java, MySQL, and JDBC.

## Features

- **Employee Management:**
  - Add a new employee
  - View employee details
  - Update employee information
  - Delete an employee

- **Shift Management:**
  - Assign a shift to an employee
  - View shift details
  - Update shift information
  - Delete a shift

- **Salary Management:**
  - Set a salary for an employee
  - View salary details
  - Update salary information
  - Delete a salary record

## Prerequisites

- Java Development Kit (JDK) 8 or higher
- MySQL Server
- MySQL Workbench or any other MySQL client
- MySQL JDBC Driver (`mysql-connector-java-x.x.xx.jar`)

## Database Setup

1. **Create the Database:**

    ```sql
    CREATE DATABASE employee_management;
    ```

2. **Create the Tables:**

    ```sql
    USE employee_management;

    CREATE TABLE Employee (
        employee_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        email VARCHAR(100),
        phone VARCHAR(15),
        position VARCHAR(50)
    );

    CREATE TABLE Shift (
        shift_id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT,
        shift_date DATE,
        start_time TIME,
        end_time TIME,
        FOREIGN KEY (employee_id) REFERENCES Employee(employee_id)
    );

    CREATE TABLE Salary (
        salary_id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT,
        salary_amount DOUBLE,
        payment_date DATE,
        FOREIGN KEY (employee_id) REFERENCES Employee(employee_id)
    );
    ```

## Configuration

1. **Database Connection:**

    Update the `DatabaseConnection.java` file with your MySQL database connection details:

    ```java
    private static final String URL = "jdbc:mysql://localhost:3306/employee_management";
    private static final String USER = "your_mysql_username";
    private static final String PASSWORD = "your_mysql_password";
    ```

## Usage

1. **Compile the Application:**

    ```sh
    javac EmployeeManagementSystem.java
    ```

2. **Run the Application:**

    ```sh
    java EmployeeManagementSystem
    ```

3. **Follow the On-Screen Menu:**

    Use the on-screen menu to add, view, update, and delete employee records, shifts, and salaries.

## Example

```plaintext
Employee Management System
1. Add Employee
2. View Employee
3. Update Employee
4. Delete Employee
5. Assign Shift
6. View Shift
7. Update Shift
8. Delete Shift
9. Set Salary
10. View Salary
11. Update Salary
12. Delete Salary
13. Exit
Choose an option: 1

Enter name: John Doe
Enter email: john.doe@example.com
Enter phone: 1234567890
Enter position: Sales Manager
Employee added successfully.
