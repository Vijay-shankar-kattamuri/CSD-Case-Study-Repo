package event_package;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Default_package.DBConnection;
import event_package.Event;

public class EventData {
    public void addEvent(Event event) throws SQLException {
        String query = "INSERT INTO event (name, date, location, description, capacity) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, event.getName());
            statement.setDate(2, Date.valueOf(event.getDate()));
            statement.setString(3, event.getLocation());
            statement.setString(4, event.getDescription());
            statement.setInt(5, event.getCapacity());
            statement.executeUpdate();
        }
    }

    public Event getEvent(int eventId) throws SQLException {
        String query = "SELECT * FROM event WHERE event_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, eventId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Event(
                            resultSet.getInt("event_id"),
                            resultSet.getString("name"),
                            resultSet.getDate("date").toString(),
                            resultSet.getString("location"),
                            resultSet.getString("description"),
                            resultSet.getInt("capacity")
                    );
                }
            }
        }
        return null;
    }

    public void updateEvent(Event event) throws SQLException {
        String query = "UPDATE event SET name = ?, date = ?, location = ?, description = ?, capacity = ? WHERE event_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, event.getName());
            statement.setDate(2, Date.valueOf(event.getDate()));
            statement.setString(3, event.getLocation());
            statement.setString(4, event.getDescription());
            statement.setInt(5, event.getCapacity());
            statement.setInt(6, event.getEventId());
            statement.executeUpdate();
        }
    }

    public void deleteEvent(int eventId) throws SQLException {
        String query = "DELETE FROM event WHERE event_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, eventId);
            statement.executeUpdate();
        }
    }

    public List<Event> getAllEvents() throws SQLException {
        List<Event> events = new ArrayList<>();
        String query = "SELECT * FROM event";
        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                events.add(new Event(
                        resultSet.getInt("event_id"),
                        resultSet.getString("name"),
                        resultSet.getDate("date").toString(),
                        resultSet.getString("location"),
                        resultSet.getString("description"),
                        resultSet.getInt("capacity")
                ));
            }
        }
        return events;
    }
}
