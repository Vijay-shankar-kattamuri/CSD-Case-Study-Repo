package registration_package;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RegistrationData {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/event_management";
    private static final String USER = "captain";
    private static final String PASS = "captain@1234";

    public void registerParticipant(Registration registration) throws SQLException {
        String sql = "INSERT INTO registration (event_id, participant_id, registration_date, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, registration.getEventId());
            stmt.setInt(2, registration.getParticipantId());
            stmt.setString(3, registration.getRegistrationDate());
            stmt.setString(4, registration.getStatus());
            stmt.executeUpdate();
            updateEventCapacity(registration.getEventId(), -1);
        }
    }

    public Registration getRegistration(int id) throws SQLException {
        String sql = "SELECT * FROM registration WHERE registration_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Registration(
                            rs.getInt("registration_id"),
                            rs.getInt("event_id"),
                            rs.getInt("participant_id"),
                            rs.getString("registration_date"),
                            rs.getString("status")
                    );
                }
            }
        }
        return null;
    }

    public void updateRegistration(Registration registration) throws SQLException {
        String sql = "UPDATE registration SET event_id = ?, participant_id = ?, registration_date = ?, status = ? WHERE registration_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, registration.getEventId());
            stmt.setInt(2, registration.getParticipantId());
            stmt.setString(3, registration.getRegistrationDate());
            stmt.setString(4, registration.getStatus());
            stmt.setInt(5, registration.getRegistrationId());
            stmt.executeUpdate();
        }
    }

    public void cancelRegistration(int id) throws SQLException {
        String sql = "DELETE FROM registration WHERE registration_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            Registration registration = getRegistration(id);
            if (registration != null) {
                updateEventCapacity(registration.getEventId(), 1);
            }
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public List<Registration> getAllRegistrations() throws SQLException {
        List<Registration> registrations = new ArrayList<>();
        String sql = "SELECT * FROM registration";  // Adjust the SQL query based on your database schema

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("registration_id");
                int eventId = rs.getInt("event_id");
                int participantId = rs.getInt("participant_id");
                String registrationDate = rs.getString("registration_date");
                String status = rs.getString("status");

                Registration registration = new Registration(id, eventId, participantId, registrationDate, status);
                registrations.add(registration);
            }
        }

        return registrations;
    }

    private void updateEventCapacity(int eventId, int capacityChange) throws SQLException {
        String sql = "UPDATE event SET capacity = capacity + ? WHERE event_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, capacityChange);
            stmt.setInt(2, eventId);
            stmt.executeUpdate();
        }
    }
    
    public int getEventCapacity(int eventId) throws SQLException {
        String sql = "SELECT capacity FROM event WHERE event_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, eventId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("capacity");
                }
            }
        }
        return -1;  
    }

}
