##Blood Bank Management System Group 4(Case Study no. 14)


#Overview

This is a menu-based console application developed in Core Java using JDBC to interact with a MySQL database. The application simulates a blood bank management system, allowing users to manage blood donations, inventory, and requests.

## Functionalities
- *Donor Management:*
  - Add new donors to the system
  - View donor details
  - Update donor information
  - Delete donors

- *Inventory Management:*
  - Add blood donations to the inventory
  - View blood inventory details
  - Update inventory information
  - Delete blood inventory records

- *Request Management:*
  - Register blood requests
  - View request details
  - Update request status
  - Delete requests


## Setup and Usage
1. *Setup MySQL Database:*

     1. Install MySQL server

   - Create a database named NewBloodBankDbase and set up the tables using the following SQL commands:

     
     CREATE DATABASE BloodBankDbase2;
     USE BloodBankDase2;

     CREATE TABLE Donor (
         donor_id INT AUTO_INCREMENT PRIMARY KEY,
         donor_name VARCHAR(255),
         blood_group VARCHAR(10),
         contact_number VARCHAR(20),
         email VARCHAR(255),
         last_donation_date DATE
     );

     CREATE TABLE Inventory (
         donation_id INT AUTO_INCREMENT PRIMARY KEY,
         donor_id INT,
         donation_date DATE,
         blood_group VARCHAR(10),
         quantity INT,
         expiry_date DATE,
         FOREIGN KEY (donor_id) REFERENCES Donor(donor_id)
     );

     CREATE TABLE Request (
         request_id INT AUTO_INCREMENT PRIMARY KEY,
         requester_name VARCHAR(255),
         blood_group_requested VARCHAR(10),
         request_date DATE,
         request_status VARCHAR(20)
     );
     

2. *Configure the Java Application:*
   - Install latest jdk
   - Install the *MySQL Connector/J* JDBC driver.
   - Create a new Java project in IDE (Eclipse) and add the JDBC driver to project's build path.

3. *Update Database Connection Details:*
   - Open BloodBankManagementSystem.java.
   - Update the database connection details with MySQL credentials:

     java
     private static final String URL = "jdbc:mysql://localhost:3306/BloodBankDbase2";
     private static final String USER = "root";
     private static final String PASSWORD = "pass"; //  MySQL root password
     

4. *Run the Application:*
   - Compile and run bloodbank.java as a Java application.
   - Follow the on-screen menu to manage donors, inventory, and requests.

5. *Project Structure*.

      BloodBankManagementSystem/
├── lib/
│   └── mysql-connector-java-j-9.0.0.jar
├── src/
│   └── bloodbabk.java
├── sql/
│   └── database_setup.sql
└── README.md
