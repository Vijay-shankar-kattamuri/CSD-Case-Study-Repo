CREATE DATABASE BloodBankDbase2;

USE BloodBankDbase2;

CREATE TABLE Donor (
    donor_id INT PRIMARY KEY AUTO_INCREMENT,
    donor_name VARCHAR(100),
    blood_group VARCHAR(10),
    contact_number VARCHAR(15),
    email VARCHAR(100),
    last_donation_date DATE
);

CREATE TABLE Inventory (
    donation_id INT PRIMARY KEY AUTO_INCREMENT,
    donor_id INT,
    donation_date DATE,
    blood_group VARCHAR(10),
    quantity INT,
    expiry_date DATE,
    FOREIGN KEY (donor_id) REFERENCES Donor(donor_id)
);

CREATE TABLE Request (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    requester_name VARCHAR(100),
    blood_group_requested VARCHAR(10),
    request_date DATE,
    request_status VARCHAR(20)
);
 USE BloodBankDbase2;
INSERT INTO Donor (donor_name, blood_group, contact_number, email, last_donation_date) VALUES
('Amit', 'O+', '1234567890', 'amit@example.com', '2024-07-01'),
('Smith', 'A-', '0987654321', 'smith@example.com', '2024-06-15'),
('Neyaz', 'B+', '5555555555', 'neyaz@example.com', '2024-05-10');

INSERT INTO Inventory (donor_id, donation_date, blood_group, quantity, expiry_date) VALUES
(1, '2024-07-01', 'O+', 3, '2024-10-01'),
(2, '2024-06-15', 'A-', 2, '2024-09-15'),
(3, '2024-05-10', 'B+', 1, '2024-08-10');

INSERT INTO Request (requester_name, blood_group_requested, request_date, request_status) VALUES
('Rahul', 'O+', '2024-07-10', 'Pending'),
('Raj', 'A-', '2024-07-11', 'Fulfilled'),
('Aman', 'B+', '2024-07-12', 'Cancelled');
select * from Donor;
select * from Inventory;
select * from Request;