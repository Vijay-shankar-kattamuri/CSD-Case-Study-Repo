package bloodbank;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class bloodbank {

    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/BloodBankDbase2";
    private static final String USER = "root";
    private static final String PASSWORD = "Neyaz1806@"; 

    private static Connection conn;

    public static void main(String[] args) {
    	 
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to the database.");
           
               
                // Display menu and process user input
         

            Scanner scanner = new Scanner(System.in);

            while (true) {
                // Main menu
                System.out.println("Blood Bank Management System");
                System.out.println("1. Donor Management");
                System.out.println("2. Inventory Management");
                System.out.println("3. Request Management");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        donorManagement(scanner);
                        break;
                    case 2:
                        inventoryManagement(scanner);
                        break;
                    case 3:
                        requestManagement(scanner);
                        break;
                    case 4:
                        conn.close();
                        System.out.println("Disconnected from the database.");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
   

    // Donor management menu
    private static void donorManagement(Scanner scanner) {
        System.out.println("Donor Management");
        System.out.println("1. Add New Donor");
        System.out.println("2. View Donor Details");
        System.out.println("3. Update Donor Information");
        System.out.println("4. Delete Donor");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                addNewDonor(scanner);
                break;
            case 2:
                viewDonorDetails(scanner);
                break;
            case 3:
                updateDonorInformation(scanner);
                break;
            case 4:
                deleteDonor(scanner);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    // Inventory management menu
    private static void inventoryManagement(Scanner scanner) {
        System.out.println("Inventory Management");
        System.out.println("1. Add Blood Donation");
        System.out.println("2. View Inventory Details");
        System.out.println("3. Update Inventory Information");
        System.out.println("4. Delete Inventory Record");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                addBloodDonation(scanner);
                break;
            case 2:
                viewInventoryDetails(scanner);
                break;
            case 3:
                updateInventoryInformation(scanner);
                break;
            case 4:
                deleteInventoryRecord(scanner);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    // Request management menu
    private static void requestManagement(Scanner scanner) {
        System.out.println("Request Management");
        System.out.println("1. Register Blood Request");
        System.out.println("2. View Request Details");
        System.out.println("3. Update Request Status");
        System.out.println("4. Delete Request");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                registerBloodRequest(scanner);
                break;
            case 2:
                viewRequestDetails(scanner);
                break;
            case 3:
                updateRequestStatus(scanner);
                break;
            case 4:
                deleteRequest(scanner);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    // Method to add a new donor
    private static void addNewDonor(Scanner scanner) {
        System.out.print("Enter donor name: ");
        String name = scanner.nextLine();
        System.out.print("Enter blood group: ");
        String bloodGroup = scanner.nextLine();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter last donation date (YYYY-MM-DD): ");
        String lastDonationDate = scanner.nextLine();

        String query = "INSERT INTO Donor (donor_name, blood_group, contact_number, email, last_donation_date) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, bloodGroup);
            stmt.setString(3, contactNumber);
            stmt.setString(4, email);
            stmt.setDate(5, Date.valueOf(lastDonationDate));
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Donor added successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to view donor details
    private static void viewDonorDetails(Scanner scanner) {
        System.out.print("Enter donor ID: ");
        int donorId = scanner.nextInt();
        scanner.nextLine();

        String query = "SELECT * FROM Donor WHERE donor_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, donorId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                System.out.println("Donor ID: " + rs.getInt("donor_id"));
                System.out.println("Name: " + rs.getString("donor_name"));
                System.out.println("Blood Group: " + rs.getString("blood_group"));
                System.out.println("Contact Number: " + rs.getString("contact_number"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Last Donation Date: " + rs.getDate("last_donation_date"));
            } else {
                System.out.println("No donor found with ID: " + donorId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update donor information
    private static void updateDonorInformation(Scanner scanner) {
        System.out.print("Enter donor ID to update: ");
        int donorId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new donor name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new blood group: ");
        String bloodGroup = scanner.nextLine();
        System.out.print("Enter new contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new last donation date (YYYY-MM-DD): ");
        String lastDonationDate = scanner.nextLine();

        String query = "UPDATE Donor SET donor_name = ?, blood_group = ?, contact_number = ?, email = ?, last_donation_date = ? WHERE donor_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, bloodGroup);
            stmt.setString(3, contactNumber);
            stmt.setString(4, email);
            stmt.setDate(5, Date.valueOf(lastDonationDate));
            stmt.setInt(6, donorId);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Donor information updated successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete a donor
    private static void deleteDonor(Scanner scanner) {
        System.out.print("Enter donor ID to delete: ");
        int donorId = scanner.nextInt();
        scanner.nextLine();

        String query = "DELETE FROM Donor WHERE donor_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, donorId);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Donor deleted successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add a blood donation to the inventory
    private static void addBloodDonation(Scanner scanner) {
        System.out.print("Enter donor ID: ");
        int donorId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter donation date (YYYY-MM-DD): ");
        String donationDate = scanner.nextLine();
        System.out.print("Enter blood group: ");
        String bloodGroup = scanner.nextLine();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter expiry date (YYYY-MM-DD): ");
        String expiryDate = scanner.nextLine();

        String query = "INSERT INTO Inventory (donor_id, donation_date, blood_group, quantity, expiry_date) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, donorId);
            stmt.setDate(2, Date.valueOf(donationDate));
            stmt.setString(3, bloodGroup);
            stmt.setInt(4, quantity);
            stmt.setDate(5, Date.valueOf(expiryDate));
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Blood donation added successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to view inventory details
    private static void viewInventoryDetails(Scanner scanner) {
        System.out.print("Enter donation ID: ");
        int donationId = scanner.nextInt();
        scanner.nextLine();

        String query = "SELECT * FROM Inventory WHERE donation_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, donationId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                System.out.println("Donation ID: " + rs.getInt("donation_id"));
                System.out.println("Donor ID: " + rs.getInt("donor_id"));
                System.out.println("Donation Date: " + rs.getDate("donation_date"));
                System.out.println("Blood Group: " + rs.getString("blood_group"));
                System.out.println("Quantity: " + rs.getInt("quantity"));
                System.out.println("Expiry Date: " + rs.getDate("expiry_date"));
            } else {
                System.out.println("No donation found with ID: " + donationId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update inventory information
    private static void updateInventoryInformation(Scanner scanner) {
        System.out.print("Enter donation ID to update: ");
        int donationId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new donation date (YYYY-MM-DD): ");
        String donationDate = scanner.nextLine();
        System.out.print("Enter new blood group: ");
        String bloodGroup = scanner.nextLine();
        System.out.print("Enter new quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter new expiry date (YYYY-MM-DD): ");
        String expiryDate = scanner.nextLine();

        String query = "UPDATE Inventory SET donation_date = ?, blood_group = ?, quantity = ?, expiry_date = ? WHERE donation_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(donationDate));
            stmt.setString(2, bloodGroup);
            stmt.setInt(3, quantity);
            stmt.setDate(4, Date.valueOf(expiryDate));
            stmt.setInt(5, donationId);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Inventory information updated successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete an inventory record
    private static void deleteInventoryRecord(Scanner scanner) {
        System.out.print("Enter donation ID to delete: ");
        int donationId = scanner.nextInt();
        scanner.nextLine();

        String query = "DELETE FROM Inventory WHERE donation_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, donationId);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Inventory record deleted successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to register a blood request
    private static void registerBloodRequest(Scanner scanner) {
        System.out.print("Enter requester name: ");
        String requesterName = scanner.nextLine();
        System.out.print("Enter blood group requested: ");
        String bloodGroupRequested = scanner.nextLine();
        System.out.print("Enter request date (YYYY-MM-DD): ");
        String requestDate = scanner.nextLine();
        System.out.print("Enter request status (Pending, Fulfilled, Cancelled): ");
        String requestStatus = scanner.nextLine();

        String query = "INSERT INTO Request (requester_name, blood_group_requested, request_date, request_status) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, requesterName);
            stmt.setString(2, bloodGroupRequested);
            stmt.setDate(3, Date.valueOf(requestDate));
            stmt.setString(4, requestStatus);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Blood request registered successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to view request details
    private static void viewRequestDetails(Scanner scanner) {
        System.out.print("Enter request ID: ");
        int requestId = scanner.nextInt();
        scanner.nextLine();

        String query = "SELECT * FROM Request WHERE request_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                System.out.println("Request ID: " + rs.getInt("request_id"));
                System.out.println("Requester Name: " + rs.getString("requester_name"));
                System.out.println("Blood Group Requested: " + rs.getString("blood_group_requested"));
                System.out.println("Request Date: " + rs.getDate("request_date"));
                System.out.println("Request Status: " + rs.getString("request_status"));
            } else {
                System.out.println("No request found with ID: " + requestId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update request status
    private static void updateRequestStatus(Scanner scanner) {
        System.out.print("Enter request ID to update: ");
        int requestId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new request status (Pending, Fulfilled, Cancelled): ");
        String requestStatus = scanner.nextLine();

        String query = "UPDATE Request SET request_status = ? WHERE request_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, requestStatus);
            stmt.setInt(2, requestId);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Request status updated successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete a request
    private static void deleteRequest(Scanner scanner) {
        System.out.print("Enter request ID to delete: ");
        int requestId = scanner.nextInt();
        scanner.nextLine();

        String query = "DELETE FROM Request WHERE request_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, requestId);
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Request deleted successfully. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
