package MainCode;

public class InventoryManagment {
	public static void main(String[] args) {
		Menu menu=new Menu();
		menu.displayMainMenu();
	}
}
