/**
 * 
 */
/**
 * 
 */
module COGNIZANT {
	requires java.sql;
	requires java.base;
}