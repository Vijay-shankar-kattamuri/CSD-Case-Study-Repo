package DAO;

import Model.Bookings;
import Model.Rooms;

import java.sql.*;

public class BookingsDAO {

    //Create New Booking
    public void addBooking(Bookings booking){
        try{
            //JDBC Connector
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement("insert into bookings (booking_id, room_id, customer_id, check_in_date, check_out_date) values(?,?,?,?,?)");

            int roomId = booking.getRoomID();
            stmt.setInt(1,booking.getBookingID());
            stmt.setInt(2,roomId);
            stmt.setInt(3,booking.getCustomerID());
            stmt.setDate(4,booking.getCheckInDate());
            stmt.setDate(5,booking.getCheckOutDate());


            //Query
            stmt.executeUpdate();

            // Update Room availability
            String updatesql = "update room_table set status = ? WHERE room_id = ?";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
                PreparedStatement upstmt = con.prepareStatement(updatesql);

                upstmt.setString(1, "Occupied");
                upstmt.setInt(2, roomId);

                upstmt.executeUpdate();
            }catch(Exception e) {
                System.out.println(e);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }

    //View Booking Details
    public Bookings getBooking(int booking_id) {
        String sql = "select * from bookings WHERE booking_id = ?";
        try {
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, booking_id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Bookings booking = new Bookings();
                booking.setBookingID(rs.getInt("booking_id"));
                booking.setRoomID(rs.getInt("room_id"));
                booking.setCustomerID(rs.getInt("customer_id"));
                booking.setCheckInDate(rs.getDate("check_in_date"));
                booking.setCheckOutDate(rs.getDate("check_out_date"));


                return booking;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    //Cancel Booking
    public void cancelBooking(int bookingId) {

        // Update Room availability
        String updatesql = "UPDATE room_table a JOIN bookings b ON a.room_id = b.room_id SET a.status = ? WHERE b.booking_id = ?";
        ;
        try {
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement upstmt = con.prepareStatement(updatesql);

            upstmt.setString(1, "Available");
            upstmt.setInt(2, bookingId);

            upstmt.executeUpdate();
        }catch(Exception e) {
            System.out.println(e);
        }


        String sql = "delete from bookings WHERE booking_id = ?";
        try{
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, bookingId);
            stmt.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }


    }

    //List all Bookings
    public void getBookings(int customer_id) {
        String sql = "select * FROM bookings WHERE customer_id = ?";
        try {
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, customer_id);
            ResultSet rs = stmt.executeQuery();

            System.out.println("Booking Id\tRoom Id\tCustomer Id\tCheck In Date\tCheck Out Date");
            while(rs.next()) {
                String row = "";
                for(int i = 1; i <=rs.getMetaData().getColumnCount();i++) {
                    row += rs.getString(i) + "\t\t\t";
                }
                System.out.println(row);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
