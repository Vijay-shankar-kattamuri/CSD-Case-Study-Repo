package DAO;

import Model.Bookings;
import Model.Rooms;

import java.sql.*;

public class RoomsDAO{

    //Create
    public void addRoom(Rooms rooms){
        try{
            //JDBC Connector
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement("insert into room_table (room_id, room_number,type, price,status) values(?,?,?,?,?)");

            stmt.setInt(1,rooms.getRoomId());
            stmt.setInt(2,rooms.getRoomNumber());
            stmt.setString(3,rooms.getRoomType());
            stmt.setInt(4,rooms.getPrice());
            stmt.setString(5,rooms.getStatus());

            //Query
            stmt.executeUpdate();

        }catch(Exception e){
            System.out.println(e);
        }
    }

    //Read
    public Rooms getRooms(int room_id) {
        String sql = "select * FROM room_table WHERE room_id = ?";
        try {
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, room_id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Rooms rooms = new Rooms();
                rooms.setRoomId(rs.getInt("room_id"));
                rooms.setRoomNumber(rs.getInt("room_number"));
                rooms.setRoomType(rs.getString("type"));
                rooms.setPrice(rs.getInt("price"));
                rooms.setStatus(rs.getString("status"));

                return rooms;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    //Update
    public void updateRoom(Rooms rooms, int oldRoomId) {
        String sql = "update room_table set room_id = ?, room_number = ?, type = ?, price = ?, status = ? WHERE room_id = ?";
        try {
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, rooms.getRoomId());
            stmt.setInt(2, rooms.getRoomNumber());
            stmt.setString(3, rooms.getRoomType());
            stmt.setInt(4, rooms.getPrice());
            stmt.setString(5, rooms.getStatus());
            stmt.setInt(6, oldRoomId);

            stmt.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //Delete
    public void deleteRoom(int roomId) {
        String sql = "delete from room_table WHERE room_id = ?";
        try{
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, roomId);
            stmt.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }


}
