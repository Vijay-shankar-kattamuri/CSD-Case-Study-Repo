package DAO;

import Model.Customers;

import java.sql.*;

public class CustomersDAO {

    //Add New Customer
    public void addCustomer(Customers customer){
        try{
            //JDBC Connector
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement("insert into customers (customer_id, name,email, phone_number) values(?,?,?,?)");

            stmt.setInt(1,customer.getCustomerId());
            stmt.setString(2, customer.getCustomerName());
            stmt.setString(3, customer.getCustomerEmail());
            stmt.setString(4,customer.getCustomerPhone());

            //Query
            stmt.executeUpdate();

        }catch(Exception e){
            System.out.println(e);
        }
    }

    //View Customer Details
    public Customers getCustomers(int customerId) {
        String sql = "select * FROM customers WHERE customer_id = ?";
        try {
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Customers customers = new Customers();
                customers.setCustomerId(rs.getInt("customer_id"));
                customers.setCustomerName(rs.getString("name"));
                customers.setCustomerEmail(rs.getString("email"));
                customers.setCustomerPhone(rs.getString("phone_number"));

                return customers;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    //Update Customer Information
    public void updateCustomer(Customers customer, int oldCustomerId) {
        String sql = "update customers set customer_id = ?, name = ?, email = ?, phone_number = ? where customer_id = ?";
        try {
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1,  customer.getCustomerId());
            stmt.setString(2, customer.getCustomerName());
            stmt.setString(3, customer.getCustomerEmail());
            stmt.setString(4, customer.getCustomerPhone());
            stmt.setInt(5, oldCustomerId);

            stmt.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    //Delete Customer Information
    public void deleteCustomer(int customerId) {
        String sql = "delete from customers WHERE customer_id = ?";
        try{
            //JDBC Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "admin");
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, customerId);
            stmt.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
