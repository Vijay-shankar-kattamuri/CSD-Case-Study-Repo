import java.sql.Date;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import DAO.BookingsDAO;
import DAO.CustomersDAO;
import DAO.RoomsDAO;
import Model.Bookings;
import Model.Customers;
import Model.Rooms;

public class Main {
   private static final Scanner scanner = new Scanner(System.in);
   private static final RoomsDAO roomsDAO = new RoomsDAO();
   private static final CustomersDAO customersDAO = new CustomersDAO();
   private static final BookingsDAO bookingsDAO = new BookingsDAO();

   public static void main(String[] args){

       while(true){
           System.out.println("        Welcome to Hotel Management System\n");
           System.out.println("        Room Management\n");
           System.out.println("1. Add Rooms");
           System.out.println("2. Get Room Details");
           System.out.println("3. Update Room Information");
           System.out.println("4. Delete Room\n");
           System.out.println("        Customer Management\n");
           System.out.println("5. Register New Customer");
           System.out.println("6. View Customer Details");
           System.out.println("7. Update Customer Information");
           System.out.println("8. Delete Customer");
           System.out.println("        Bookings Management\n");
           System.out.println("9. New Booking");
           System.out.println("10. View Booking Details");
           System.out.println("11. Delete Booking");
           System.out.println("12. List all bookings (Customer ID)");

           System.out.println("0. Exit\n");
           System.out.print("Select Option: ");

           int option = scanner.nextInt();
           scanner.nextLine();

           switch(option){
               case 1:
                   addRoom();
                   continue;
               case 2:
                   viewRooms();
                   continue;
               case 3:
                   updateRoom();
                   continue;
               case 4:
                   deleteRoom();
                   continue;
               case 5:
                   addCustomer();
                   continue;
               case 6:
                   viewCustomers();
                   continue;
               case 7:
                   updateCustomer();
                   continue;
               case 8:
                   deleteCustomer();
                   continue;
               case 9:
                   addBooking();
                   continue;
               case 10:
                   viewBooking();
                   continue;
               case 11:
                   deleteBooking();
                   continue;
               case 12:
                   listBooking();
                   continue;
               case 0:
                   return;
           }
       }
   }

   //Add New Rooms Setup
   public static void addRoom(){
       System.out.print("Enter Room Type: ");
       String roomType = scanner.nextLine();
       String roomStatus = "Available";
       System.out.print("Enter Room Id: ");
       int roomId = scanner.nextInt();
       System.out.print("Enter Room Number: ");
       int roomNumber = scanner.nextInt();
       System.out.print("Enter Room Price: ");
       int roomPrice = scanner.nextInt();


       //Set Inputs to Generated Classes
       Rooms room = new Rooms();
       room.setRoomNumber(roomNumber);
       room.setRoomId(roomId);
       room.setRoomType(roomType);
       room.setPrice(roomPrice);
       room.setStatus(roomStatus);

       roomsDAO.addRoom(room);

       System.out.println("Room Added Successfully");
   }

   //View Room Setup
   private static void viewRooms() {
        System.out.print("Enter Room Id: ");
        int roomId = scanner.nextInt();
        scanner.nextLine();

        Rooms rooms = roomsDAO.getRooms(roomId);
        if (rooms != null) {
            System.out.println("Room Id: " + rooms.getRoomId());
            System.out.println("Room Number: " + rooms.getRoomNumber());
            System.out.println("Type: " + rooms.getRoomType());
            System.out.println("Price: " + rooms.getPrice());
            System.out.println("Status: " + rooms.getStatus());
        } else {
            System.out.println("Rooms not found.");
        }
   }

   //Update Room Details
   private static void updateRoom() {
       System.out.print("Enter Room ID: ");
       int roomId = scanner.nextInt();
       scanner.nextLine();  // Consume newline

       Rooms rooms = roomsDAO.getRooms(roomId);
       if (rooms == null) {
           System.out.println("Room not found.");
           return;
       }

       //Get Update Infromation
       System.out.print("Enter new Room Id (current: " + rooms.getRoomId() + "): ");
       int newRoomId  = scanner.nextInt();
       System.out.print("Enter new Room Number (current: " + rooms.getRoomNumber() + "): ");
       int roomNumber = scanner.nextInt();
       System.out.print("Enter new Room Price (current: " + rooms.getPrice() + "): ");
       int price = scanner.nextInt();

       scanner.nextLine();

       System.out.print("Room Status - Available or Occupied? (current: " + rooms.getStatus() + "): ");
       String status = scanner.nextLine();
       System.out.print("Enter new Room Type (current: " + rooms.getRoomType() + "): ");
       String roomType = scanner.nextLine();

       //Update Room Details
       try{
           rooms.setRoomId(newRoomId);
           rooms.setRoomNumber(roomNumber);
           rooms.setRoomType(roomType);
           rooms.setPrice(price);
           rooms.setStatus(status);

           roomsDAO.updateRoom(rooms, roomId);
       }catch(Exception e){
           System.out.println("Invalid Parameters, Room not Updated.");
       }
       System.out.println("Room Information updated successfully.");
   }


    //Delete Room
   private static void deleteRoom() {
       System.out.print("Enter Room ID: ");
       int roomId = scanner.nextInt();
       scanner.nextLine();  // Consume newline

       roomsDAO.deleteRoom(roomId);
       System.out.println("Room deleted successfully.");
   }

    //Add New Customer
    public static void addCustomer(){

        System.out.print("Enter Customer ID: ");
        int customerID = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Customer Name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter Customer Email: ");
        String customerEmail = scanner.nextLine();
        System.out.print("Enter Customer Phone: ");
        String customerPhone = scanner.nextLine();



        //Set Inputs to Generated Classes
        Customers customer = new Customers();
        customer.setCustomerId(customerID);
        customer.setCustomerName(customerName);
        customer.setCustomerEmail(customerEmail);
        customer.setCustomerPhone(customerPhone);

        customersDAO.addCustomer(customer);

        System.out.println("Customer Registered Successfully");
    }

    //View Customer Details
    private static void viewCustomers() {
        System.out.print("Enter Customer Id: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();

        Customers customer = customersDAO.getCustomers(customerId);
        if (customer != null) {
            System.out.println("Customer Id: " + customer.getCustomerId());
            System.out.println("Name: " + customer.getCustomerName());
            System.out.println("Email: " + customer.getCustomerEmail());
            System.out.println("Phone Number: " + customer.getCustomerPhone());
        } else {
            System.out.println("Customer not found.");
        }
    }

    //Update Customer Details
    private static void updateCustomer() {
        System.out.print("Enter Customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Customers customer = customersDAO.getCustomers(customerId);
        if (customer == null) {
            System.out.println("Customer not found.");
            return;
        }

        //Get Update Information
        System.out.print("Enter new Customer Id (current: " + customer.getCustomerId() + "): ");
        int newCustomerId  = scanner.nextInt();

        scanner.nextLine();

        System.out.print("Enter new Customer Name (current: " + customer.getCustomerName() + "): ");
        String customerName = scanner.nextLine();
        System.out.print("Enter new Customer Email (current: " + customer.getCustomerEmail() + "): ");
        String customerEmail = scanner.nextLine();
        System.out.print("Enter new Customer Phone Number (current: " + customer.getCustomerPhone() + "): ");
        String customerPhone = scanner.nextLine();

        //Update Room Details
        try{
            customer.setCustomerId(newCustomerId);
            customer.setCustomerName(customerName);
            customer.setCustomerEmail(customerEmail);
            customer.setCustomerPhone(customerPhone);

            customersDAO.updateCustomer(customer, customerId);
        }catch(Exception e){
            System.out.println("Invalid Parameters, Customer not Updated.");
        }
        System.out.println("Customer Information updated successfully.");
    }

    //Delete Customer
    private static void deleteCustomer() {
        System.out.print("Enter Customers ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();

        customersDAO.deleteCustomer(customerId);
        System.out.println("Customer deleted successfully.");
    }

    //New Booking
    private static void addBooking() {
        System.out.print("Enter room ID: ");
        int roomId = scanner.nextInt();
        scanner.nextLine();

        //Room Check
        Rooms room = roomsDAO.getRooms(roomId);
        if (room == null) {
            System.out.println("Room not found.");
            return;
        }
        if (room.getStatus().equals("Occupied")) {
            System.out.println("Room is not available for Booking.");
            return;
        }

        //Customer Check
        System.out.print("Enter Customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        Customers customer = customersDAO.getCustomers(customerId);
        if (customer == null) {
            System.out.println("Customer not found.");
        }

        System.out.print("Enter Booking ID: ");
        int bookingId = scanner.nextInt();
        scanner.nextLine();

        //Dates Setup
        Date checkInDate = null;
        Date checkOutDate = null;

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        System.out.println("Enter Checkin Date (yyyy-mm-dd):");
        String checkInDateStr = scanner.nextLine();

        System.out.println("Enter Checkout Date:");
        String checkOutDateStr = scanner.nextLine();

        //Dates Parse
        try {
            java.util.Date checkInDateutil = dateFormat.parse(checkInDateStr);
            java.util.Date checkOutDateutil = dateFormat.parse(checkOutDateStr);

            // Convert java.util.Date to java.sql.Date
            checkInDate = new Date(checkInDateutil.getTime());
            checkOutDate = new Date(checkOutDateutil.getTime());

        } catch (ParseException e) {
            e.printStackTrace();
        }

        Bookings bookings = new Bookings();

        bookings.setBookingID(bookingId);
        bookings.setCustomerID(customerId);
        bookings.setRoomID(roomId);
        bookings.setCheckInDate(checkInDate);
        bookings.setCheckOutDate(checkOutDate);

        bookingsDAO.addBooking(bookings);
        System.out.println("Room Booked Successfully");
    }


    //View Booking Details
    private static void viewBooking() {
       System.out.print("Enter Booking ID: ");
       int bookingId = scanner.nextInt();
       scanner.nextLine();

        Bookings booking = bookingsDAO.getBooking(bookingId);
        if (booking != null) {
            System.out.println("Booking Id: " + booking.getBookingID());
            System.out.println("Room Id: " + booking.getRoomID());
            System.out.println("Customer Id: " + booking.getCustomerID());
            System.out.println("Check In Date: " + booking.getCheckInDate());
            System.out.println("Check Out Date: " + booking.getCheckOutDate());
        } else {
            System.out.println("Booking not found.");
        }
    }

    //Delete Booking
    private static void deleteBooking() {
        System.out.print("Enter Booking ID: ");
        int bookingId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        bookingsDAO.cancelBooking(bookingId);
        System.out.println("Booking Cancelled successfully.");
    }

    //List booking by customer id
    private static void listBooking(){
       System.out.print("Enter Customer ID: ");
       int customerId = scanner.nextInt();

       scanner.nextLine();

       bookingsDAO.getBookings(customerId);
    }
}