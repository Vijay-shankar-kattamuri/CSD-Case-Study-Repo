package Model;

import java.sql.Date;

public class Bookings {
    int bookingID;
    int roomID;
    int customerID;
    Date checkInDate;
    Date checkOutDate;

    //Getters
    public int getBookingID() {
        return bookingID;
    }
    public int getRoomID() {
        return roomID;
    }
    public int getCustomerID() {
        return customerID;
    }
    public Date getCheckInDate() {
        return checkInDate;
    }
    public Date getCheckOutDate() {
        return checkOutDate;
    }

    //Setters
    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }
    public void setRoomID(int roomID) {
        this.roomID = roomID;
    }
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }
    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }
}
