package Model;


public class Rooms {
    int roomId;
    int roomNumber;
    String roomType;
    int price;
    String status;

    //Getter
    public int getRoomId() {
        return roomId;
    }
    public int getRoomNumber() {
        return roomNumber;
    }
    public String getRoomType() {
        return roomType;
    }
    public int getPrice() {
        return price;
    }
    public String getStatus() {
        return status;
    }
    //Setters
    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }
    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }
    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }
    public void setPrice(int price) {
        this.price = price;
    }
    public void setStatus(String status) {
        this.status = status;
    }
}
