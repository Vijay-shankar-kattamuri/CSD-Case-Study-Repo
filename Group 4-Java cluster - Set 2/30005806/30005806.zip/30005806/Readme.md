# Hotel Management System

A console based application made with JAVA JDBC and MySQL.

## Prerequisites

<ul>
<li>MySQL Server 8.0 or higher</li>
<li>Java 22.0.2</li>
<li>JDBC MySQL connector JAR properly set up</li>
</ul>

## Initial Setup
<ul>
    <li>Execute the MySQL queries in the file
    
    databaseschema.sql
    
</li>
</ul>

## Usage
<ul>
    To run the application, use the command
        
        java Main

</ul>

<ul>
    You can now see the menu of the application
</ul>

### Functionalities
Depending on your input in the initial menu, your functions will be:

    1. Add New Rooms to the Hotel
    2. Get Details of a specific room
    3. Update Room Infromation of a specific room.
    4. Delete a given room
    5. Register a new customer
    6. View customer details
    7. Update customer information
    8. Delete customer from database
    9. Register a new Booking
    10. View Booking Details
    11. Delete a booking
    12. List all bookings based on customer id
    0. Exit

Select an option from the above list, to execute those specific functions in the application.