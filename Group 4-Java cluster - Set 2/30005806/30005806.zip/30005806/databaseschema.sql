create database hotel;
use hotel;

create table customers(
    customer_id int primary key,
    name varchar(15),
    email varchar(20),
    phone_number varchar(10)
);

create table room_table(
    room_id int primary key,
    room_number int,
    type varchar(10),
    price int,
    status varchar(10)
);

create table bookings(
    booking_id int primary key,
    room_id int,
    customer_id int,
    check_in_date Date,
    check_out_date Date,

    foreign key (room_id) references room_table(room_id),
    foreign key (customer_id) references customers(customer_id)
)
