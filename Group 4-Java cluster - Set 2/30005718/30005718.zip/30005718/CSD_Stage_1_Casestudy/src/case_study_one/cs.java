package case_study_one;
import java.sql.ResultSet;
import java.sql.Connection;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;  
import java.util.Scanner;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class cs {
    static void addEntry(int a) {
        Connection con = null;
        Statement stmt = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tejas", "root", "<your password>");
            stmt = con.createStatement();
            Scanner sc = new Scanner(System.in);

            System.out.println("Enter Blog Title:");
            String blog_title = sc.nextLine();

            System.out.println("Enter description for your blog:");
            String blog_desc = sc.nextLine();

            System.out.println("Enter author name:");
            String blog_author = sc.nextLine();

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            String currentDate = dtf.format(now);
            System.out.println("Current date and time: " + currentDate);

            String query = "INSERT INTO blog_table (Title, Description, Author, creation_date) VALUES ('"
                    + blog_title + "', '"
                    + blog_desc + "', '"
                    + blog_author + "', '"
                    + currentDate + "');";

            System.out.println("Executing query: " + query);
            stmt.execute(query);
            System.out.println("Query executed successfully");

        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    static void viewAllEntries(int a) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tejas", "root", "12345");
            stmt = con.createStatement();
            String query = "SELECT * FROM blog_table";

            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int id = rs.getInt("blog_id");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String author = rs.getString("Author");
                String creationDate = rs.getString("creation_date");

                System.out.println("ID: " + id);
                System.out.println("Title: " + title);
                System.out.println("Description: " + description);
                System.out.println("Author: " + author);
                System.out.println("Creation Date: " + creationDate);
                System.out.println("------------------------------");
            }

        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    static void addPost(int a) {
        Connection con = null;
        Statement stmt = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tejas", "root", "<your password>");
            stmt = con.createStatement();
            Scanner sc = new Scanner(System.in);

            System.out.println("Enter Blog id for which you want to add the post:");
            String blog_id = sc.nextLine();

            System.out.println("Enter Title for your Post:");
            String post_title = sc.nextLine();

            System.out.println("Enter post content:");
            String post_content = sc.nextLine();

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            String publishDate = dtf.format(now);

            String query = "INSERT INTO post_table (blog_id,title, content, publish_date) VALUES ('"
                    + blog_id + "', '"
                    + post_title + "', '"
                    + post_content + "', '"
                    + publishDate + "');";

            System.out.println("Executing query: " + query);
            stmt.execute(query);
            System.out.println("Query executed successfully");
            sc.close();

        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    static void viewAllPosts(int a) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tejas", "root", "<your password>");
            stmt = con.createStatement();
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter blog ID for which you want to display all posts ");
            int blogID = sc.nextInt();
            String query = "Select * from post_table where blog_id=" + blogID + ";";
            sc.close();
            rs = stmt.executeQuery(query);
            String query2 = "Select Author, creation_date from blog_table where blog_id=" + blogID + ";";
            while (rs.next()) {
                int id = rs.getInt("post_id");
                String title = rs.getString("title");
                String content = rs.getString("content");
                String publishDate = rs.getString("publish_date");


                System.out.println("Post ID: " + id);
                System.out.println("Post Title: " + title);
                System.out.println("Post Content: " + content);
                System.out.println("Post Publication date: " + publishDate);

            }
            rs = stmt.executeQuery(query2);

            while (rs.next()) {
                String Author = rs.getString("Author");
                String CreationDate = rs.getString("creation_date");

                System.out.println("Blog Author: " + Author);
                System.out.println("Blog Creation Date: " + CreationDate);
                System.out.println("------------------------------");
            }

        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    static void addUser(int a) {
        Connection con = null;
        Statement stmt = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tejas", "root", "<your password>");
            stmt = con.createStatement();
            Scanner sc = new Scanner(System.in);

            System.out.println("Enter Username:");
            String username = sc.nextLine();

            System.out.println("Enter Email:");
            String email = sc.nextLine();

            System.out.println("Enter Date of birth:");
            String dob = sc.nextLine();

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            String regdate = dtf.format(now);

            String query = "INSERT INTO user_table (username, email, dob, reg_date) VALUES ('"
                    + username + "', '"
                    + email + "', '"
                    + dob + "', '"
                    + regdate + "');";

            System.out.println("Executing query: " + query);
            stmt.execute(query);
            System.out.println("Query executed successfully");

        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    static void viewAllUsers(int a) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tejas", "root", "<your password>");
            stmt = con.createStatement();
            String query = "SELECT * FROM user_table";

            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int id = rs.getInt("user_id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String DOB = rs.getString("dob");
                String regDate = rs.getString("reg_date");

                System.out.println("ID: " + id);
                System.out.println("Username: " + username);
                System.out.println("Email: " + email);
                System.out.println("Date of Birth: " + DOB);
                System.out.println("Registration Date: " + regDate);
                System.out.println("------------------------------");
            }

        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    static void addComment(int a) {
        Connection con = null;
        Statement stmt = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tejas", "root", "<your password>");
            stmt = con.createStatement();
            Scanner sc = new Scanner(System.in);

            System.out.println("Enter Post id for which you want to add the comment:");
            String post_id = sc.nextLine();


            System.out.println("Enter Comment:");
            String post_comment = sc.nextLine();
            
            System.out.println("Enter User_id:");
            int userID = sc.nextInt();


            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            String commentDate = dtf.format(now);

            String query = "INSERT INTO comment_table (post_id,user_id, content, comment_date) VALUES ('"
                    + post_id + "', '"
                    + userID + "', '"
                    + post_comment + "', '"
                    + commentDate + "');";

            System.out.println("Executing query: " + query);
            stmt.execute(query);
            System.out.println("Query executed successfully");
            sc.close();

        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    static void viewAllComments(int a) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tejas", "root", "<your password>");
            stmt = con.createStatement();
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter Post ID for which you want to display all Comments ");
            int postID = sc.nextInt();
            String query = "Select * from comment_table where post_id=" + postID + ";";
            sc.close();
            rs = stmt.executeQuery(query);
            String query2 = "Select user_id, content, comment_date from comment_table where post_id=" + postID + ";";
            while (rs.next()) {
                int id = rs.getInt("user_id");
                String content = rs.getString("content");
                String commentDate = rs.getString("comment_date");


                System.out.println("Post ID: " + id);
                System.out.println("Post Content: " + content);
                System.out.println("Post Publication date: " + commentDate);

            }    

        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }
    
    public static void main(String[] args) {
    	
    	
        System.out.println("Enter the serial number of the operation you want to perform:");
        System.out.println("1) Blog Creation");
        System.out.println("2) View all blogs");
        System.out.println("3) Add a post");
        System.out.println("4) View all Posts");
        System.out.println("5) Add new user");
        System.out.println("6) View All users");
        System.out.println("7) Add comment on a post");
        System.out.println("8) View all comments");



        Scanner sc = new Scanner(System.in);
        int op = sc.nextInt();

        switch (op) {
            case 1:
                addEntry(op);
                break;
            case 2:
            	viewAllEntries(op);
            	break;
            case 3:
            	addPost(op);
            	break;
            case 4:
            	viewAllPosts(op);
                break;
            case 5:
            	addUser(op);
                break;
            case 6:
            	viewAllUsers(op);
                break;
            case 7:
            	addComment(op);
                break;
            case 8:
            	viewAllComments(op);
                break;
            default:
                System.out.println("Invalid option");
        }

        sc.close();
    }
}
