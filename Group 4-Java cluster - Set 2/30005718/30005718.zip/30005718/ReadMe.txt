Steps to set up the environment:-
1)Find the cs.java file in the CSD_Stage_1_Casestudy folder under src. The file contains the Java code.
2) DB dump for all the tables is provided in the DB dump folder. Run the commands in the files to get the database and schema.
3)Set up the connection with the Database using your username and password.

You are set to go!!!

Upon running the program you will be prompted with 8 options as follows.

1) Blog Creation
2) View all blogs
3) Add a post
4) View all Posts
5) Add new user
6) View All users
7) Add comment on a post
8) View all comments

Select the appropriate option. Enter the prompted results. The data will be dumped in to the database.