/**
 * 
 */
/**
 * @author DELL
 *
 */
module ClassroomManagementSystem {
	requires java.sql;
}