
package feedbackmanagement;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class AnalysisManagement {
    private Connection connection;

    public AnalysisManagement(Connection connection) {
        this.connection = connection;
    }

    public void addAnalysis(Scanner scanner) {
        try {
            System.out.println("Enter feedback ID to analyze:");
            int feedbackId = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter analysis details:");
            String analysisDetails = scanner.nextLine();
            System.out.println("Enter status:");
            String status = scanner.nextLine();

            String query = "INSERT INTO Analysis (feedback_id, analysis_date, analysis_details, status) VALUES (?, CURDATE(), ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, feedbackId);
            pstmt.setString(2, analysisDetails);
            pstmt.setString(3, status);
            pstmt.executeUpdate();
            System.out.println("Feedback analyzed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewAnalysisReports(Scanner scanner) {
        
    }
}

