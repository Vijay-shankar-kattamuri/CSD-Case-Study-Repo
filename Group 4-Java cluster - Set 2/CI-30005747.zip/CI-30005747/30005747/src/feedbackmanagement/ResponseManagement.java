
package feedbackmanagement;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ResponseManagement {
    private Connection connection;

    public ResponseManagement(Connection connection) {
        this.connection = connection;
    }

    public void addResponse(Scanner scanner) {
        try {
            System.out.println("Enter feedback ID to respond to:");
            int feedbackId = scanner.nextInt();
            scanner.nextLine(); 
            System.out.println("Enter response text:");
            String responseText = scanner.nextLine();
            System.out.println("Enter status:");
            String status = scanner.nextLine();

            String query = "INSERT INTO Response (feedback_id, response_date, response_text, status) VALUES (?, CURDATE(), ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, feedbackId);
            pstmt.setString(2, responseText);
            pstmt.setString(3, status);
            pstmt.executeUpdate();
            System.out.println("Response recorded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewResponseHistory(Scanner scanner) {
        
    }
}


