package com.obs.exception;

public class AccountantException extends Exception{
	
	public AccountantException() {
		
	}
	
	public AccountantException(String message) {
		super(message);
	}
}
