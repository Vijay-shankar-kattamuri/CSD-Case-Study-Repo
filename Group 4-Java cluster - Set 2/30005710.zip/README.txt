Project Description:

The Online Library Management System is a Java-based application designed to manage an online library. It provides functionalities for managing eBooks, authors, and users with their memberships. The system allows administrators to add, view, update, and delete eBooks, authors, and user information.

Features:

EBook Management: Add, view, update, and delete eBooks.

Author Management: Add, view, update, and delete authors.

User Management: Register new users, view user details, update user information, and cancel memberships.

Database Integration: Utilizes a MySQL database to store and manage data.

Ebook.java: Represents the eBook entity.

EBookManagement.java: Contains methods for managing eBooks.

Author.java: Represents the author entity.

AuthorManagement.java: Contains methods for managing authors.

User.java: Represents the user entity.

UserManagement.java: Contains methods for managing users.

Demo.java: Contains the method to establish a database connection.

Main.java: The entry point of the application, containing the main menu and handling user input.


Setup Instructions:


Prerequisites:

Java Development Kit (JDK) 8 or later

MySQL database

An IDE or text editor (e.g., IntelliJ IDEA, Eclipse, VSCode)

Database Setup:

Install MySQL and create a database named library_management.

Create the necessary tables

Project Setup:

Clone the repository:

Copy code

git clone https://github.com/your-username/library-management-system.git

Open the project in your preferred IDE.

Configure the database connection in Demo.java:

package Comp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Demo {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/library_management";
        String user = "your-username";
        String password = "your-password";
        return DriverManager.getConnection(url, user, password);
    }
}

Build and run the project.

Usage:

Run the Main class.

Follow the on-screen prompts to manage eBooks, authors, and user memberships.

Example Operations:

EBook Management:

Add a new eBook:
Enter title, genre, publication date, author ID, and available copies.
View eBook details:
Enter the eBook ID to view its details.
Update eBook information:
Enter the eBook ID and the updated details.
Delete an eBook:
Enter the eBook ID to delete it.

Author Management:

Add a new author:
Enter name, bio, nationality, and birth date.
View author details:
Enter the author ID to view their details.
Update author information:
Enter the author ID and the updated details.
Delete an author:
Enter the author ID to delete them.

User Management:

Register a new user:

Enter username, email, date of birth, membership date, and membership status.
View user membership details:

Enter the user ID to view details.
Update membership information:

Enter the user ID and the updated details.
Cancel a membership:

Enter the user ID to cancel the membership.