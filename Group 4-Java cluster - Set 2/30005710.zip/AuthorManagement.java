package Comp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class AuthorManagement {
	 public void addAuthor(String name, String bio, String nationality, Date birthDate) throws SQLException {
	        String query = "INSERT INTO Authors (name, bio, nationality, birth_date) VALUES (?, ?, ?, ?)";
	        try (Connection conn = Demo.getConnection();
	        	PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setString(1, name);
	            stmt.setString(2, bio);
	            stmt.setString(3, nationality);
	            stmt.setDate(4, birthDate);
	            stmt.executeUpdate();
	        }
	    }

	    public List<String> viewAuthorDetails(int authorId) throws SQLException {
	        String query = "SELECT * FROM Authors WHERE author_id = ?";
	        List<String> details = new ArrayList<>();
	        try (Connection conn = Demo.getConnection();
	        	PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setInt(1, authorId);
	            try (ResultSet rs = stmt.executeQuery()) {
	                if (rs.next()) {
	                    details.add("Name: " + rs.getString("name"));
	                    details.add("Bio: " + rs.getString("bio"));
	                    details.add("Nationality: " + rs.getString("nationality"));
	                    details.add("Birth Date: " + rs.getDate("birth_date"));
	                }
	            }
	        }
	        return details;
	    }

	    public void updateAuthor(int authorId, String name, String bio, String nationality, Date birthDate) throws SQLException {
	        String query = "UPDATE Authors SET name = ?, bio = ?, nationality = ?, birth_date = ? WHERE author_id = ?";
	        try (Connection conn = Demo.getConnection(); 
	        	PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setString(1, name);
	            stmt.setString(2, bio);
	            stmt.setString(3, nationality);
	            stmt.setDate(4, birthDate);
	            stmt.setInt(5, authorId);
	            stmt.executeUpdate();
	        }
	    }

	    public void deleteAuthor(int authorId) throws SQLException {
	        String query = "DELETE FROM Authors WHERE author_id = ?";
	        try (Connection conn = Demo.getConnection();
	        	PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setInt(1, authorId);
	            stmt.executeUpdate();
	        }
	    }
}
