package Comp;

import java.sql.Date;

public class Ebook {
    private int ebookId;
    private String title;
    private String genre;
    private Date publicationDate;
    private int authorId;
    private int availableCopies;
    
    // Getters
    public int getEbookId() {
        return ebookId;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public int getAuthorId() {
        return authorId;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    // Setters
    public void setEbookId(int ebookId) {
        this.ebookId = ebookId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
    }
}
