package Comp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class EBookManagement {
	public void addEBook(String title, String genre, Date publicationDate, int authorId, int availableCopies) throws SQLException {
        String query = "INSERT INTO EBooks (title, genre, publication_date, author_id, available_copies) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Demo.getConnection();
        	PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, title);
            stmt.setString(2, genre);
            stmt.setDate(3, publicationDate);
            stmt.setInt(4, authorId);
            stmt.setInt(5, availableCopies);
            stmt.executeUpdate();
        }
    }

    public List<String> viewEBookDetails(int ebookId) throws SQLException {
        String query = "SELECT * FROM EBooks WHERE ebook_id = ?";
        List<String> details = new ArrayList<>();
        try (Connection conn = Demo.getConnection();
        		
        	PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, ebookId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    details.add("Title: " + rs.getString("title"));
                    details.add("Genre: " + rs.getString("genre"));
                    details.add("Publication Date: " + rs.getDate("publication_date"));
                    details.add("Author ID: " + rs.getInt("author_id"));
                    details.add("Available Copies: " + rs.getInt("available_copies"));
                }
            }
        }
        return details;
    }

    public void updateEBook(int ebookId, String title, String genre, Date publicationDate, int authorId, int availableCopies) throws SQLException {
        String query = "UPDATE EBooks SET title = ?, genre = ?, publication_date = ?, author_id = ?, available_copies = ? WHERE ebook_id = ?";
        try (Connection conn = Demo.getConnection();
        	PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, title);
            stmt.setString(2, genre);
            stmt.setDate(3, publicationDate);
            stmt.setInt(4, authorId);
            stmt.setInt(5, availableCopies);
            stmt.setInt(6, ebookId);
            stmt.executeUpdate();
        }
    }

    public void deleteEBook(int ebookId) throws SQLException {
        String query = "DELETE FROM EBooks WHERE ebook_id = ?";
        try (Connection conn = Demo.getConnection();
        	PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, ebookId);
            stmt.executeUpdate();
        }
    }
}
