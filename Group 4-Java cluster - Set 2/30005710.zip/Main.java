package Comp;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EBookManagement ebookManagement = new EBookManagement();
        AuthorManagement authorManagement = new AuthorManagement();
        UserManagement userManagement = new UserManagement();

        while (true) {
            System.out.println("Digital Library Management System");
            System.out.println("1. E-Book Management");
            System.out.println("2. Author Management");
            System.out.println("3. Membership Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    handleEBookManagement(scanner, ebookManagement);
                    break;
                case 2:
                    handleAuthorManagement(scanner, authorManagement);
                    break;
                case 3:
                    handleMembershipManagement(scanner, userManagement);
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void handleEBookManagement(Scanner scanner, EBookManagement ebookManagement) {
        System.out.println("E-Book Management");
        System.out.println("1. Add a new e-book");
        System.out.println("2. View e-book details");
        System.out.println("3. Update e-book information");
        System.out.println("4. Delete an e-book");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter genre: ");
                    String genre = scanner.nextLine();
                    Date publicationDate = getDateFromInput(scanner, "Enter publication date (YYYY-MM-DD): ");
                    System.out.print("Enter author ID: ");
                    int authorId = scanner.nextInt();
                    System.out.print("Enter available copies: ");
                    int availableCopies = scanner.nextInt();
                    ebookManagement.addEBook(title, genre, publicationDate, authorId, availableCopies);
                    System.out.println("E-Book added successfully.");
                    break;
                case 2:
                    System.out.print("Enter e-book ID: ");
                    int ebookId = scanner.nextInt();
                    List<String> ebookDetails = ebookManagement.viewEBookDetails(ebookId);
                    if (ebookDetails.isEmpty()) {
                        System.out.println("E-Book not found.");
                    } else {
                        ebookDetails.forEach(System.out::println);
                    }
                    break;
                case 3:
                    System.out.print("Enter e-book ID: ");
                    ebookId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter title: ");
                    title = scanner.nextLine();
                    System.out.print("Enter genre: ");
                    genre = scanner.nextLine();
                    System.out.print("Enter publication date (YYYY-MM-DD): ");
                    publicationDate = Date.valueOf(scanner.nextLine());
                    System.out.print("Enter author ID: ");
                    authorId = scanner.nextInt();
                    System.out.print("Enter available copies: ");
                    availableCopies = scanner.nextInt();
                    ebookManagement.updateEBook(ebookId, title, genre, publicationDate, authorId, availableCopies);
                    System.out.println("E-Book updated successfully.");
                    break;
                case 4:
                    System.out.print("Enter e-book ID: ");
                    ebookId = scanner.nextInt();
                    ebookManagement.deleteEBook(ebookId);
                    System.out.println("E-Book deleted successfully.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void handleAuthorManagement(Scanner scanner, AuthorManagement authorManagement) {
        System.out.println("Author Management");
        System.out.println("1. Add a new author");
        System.out.println("2. View author details");
        System.out.println("3. Update author information");
        System.out.println("4. Delete an author");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter bio: ");
                    String bio = scanner.nextLine();
                    System.out.print("Enter nationality: ");
                    String nationality = scanner.nextLine();
                    System.out.print("Enter birth date (YYYY-MM-DD): ");
                    Date birthDate = Date.valueOf(scanner.nextLine());
                    authorManagement.addAuthor(name, bio, nationality, birthDate);
                    System.out.println("Author added successfully.");
                    break;
                case 2:
                    System.out.print("Enter author ID: ");
                    int authorId = scanner.nextInt();
                    List<String> authorDetails = authorManagement.viewAuthorDetails(authorId);
                    if (authorDetails.isEmpty()) {
                        System.out.println("Author not found.");
                    } else {
                        authorDetails.forEach(System.out::println);
                    }
                    break;
                case 3:
                    System.out.print("Enter author ID: ");
                    authorId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter bio: ");
                    bio = scanner.nextLine();
                    System.out.print("Enter nationality: ");
                    nationality = scanner.nextLine();
                    System.out.print("Enter birth date (YYYY-MM-DD): ");
                    birthDate = Date.valueOf(scanner.nextLine());
                    authorManagement.updateAuthor(authorId, name, bio, nationality, birthDate);
                    System.out.println("Author updated successfully.");
                    break;
                case 4:
                    System.out.print("Enter author ID: ");
                    authorId = scanner.nextInt();
                    authorManagement.deleteAuthor(authorId);
                    System.out.println("Author deleted successfully.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void handleMembershipManagement(Scanner scanner, UserManagement userManagement) {
        System.out.println("Membership Management");
        System.out.println("1. Register a new user");
        System.out.println("2. View user membership details");
        System.out.println("3. Update membership information");
        System.out.println("4. Cancel a membership");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            switch (choice) {
                case 1:
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter date of birth (YYYY-MM-DD): ");
                    Date dateOfBirth = Date.valueOf(scanner.nextLine());
                    System.out.print("Enter membership date (YYYY-MM-DD): ");
                    Date membershipDate = Date.valueOf(scanner.nextLine());
                    System.out.print("Enter membership status (active/inactive): ");
                    String membershipStatus = scanner.nextLine();
                    userManagement.addUser(username, email, dateOfBirth, membershipDate, membershipStatus);
                    System.out.println("User registered successfully.");
                    break;
                case 2:
                    System.out.print("Enter user ID: ");
                    int userId = scanner.nextInt();
                    List<String> userDetails = userManagement.viewUserDetails(userId);
                    if (userDetails.isEmpty()) {
                        System.out.println("User not found.");
                    } else {
                        userDetails.forEach(System.out::println);
                    }
                    break;
                case 3:
                    System.out.print("Enter user ID: ");
                    userId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter username: ");
                    username = scanner.nextLine();
                    System.out.print("Enter email: ");
                    email = scanner.nextLine();
                    System.out.print("Enter date of birth (YYYY-MM-DD): ");
                    dateOfBirth = Date.valueOf(scanner.nextLine());
                    System.out.print("Enter membership date (YYYY-MM-DD): ");
                    membershipDate = Date.valueOf(scanner.nextLine());
                    System.out.print("Enter membership status (active/inactive): ");
                    membershipStatus = scanner.nextLine();
                    userManagement.updateUser(userId, username, email, dateOfBirth, membershipDate, membershipStatus);
                    System.out.println("User updated successfully.");
                    break;
                case 4:
                    System.out.print("Enter user ID: ");
                    userId = scanner.nextInt();
                    userManagement.deleteUser(userId);
                    System.out.println("User membership cancelled successfully.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
        
        private static Date getDateFromInput(Scanner scanner, String prompt) {
            while (true) {
                System.out.print(prompt);
                String dateString = scanner.nextLine();
                try {
                    return Date.valueOf(dateString);
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid date format. Please use YYYY-MM-DD.");
                }
            }

	}

}
