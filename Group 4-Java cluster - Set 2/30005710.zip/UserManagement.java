package Comp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class UserManagement {
	public void addUser(String username, String email, Date dateOfBirth, Date membershipDate, String membershipStatus) throws SQLException {
        String query = "INSERT INTO Users (username, email, date_of_birth, membership_date, membership_status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Demo.getConnection(); 
        	PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setDate(3, dateOfBirth);
            stmt.setDate(4, membershipDate);
            stmt.setString(5, membershipStatus);
            stmt.executeUpdate();
        }
    }

    public List<String> viewUserDetails(int userId) throws SQLException {
        String query = "SELECT * FROM Users WHERE user_id = ?";
        List<String> details = new ArrayList<>();
        try (Connection conn = Demo.getConnection();
        	PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    details.add("Username: " + rs.getString("username"));
                    details.add("Email: " + rs.getString("email"));
                    details.add("Date of Birth: " + rs.getDate("date_of_birth"));
                    details.add("Membership Date: " + rs.getDate("membership_date"));
                    details.add("Membership Status: " + rs.getString("membership_status"));
                }
            }
        }
        return details;
    }

    public void updateUser(int userId, String username, String email, Date dateOfBirth, Date membershipDate, String membershipStatus) throws SQLException {
        String query = "UPDATE Users SET username = ?, email = ?, date_of_birth = ?, membership_date = ?, membership_status = ? WHERE user_id = ?";
        try (Connection conn = Demo.getConnection();
        	PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setDate(3, dateOfBirth);
            stmt.setDate(4, membershipDate);
            stmt.setString(5, membershipStatus);
            stmt.setInt(6, userId);
            stmt.executeUpdate();
        }
    }

    public void deleteUser(int userId) throws SQLException {
        String query = "DELETE FROM Users WHERE user_id = ?";
        try (Connection conn = Demo.getConnection();
        	PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.executeUpdate();
        }
    }
}
