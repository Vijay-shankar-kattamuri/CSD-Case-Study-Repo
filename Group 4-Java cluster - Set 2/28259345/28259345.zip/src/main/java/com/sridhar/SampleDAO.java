package com.sridhar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SampleDAO {
    public void addSample(Sample sample) throws SQLException {
        String sql = "INSERT INTO Sample (experiment_id, name, type, quantity) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sample.getExperimentId());
            pstmt.setString(2, sample.getName());
            pstmt.setString(3, sample.getType());
            pstmt.setInt(4, sample.getQuantity());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            if (e.getMessage().contains("foreign key constraint fails")) {
                throw new SQLException("Experiment ID not found: " + sample.getExperimentId(), e);
            } else {
                throw e;
            }
        }
    }

    public Sample getSample(int sampleId) {
        String sql = "SELECT * FROM Sample WHERE sample_id = ?";
        Sample sample = null;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sampleId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                sample = new Sample();
                sample.setSampleId(rs.getInt("sample_id"));
                sample.setExperimentId(rs.getInt("experiment_id"));
                sample.setName(rs.getString("name"));
                sample.setType(rs.getString("type"));
                sample.setQuantity(rs.getInt("quantity"));
            }
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Sample not found: " + e.getMessage());
        }
        return sample;
    }

    public void updateSample(Sample sample) {
        String sql = "UPDATE Sample SET experiment_id = ?, name = ?, type = ?, quantity = ? WHERE sample_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sample.getExperimentId());
            pstmt.setString(2, sample.getName());
            pstmt.setString(3, sample.getType());
            pstmt.setInt(4, sample.getQuantity());
            pstmt.setInt(5, sample.getSampleId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Sample not found: " + e.getMessage());
        }
    }

    public void deleteSample(int sampleId) {
        String sql = "DELETE FROM Sample WHERE sample_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sampleId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Sample not found: " + e.getMessage());
        }
    }

    public List<Sample> getAllSamples() {
        List<Sample> samples = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Sample")) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Sample sample = new Sample();
                sample.setSampleId(rs.getInt("sample_id"));
                sample.setExperimentId(rs.getInt("experiment_id"));
                sample.setName(rs.getString("name"));
                sample.setType(rs.getString("type"));
                sample.setQuantity(rs.getInt("quantity"));
                samples.add(sample);
            }
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Error retreiving sample data from db: " + e.getMessage());
        }
        return samples;
    }
}
