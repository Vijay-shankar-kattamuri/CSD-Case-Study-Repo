package com.sridhar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSetup {
    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root";
    private static final String PASSWORD = "sridhar";
    private static final String DATABASE_NAME = "LabManagementSystem";

    public static void setupdb() {
        createDatabase();
        createTables();
    }

    private static void createDatabase() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE DATABASE IF NOT EXISTS " + DATABASE_NAME;
            stmt.executeUpdate(sql);
            System.out.println("Database created successfully...");
        } catch (SQLException e) {
            System.out.println("Error creating database "+e.getMessage());
            // e.printStackTrace();
        }
    }

    private static void createTables() {
        try (Connection conn = DriverManager.getConnection(URL + DATABASE_NAME, USER, PASSWORD);
             Statement stmt = conn.createStatement()) {
            
            String createExperimentTable = "CREATE TABLE IF NOT EXISTS Experiment (" +
                    "experiment_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "description TEXT, " +
                    "start_date DATE, " +
                    "end_date DATE" +
                    ")";

            String createSampleTable = "CREATE TABLE IF NOT EXISTS Sample (" +
                    "sample_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "experiment_id INT, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "type VARCHAR(100), " +
                    "quantity INT, " +
                    "FOREIGN KEY (experiment_id) REFERENCES Experiment(experiment_id) ON DELETE CASCADE" +
                    ")";

            String createResearcherTable = "CREATE TABLE IF NOT EXISTS Researcher (" +
                    "researcher_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "email VARCHAR(100), " +
                    "phone_number VARCHAR(15), " +
                    "specialization VARCHAR(100)" +
                    ")";

            stmt.executeUpdate(createExperimentTable);
            stmt.executeUpdate(createSampleTable);
            stmt.executeUpdate(createResearcherTable);

            System.out.println("Tables created successfully...");
        } catch (SQLException e) {
            System.out.println("Error creating tables "+e.getMessage());
            // e.printStackTrace();
        }
    }
}
