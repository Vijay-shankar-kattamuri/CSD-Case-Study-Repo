package com.sridhar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ResearcherDAO {
    public void addResearcher(Researcher researcher) {
        String sql = "INSERT INTO Researcher (name, email, phone_number, specialization) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, researcher.getName());
            pstmt.setString(2, researcher.getEmail());
            pstmt.setString(3, researcher.getPhoneNumber());
            pstmt.setString(4, researcher.getSpecialization());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding researcher in database: " + e.getMessage());
            // e.printStackTrace();
        }
    }

    public Researcher getResearcher(int researcherId) {
        String sql = "SELECT * FROM Researcher WHERE researcher_id = ?";
        Researcher researcher = null;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, researcherId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                researcher = new Researcher();
                researcher.setResearcherId(rs.getInt("researcher_id"));
                researcher.setName(rs.getString("name"));
                researcher.setEmail(rs.getString("email"));
                researcher.setPhoneNumber(rs.getString("phone_number"));
                researcher.setSpecialization(rs.getString("specialization"));
            }
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Researcher not found: " + e.getMessage());
        }
        return researcher;
    }

    public void updateResearcher(Researcher researcher) {
        String sql = "UPDATE Researcher SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE researcher_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, researcher.getName());
            pstmt.setString(2, researcher.getEmail());
            pstmt.setString(3, researcher.getPhoneNumber());
            pstmt.setString(4, researcher.getSpecialization());
            pstmt.setInt(5, researcher.getResearcherId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Researcher not found: " + e.getMessage());
        }
    }

    public void deleteResearcher(int researcherId) {
        String sql = "DELETE FROM Researcher WHERE researcher_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, researcherId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Researcher not found: " + e.getMessage());
        }
    }

    public List<Researcher> getAllResearchers() {
        List<Researcher> researchers = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Researcher")) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Researcher researcher = new Researcher();
                researcher.setResearcherId(rs.getInt("researcher_id"));
                researcher.setName(rs.getString("name"));
                researcher.setEmail(rs.getString("email"));
                researcher.setPhoneNumber(rs.getString("phone_number"));
                researcher.setSpecialization(rs.getString("specialization"));
                researchers.add(researcher);
            }
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Error retreiving researcher data from db " + e.getMessage());
        }
        return researchers;
    }
}

