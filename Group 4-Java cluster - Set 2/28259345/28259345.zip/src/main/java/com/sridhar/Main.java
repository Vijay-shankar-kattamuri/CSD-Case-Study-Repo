package com.sridhar;


import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DatabaseSetup.setupdb();
        ExperimentDAO experimentDAO = new ExperimentDAO();
        SampleDAO sampleDAO = new SampleDAO();
        ResearcherDAO researcherDAO = new ResearcherDAO();

        while (true) {
            System.out.println("\n\n\nMenu:");
            System.out.println("1. Experiment Management");
            System.out.println("2. Sample Management");
            System.out.println("3. Researcher Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageExperiments(scanner, experimentDAO);
                    break;
                case 2:
                    manageSamples(scanner, sampleDAO);
                    break;
                case 3:
                    manageResearchers(scanner, researcherDAO);
                    break;
                case 4:
                    System.out.println("\nExiting the program");
                    System.out.println("Developed by Sridhar Raju\n\n");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageExperiments(Scanner scanner, ExperimentDAO experimentDAO) {
        System.out.println("\n\nExperiment Management:");
        System.out.println("1. Add Experiment");
        System.out.println("2. View Experiment");
        System.out.println("3. Update Experiment");
        System.out.println("4. Delete Experiment");
        System.out.println("5. Print all Experiment");
        System.out.println("6. Go back to Main Page");
        System.out.print("\nChoose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter experiment name: ");
                String name = scanner.nextLine();
                System.out.print("Enter description: ");
                String description = scanner.nextLine();
                System.out.print("Enter start date (yyyy-MM-dd): ");
                String startDateStr = scanner.nextLine();
                System.out.print("Enter end date (yyyy-MM-dd): ");
                String endDateStr = scanner.nextLine();

                try {
                    Date startDate = new SimpleDateFormat("yyyy-MM-dd").parse(startDateStr);
                    Date endDate = new SimpleDateFormat("yyyy-MM-dd").parse(endDateStr);
                    if(startDate.after(endDate))
                    {
                        System.out.println("\n\nError ::Start date is greater than end date");
                        // break;
                        manageExperiments(scanner, experimentDAO);
                        
                    }
                    Experiment experiment = new Experiment();
                    experiment.setName(name);
                    experiment.setDescription(description);
                    experiment.setStartDate(startDate);
                    experiment.setEndDate(endDate);
                    experimentDAO.addExperiment(experiment);
                    System.out.println("\nExperiment added successfully.");
                } catch (ParseException e) {
                    System.out.println("\nError: Invalid date format.");
                    manageExperiments(scanner, experimentDAO);
                }
                break;
            case 2:
                System.out.print("Enter experiment ID: ");
                int experimentId = scanner.nextInt();
                Experiment experiment = experimentDAO.getExperiment(experimentId);
                if (experiment != null) {
                    System.out.println("Experiment ID: " + experiment.getExperimentId());
                    System.out.println("Name: " + experiment.getName());
                    System.out.println("Description: " + experiment.getDescription());
                    System.out.println("Start Date: " + experiment.getStartDate());
                    System.out.println("End Date: " + experiment.getEndDate());
                } else {
                    System.out.println("Experiment not found.");
                }
                break;
            case 3:
                System.out.print("Enter experiment ID: ");
                int updateExperimentId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                Experiment updateExperiment = experimentDAO.getExperiment(updateExperimentId);
                if (updateExperiment != null) {
                    System.out.print("Enter new name: ");
                    updateExperiment.setName(scanner.nextLine());
                    System.out.print("Enter new description: ");
                    updateExperiment.setDescription(scanner.nextLine());
                    System.out.print("Enter new start date (yyyy-MM-dd): ");
                    String newStartDateStr = scanner.nextLine();
                    System.out.print("Enter new end date (yyyy-MM-dd): ");
                    String newEndDateStr = scanner.nextLine();
                    try {
                        Date newStartDate = new SimpleDateFormat("yyyy-MM-dd").parse(newStartDateStr);
                        Date newEndDate = new SimpleDateFormat("yyyy-MM-dd").parse(newEndDateStr);
                        updateExperiment.setStartDate(newStartDate);
                        updateExperiment.setEndDate(newEndDate);
                        experimentDAO.updateExperiment(updateExperiment);
                        System.out.println("Experiment updated successfully.");
                    } catch (ParseException e) {
                        System.out.println("Invalid date format.");
                    }
                } else {
                    System.out.println("Experiment not found.");
                }
                break;
            case 4:
                System.out.print("Enter experiment ID: ");
                int deleteExperimentId = scanner.nextInt();
                experimentDAO.deleteExperiment(deleteExperimentId);
                System.out.println("Experiment deleted successfully.");
                break;
            case 5:
                List<Experiment> experiments = experimentDAO.getAllExperiments();
                printExperimentTable(experiments);
                break;
            case 6: break;
            default:
                System.out.println("\nInvalid choice.");
                manageExperiments(scanner, experimentDAO);
        }
    }

    private static void manageSamples(Scanner scanner, SampleDAO sampleDAO) {
        System.out.println("\n\nSample Management:");
        System.out.println("1. Add Sample");
        System.out.println("2. View Sample");
        System.out.println("3. Update Sample");
        System.out.println("4. Delete Sample");
        System.out.println("5. Print all Sample");
        System.out.println("6. Go back to Main Page");
        System.out.print("\nChoose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter experiment ID: ");
                int experimentId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter sample name: ");
                String name = scanner.nextLine();
                System.out.print("Enter type: ");
                String type = scanner.nextLine();
                System.out.print("Enter quantity: ");
                int quantity = scanner.nextInt();

                Sample sample = new Sample();
                sample.setExperimentId(experimentId);
                sample.setName(name);
                sample.setType(type);
                sample.setQuantity(quantity);
                try {
                    sampleDAO.addSample(sample);
                    System.out.println("Sample added successfully.");
                } catch (SQLException e) {
                    System.out.println("Error: " + e.getMessage());
                }
                break;
            case 2:
                System.out.print("Enter sample ID: ");
                int sampleId = scanner.nextInt();
                Sample samples = sampleDAO.getSample(sampleId);
                if (samples != null) {
                    System.out.println("Sample ID: " + samples.getSampleId());
                    System.out.println("Experiment ID: " + samples.getExperimentId());
                    System.out.println("Name: " + samples.getName());
                    System.out.println("Type: " + samples.getType());
                    System.out.println("Quantity: " + samples.getQuantity());
                } else {
                    System.out.println("Sample not found.");
                }
                break;
            case 3:
                System.out.print("Enter sample ID: ");
                int updateSampleId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                Sample updateSample = sampleDAO.getSample(updateSampleId);
                if (updateSample != null) {
                    System.out.print("Enter new experiment ID: ");
                    updateSample.setExperimentId(scanner.nextInt());
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new name: ");
                    updateSample.setName(scanner.nextLine());
                    System.out.print("Enter new type: ");
                    updateSample.setType(scanner.nextLine());
                    System.out.print("Enter new quantity: ");
                    updateSample.setQuantity(scanner.nextInt());
                    sampleDAO.updateSample(updateSample);
                    System.out.println("Sample updated successfully.");
                } else {
                    System.out.println("Sample not found.");
                }
                break;
            case 4:
                System.out.print("Enter sample ID: ");
                int deleteSampleId = scanner.nextInt();
                sampleDAO.deleteSample(deleteSampleId);
                System.out.println("Sample deleted successfully.");
                break;
            case 5:
                List<Sample> samplesl = sampleDAO.getAllSamples();
                printSampleTable(samplesl);
                break;
            case 6: break;
            default:
                System.out.println("Invalid choice.");
                manageSamples(scanner, sampleDAO);
        
        }
    }

    private static void manageResearchers(Scanner scanner, ResearcherDAO researcherDAO) {
        System.out.println("\n\nResearcher Management:");
        System.out.println("1. Add Researcher");
        System.out.println("2. View Researcher");
        System.out.println("3. Update Researcher");
        System.out.println("4. Delete Researcher");
        System.out.println("5. Print all Researcher");
        System.out.println("Any other key. Go back to Main Page");
        System.out.print("\nChoose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter researcher name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter phone number: ");
                String phoneNumber = scanner.nextLine();
                System.out.print("Enter specialization: ");
                String specialization = scanner.nextLine();

                Researcher researcher = new Researcher();
                researcher.setName(name);
                researcher.setEmail(email);
                researcher.setPhoneNumber(phoneNumber);
                researcher.setSpecialization(specialization);
                researcherDAO.addResearcher(researcher);
                System.out.println("Researcher added successfully.");
                break;
            case 2:
                System.out.print("Enter researcher ID: ");
                int researcherId = scanner.nextInt();
                Researcher researche = researcherDAO.getResearcher(researcherId);
                if (researche != null) {
                    System.out.println("Researcher ID: " + researche.getResearcherId());
                    System.out.println("Name: " + researche.getName());
                    System.out.println("Email: " + researche.getEmail());
                    System.out.println("Phone Number: " + researche.getPhoneNumber());
                    System.out.println("Specialization: " + researche.getSpecialization());
                } else {
                    System.out.println("Researcher not found.");
                }
                break;
            case 3:
                System.out.print("Enter researcher ID: ");
                int updateResearcherId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                Researcher updateResearcher = researcherDAO.getResearcher(updateResearcherId);
                if (updateResearcher != null) {
                    System.out.print("Enter new name: ");
                    updateResearcher.setName(scanner.nextLine());
                    System.out.print("Enter new email: ");
                    updateResearcher.setEmail(scanner.nextLine());
                    System.out.print("Enter new phone number: ");
                    updateResearcher.setPhoneNumber(scanner.nextLine());
                    System.out.print("Enter new specialization: ");
                    updateResearcher.setSpecialization(scanner.nextLine());
                    researcherDAO.updateResearcher(updateResearcher);
                    System.out.println("Researcher updated successfully.");
                } else {
                    System.out.println("Researcher not found.");
                }
                break;
            case 4:
                System.out.print("Enter researcher ID: ");
                int deleteResearcherId = scanner.nextInt();
                researcherDAO.deleteResearcher(deleteResearcherId);
                System.out.println("Researcher deleted successfully.");
                break;
            case 5:
                List<Researcher> researchers = researcherDAO.getAllResearchers();
                printResearcherTable(researchers);
            case 6: break;
            default:
                System.out.println("Invalid choice.");
                manageResearchers(scanner, researcherDAO);
        }
    }

    private static void printExperimentTable(List<Experiment> experiments) {
        System.out.println("--------------------------------------------------------------------");
        System.out.printf("%-15s %-20s %-20s %-15s %-15s%n", "Experiment ID", "Name", "Description", "Start Date", "End Date");
        System.out.println("--------------------------------------------------------------------");
        for (Experiment experiment : experiments) {
            System.out.printf("%-15d %-20s %-20s %-15s %-15s%n",
                    experiment.getExperimentId(),
                    experiment.getName(),
                    experiment.getDescription(),
                    experiment.getStartDate(),
                    experiment.getEndDate());
        }
        System.out.println("--------------------------------------------------------------------");
    }

    private static void printSampleTable(List<Sample> samples) {
        System.out.println("--------------------------------------------------------------------");
        System.out.printf("%-10s %-15s %-20s %-15s %-10s%n", "Sample ID", "Experiment ID", "Name", "Type", "Quantity");
        System.out.println("--------------------------------------------------------------------");
        for (Sample sample : samples) {
            System.out.printf("%-10d %-15d %-20s %-15s %-10d%n",
                    sample.getSampleId(),
                    sample.getExperimentId(),
                    sample.getName(),
                    sample.getType(),
                    sample.getQuantity());
        }
        System.out.println("--------------------------------------------------------------------");
    }

    private static void printResearcherTable(List<Researcher> researchers) {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.printf("%-15s %-20s %-30s %-15s %-20s%n", "Researcher ID", "Name", "Email", "Phone Number", "Specialization");
        System.out.println("---------------------------------------------------------------------------------");
        for (Researcher researcher : researchers) {
            System.out.printf("%-15d %-20s %-30s %-15s %-20s%n",
                    researcher.getResearcherId(),
                    researcher.getName(),
                    researcher.getEmail(),
                    researcher.getPhoneNumber(),
                    researcher.getSpecialization());
        }
        System.out.println("---------------------------------------------------------------------------------");
    }
}
