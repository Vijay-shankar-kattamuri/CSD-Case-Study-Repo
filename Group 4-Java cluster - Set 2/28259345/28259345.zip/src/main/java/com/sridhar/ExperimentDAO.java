package com.sridhar;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ExperimentDAO {
    public void addExperiment(Experiment experiment) {
        String sql = "INSERT INTO Experiment (name, description, start_date, end_date) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, experiment.getName());
            pstmt.setString(2, experiment.getDescription());
            pstmt.setDate(3, new Date(experiment.getStartDate().getTime()));
            pstmt.setDate(4, new Date(experiment.getEndDate().getTime()));
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding experiment: " + e.getMessage());
            // e.printStackTrace();
        }
    }

    public Experiment getExperiment(int experimentId) {
        String sql = "SELECT * FROM Experiment WHERE experiment_id = ?";
        Experiment experiment = null;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, experimentId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                experiment = new Experiment();
                experiment.setExperimentId(rs.getInt("experiment_id"));
                experiment.setName(rs.getString("name"));
                experiment.setDescription(rs.getString("description"));
                experiment.setStartDate(rs.getDate("start_date"));
                experiment.setEndDate(rs.getDate("end_date"));
            }
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Experiment not found: " + e.getMessage());
        }
        return experiment;
    }

    public void updateExperiment(Experiment experiment) {
        String sql = "UPDATE Experiment SET name = ?, description = ?, start_date = ?, end_date = ? WHERE experiment_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, experiment.getName());
            pstmt.setString(2, experiment.getDescription());
            pstmt.setDate(3, new Date(experiment.getStartDate().getTime()));
            pstmt.setDate(4, new Date(experiment.getEndDate().getTime()));
            pstmt.setInt(5, experiment.getExperimentId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Experiment not found: " + e.getMessage());
            // e.printStackTrace();
        }
    }

    public void deleteExperiment(int experimentId) {
        String sql = "DELETE FROM Experiment WHERE experiment_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, experimentId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Experiment not found: " + e.getMessage());
            // e.printStackTrace();
        }
    }

    public List<Experiment> getAllExperiments() {
        List<Experiment> experiments = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Experiment")) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Experiment experiment = new Experiment();
                experiment.setExperimentId(rs.getInt("experiment_id"));
                experiment.setName(rs.getString("name"));
                experiment.setDescription(rs.getString("description"));
                experiment.setStartDate(rs.getDate("start_date"));
                experiment.setEndDate(rs.getDate("end_date"));
                experiments.add(experiment);
            }
        } catch (SQLException e) {
            // e.printStackTrace();
            System.err.println("Error retreiving data from database: " + e.getMessage());
        }
        return experiments;
    }
}
