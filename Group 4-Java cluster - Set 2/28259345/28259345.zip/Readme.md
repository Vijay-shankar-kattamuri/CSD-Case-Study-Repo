# Data Management System

### This project is created for Cognizant by Sridhar (28259345)


## Objective

To develop a menu-based console application for labs using Core Java, MySQL and JDBC.
This application simulates a data management system

## How project is developed

This core java project is developed using Maven to handle dependencies easily like JDBC jar files. The entire project is modular. Seperate files for each functionality and class declarations.

Getters and setters are used to store and access private variables of the class.
Database is not accessed directly with the input data. Data is first stored in class object and specific function is called to access database to enter and retreive data to ensure database security.

There is no need to initailise any Database and table manually . This program itself developed to connect to local Database and create table and initalise them with the requiremnets.

All SQL Exception are handled. and User friendly error messages are displayed accordingly.

## How to run the program

As it is a Maven made core java project, open with any IDE with Maven support. This is made in Eclipse. The depencies are auto downloaded and configured as they are mentioned in *pom.xml* file.

The default password for MySQL data base is root. If your Database have specific password, please change the password field in *DatabaseConnection.java* and *DatabaseSetup.java*.

Load the program in IDE and run the *Main.java* file. The application runs in the console.



## How to use the app


The application is made user friendly with detailed in app instruction made using switch cases. 
Ensure that you provide the correct formated input as specified. ANyways the exceptions are handled with proper error statement for each cases. All SQL Exception are handled.

## Functionalities

### 1. Experiment Management
- Add a new experiment
- View experiment details
- Update experiment information
- Delete an experiment

### 2. Sample Managemnet
- Add a new sample
- View SAmple details
- Update sample information
- Delete sample

### 3. Researcher Management
- Add a new researcher
- View researcher details
- Update researcher info
- Delete a reseacher

## Database Schema

### Experiment Table:
- experiment_id (Primary Key)
- name
- description
- start_date
- end_date
### Sample Table:
- sample_id (Primary Key)
- experiment_id (Foreign Key references Experiment Table)
- name
- type
- quantity
### Researcher Table:
- researcher_id (Primary Key)
- name
- email
- phone_number
- specialization
