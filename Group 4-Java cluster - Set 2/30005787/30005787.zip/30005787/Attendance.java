import java.sql.Date;

public class Attendance {
	
	//private variables
    private int attendanceId;
    private int employeeId;
    private Date date;
   
	
  //public getters and setters
	public int getAttendanceId() {
		return attendanceId;
	}
	public void setAttendanceId(int attendanceId) {
		this.attendanceId = attendanceId;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private String status;
	
	
	//parameterized constructor
	public Attendance(int attendanceId, int employeeId, Date date, String status) {
		super();
		this.attendanceId = attendanceId;
		this.employeeId = employeeId;
		this.date = date;
		this.status = status;
	}
	
	
	//NO-Arg Constructor
	public Attendance() {
		super();
	}
	
	
	//ToString() method
	 @Override
		public String toString() {
			return "Attendance [attendanceId=" + attendanceId + ", employeeId=" + employeeId + ", date=" + date
					+ ", status=" + status + "]";
		}

}
