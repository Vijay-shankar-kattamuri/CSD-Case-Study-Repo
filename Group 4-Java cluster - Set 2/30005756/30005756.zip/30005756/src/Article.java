import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Article {
    public static void addArticle(Scanner scanner) {
        System.out.print("Enter magazine ID: ");
        int magazineId = scanner.nextInt();
        System.out.print("Enter title: ");
        String title = scanner.next();
        System.out.print("Enter author: ");
        String author = scanner.next();
        System.out.print("Enter content: ");
        String content = scanner.next();
        System.out.print("Enter publish date (YYYY-MM-DD): ");
        String publishDate = scanner.next();

        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Article (magazine_id, title, author, content, publish_date) VALUES (?, ?, ?, ?, ?)")) {
            pstmt.setInt(1, magazineId);
            pstmt.setString(2, title);
            pstmt.setString(3, author);
            pstmt.setString(4, content);
            pstmt.setDate(5, Date.valueOf(publishDate));
            pstmt.executeUpdate();
            System.out.println("Article added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewArticle(Scanner scanner) {
        System.out.print("Enter article ID: ");
        int id = scanner.nextInt();

        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Article WHERE article_id = ?")) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Author: " + rs.getString("author"));
                System.out.println("Content: " + rs.getString("content"));
                System.out.println("Publish Date: " + rs.getDate("publish_date"));
            } else {
                System.out.println("Article not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateArticle(Scanner scanner) {
        System.out.print("Enter article ID: ");
        int id = scanner.nextInt();
        System.out.print("Enter new title: ");
        String title = scanner.next();
        System.out.print("Enter new author: ");
        String author = scanner.next();
        System.out.print("Enter new content: ");
        String content = scanner.next();
        System.out.print("Enter new publish date (YYYY-MM-DD): ");
        String publishDate = scanner.next();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Article SET title = ?, author = ?, content = ?, publish_date = ? WHERE article_id = ?")) {
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setString(3, content);
            pstmt.setDate(4, Date.valueOf(publishDate));
            pstmt.setInt(5, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Article updated successfully.");
            } else {
                System.out.println("Article not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteArticle(Scanner scanner) {
        System.out.print("Enter article ID: ");
        int id = scanner.nextInt();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Article WHERE article_id = ?")) {
            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Article deleted successfully.");
            } else {
                System.out.println("Article not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
