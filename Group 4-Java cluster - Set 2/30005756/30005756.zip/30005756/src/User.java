import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class User {
    public static void addUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.next();
        System.out.print("Enter email: ");
        String email = scanner.next();
        System.out.print("Enter date of birth (YYYY-MM-DD): ");
        String dob = scanner.next();
        System.out.print("Enter registration date (YYYY-MM-DD): ");
        String regDate = scanner.next();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO User (username, email, date_of_birth, registration_date) VALUES (?, ?, ?, ?)")) {
            pstmt.setString(1, username);
            pstmt.setString(2, email);
            pstmt.setDate(3, Date.valueOf(dob));
            pstmt.setDate(4, Date.valueOf(regDate));
            pstmt.executeUpdate();
            System.out.println("User added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewUser(Scanner scanner) {
        System.out.print("Enter user ID: ");
        int id = scanner.nextInt();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM User WHERE user_id = ?")) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Username: " + rs.getString("username"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Date of Birth: " + rs.getDate("date_of_birth"));
                System.out.println("Registration Date: " + rs.getDate("registration_date"));
            } else {
                System.out.println("User not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateUser(Scanner scanner) {
        System.out.print("Enter user ID: ");
        int id = scanner.nextInt();
        System.out.print("Enter new username: ");
        String username = scanner.next();
        System.out.print("Enter new email: ");
        String email = scanner.next();
        System.out.print("Enter new date of birth (YYYY-MM-DD): ");
        String dob = scanner.next();
        System.out.print("Enter new registration date (YYYY-MM-DD): ");
        String regDate = scanner.next();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE User SET username = ?, email = ?, date_of_birth = ?, registration_date = ? WHERE user_id = ?")) {
            pstmt.setString(1, username);
            pstmt.setString(2, email);
            pstmt.setDate(3, Date.valueOf(dob));
            pstmt.setDate(4, Date.valueOf(regDate));
            pstmt.setInt(5, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("User updated successfully.");
            } else {
                System.out.println("User not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteUser(Scanner scanner) {
        System.out.print("Enter user ID: ");
        int id = scanner.nextInt();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM User WHERE user_id = ?")) {
            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("User deleted successfully.");
            } else {
                System.out.println("User not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
