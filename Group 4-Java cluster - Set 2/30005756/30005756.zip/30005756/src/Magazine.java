import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Magazine {
	
    public static void addMagazine(Scanner scanner) {
        System.out.print("Enter title: ");
        String title = scanner.next();
        System.out.print("Enter genre: ");
        String genre = scanner.next();
        System.out.print("Enter publication frequency: ");
        String frequency = scanner.next();
        System.out.print("Enter publisher: ");
        String publisher = scanner.next();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Magazine (title, genre, publication_frequency, publisher) VALUES (?, ?, ?, ?)")) {
            pstmt.setString(1, title);
            pstmt.setString(2, genre);
            pstmt.setString(3, frequency);
            pstmt.setString(4, publisher);
            pstmt.executeUpdate();
            System.out.println("Magazine added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewMagazine(Scanner scanner) {
        System.out.print("Enter magazine ID: ");
        int id = scanner.nextInt();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Magazine WHERE magazine_id = ?")) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Genre: " + rs.getString("genre"));
                System.out.println("Publication Frequency: " + rs.getString("publication_frequency"));
                System.out.println("Publisher: " + rs.getString("publisher"));
            } else {
                System.out.println("Magazine not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateMagazine(Scanner scanner) {
        System.out.print("Enter magazine ID: ");
        int id = scanner.nextInt();
        System.out.print("Enter new title: ");
        String title = scanner.next();
        System.out.print("Enter new genre: ");
        String genre = scanner.next();
        System.out.print("Enter new publication frequency: ");
        String frequency = scanner.next();
        System.out.print("Enter new publisher: ");
        String publisher = scanner.next();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Magazine SET title = ?, genre = ?, publication_frequency = ?, publisher = ? WHERE magazine_id = ?")) {
            pstmt.setString(1, title);
            pstmt.setString(2, genre);
            pstmt.setString(3, frequency);
            pstmt.setString(4, publisher);
            pstmt.setInt(5, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Magazine updated successfully.");
            } else {
                System.out.println("Magazine not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteMagazine(Scanner scanner) {
        System.out.print("Enter magazine ID: ");
        int id = scanner.nextInt();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Magazine WHERE magazine_id = ?")) {
            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Magazine deleted successfully.");
            } else {
                System.out.println("Magazine not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
