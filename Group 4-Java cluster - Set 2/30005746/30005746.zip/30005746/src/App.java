public class App {
    public static void main(String[] args) {
        FeedbackManagementSystem fms = new FeedbackManagementSystem();
        fms.start();
    }
}
