import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.Scanner;

public class FeedbackManagementSystem {
    private static final String URL = "jdbc:mysql://localhost:3306/Customer_Feedback_MS";
    private static final String USER = "root";
    private static final String PASSWORD = "1234";
    Connection connection;
    Scanner sc;

    FeedbackManagementSystem() {
        sc = new Scanner(System.in);
        connection = null;
    }

    public void start() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver Loaded Successfully!");

            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to Database!");


            int choice = -1;
            
            while(choice != 0) {
                System.out.println("1. Manage Feedback");
                System.out.println("2. Manage Analysis");
                System.out.println("3. Manage Responses");
                System.out.println("0. Exit");
                System.out.print("Choose an option: ");

                choice = sc.nextInt();
                System.out.println("---------------------------------------------\n");

                switch (choice) {
                    case 1:
                        manageFeedback();
                        break;
                    case 2:
                        manageAnalysis();
                        break;
                    case 3:
                        manageResponses();
                        break;
                    case 0:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }

                System.out.println("---------------------------------------------");
                System.out.println("---------------------------------------------\n");
            }

            connection.close();
             
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            System.out.println("Unable to load Driver!!!");
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to connect to Database!!!");
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            System.out.println("Exited");
            sc.close();
        }
    }




    private void recordFeedback() {
        System.out.print("Enter your Customer ID: ");
        int cid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Your Name: ");
        String name = sc.nextLine();
        System.out.println("Write your Feedback:");
        String fb = sc.nextLine();

        try {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO Customer(customer_id, customer_name) VALUES (?,?);");
            stmt.setInt(1, cid);
            stmt.setString(2, name);
            try {
                stmt.executeUpdate();
            } catch (SQLException e) {
                // If customer is already registered
            }


            stmt = connection.prepareStatement("INSERT INTO Feedback (customer_id, feedback_date, feedback_text, status) VALUES (?, ?, ?, ?)");
            stmt.setInt(1, cid);
            stmt.setDate(2, new Date(System.currentTimeMillis()));
            stmt.setString(3, fb);
            stmt.setString(4, "New");
            stmt.executeUpdate();

            System.out.println("Feedback Recorded Successfully!!");

            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to insert!!!");
        }
    }
    private void viewFeedback() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet res = stmt.executeQuery("Select * From Feedback");
            
            boolean fg = false;
            System.out.println("********************************************\n");
            while(res.next()) {
                fg = true;
                System.out.println("Feedback Id: " + res.getInt(1));
                System.out.println("Customer Id: " + res.getInt(2));
                System.out.println("Date: " + res.getDate(3));
                System.out.println("Feedback: " + res.getString(4));
                System.out.println("Status: " + res.getString(5));
                System.out.println("********************************************\n");
            }

            if(!fg) System.out.println("No result found!!!");

            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to fetch!!!");
        }
    }
    private void updateFeedbackStatus() {
        System.out.print("Enter Feedback Id: ");
        int fid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter new status: ");
        String status = sc.nextLine();

        try {
            Statement stmt = connection.createStatement();
            stmt.executeUpdate("UPDATE Feedback SET status = '" + status + "' where feedback_id = " + fid + ";");
            System.out.println("Updated Successfully!!");
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to Update!!!");
        }
    }
    private void deleteFeedback() {
        System.out.print("Enter Feedback Id to Delete: ");
        int fid = sc.nextInt();

        try {
            Statement stmt = connection.createStatement();
            stmt.executeUpdate("Delete From Feedback where feedback_id = " + fid + ";");
            System.out.println("Deleted Successfully!!");
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to delete!!!");
        }
    }
    private void manageFeedback() {
        System.out.println("1. Record new feedback");
        System.out.println("2. View feedback details");
        System.out.println("3. Update feedback status");
        System.out.println("4. Delete a feedback entry");
        System.out.print("Enter your choice: ");

        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                recordFeedback();
                break;
            case 2:
                viewFeedback();
                break;
            case 3:
                updateFeedbackStatus();
                break;
            case 4:
                deleteFeedback();
                break;
            default:
                System.out.println("Invalid choice!!!");
                break;
        }
    }



    private void addAnalysis() {
        System.out.print("Enter the Feedback ID: ");
        int fid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Analysis Details: ");
        String details = sc.nextLine();

        try {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO Analysis (feedback_id, analysis_date, analysis_details, status) VALUES (?, ?, ?, ?)");
            stmt.setInt(1, fid);
            stmt.setDate(2, new Date(System.currentTimeMillis()));
            stmt.setString(3, details);
            stmt.setString(4, "New");
            stmt.executeUpdate();

            System.out.println("Analysis Added Successfully!!");

            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to Add!!!");
        }
    }
    private void viewAnalysis() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet res = stmt.executeQuery("Select * From Analysis");
            
            boolean fg = false;
            System.out.println("********************************************\n");
            while(res.next()) {
                fg = true;
                System.out.println("Analysis Id: " + res.getInt(1));
                System.out.println("Feedback Id: " + res.getInt(2));
                System.out.println("Date: " + res.getDate(3));
                System.out.println("Details: " + res.getString(4));
                System.out.println("Status: " + res.getString(5));
                System.out.println("********************************************\n");
            }

            if(!fg) System.out.println("No result found!!!");

            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to fetch!!!");
        }
    }
    private void updateAnalysis() {
        System.out.print("Enter Analysis Id: ");
        int aid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter new Analysis Details: ");
        String details = sc.nextLine();

        try {
            Statement stmt = connection.createStatement();
            stmt.executeUpdate("UPDATE Analysis SET analysis_details = '" + details + "', analysis_date = '" + new Date(System.currentTimeMillis()) + "' where analysis_id = " + aid + ";");
            System.out.println("Updated Successfully!!");
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to Update!!!");
        }
    }
    private void deleteAnalysis() {
        System.out.print("Enter Analysis Id to Delete: ");
        int aid = sc.nextInt();

        try {
            Statement stmt = connection.createStatement();
            stmt.executeUpdate("Delete From Analysis where analysis_id = " + aid + ";");
            System.out.println("Deleted Successfully!!");
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to delete!!!");
        }
    }
    private void manageAnalysis() {
        System.out.println("1. Add Analysis of Feedback");
        System.out.println("2. View analysis reports");
        System.out.println("3. Update analysis information");
        System.out.println("4. Delete an analysis record");
        System.out.print("Enter your choice: ");

        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                addAnalysis();
                break;
            case 2:
                viewAnalysis();
                break;
            case 3:
                updateAnalysis();
                break;
            case 4:
                deleteAnalysis();
                break;
            default:
                System.out.println("Invalid choice!!!");
                break;
        }
    }






    private void addResponse() {
        System.out.print("Enter the Feedback ID to responed: ");
        int fid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Response: ");
        String text = sc.nextLine();

        try {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO Response (feedback_id, response_date, response_text, status) VALUES (?, ?, ?, ?)");
            stmt.setInt(1, fid);
            stmt.setDate(2, new Date(System.currentTimeMillis()));
            stmt.setString(3, text);
            stmt.setString(4, "New");
            stmt.executeUpdate();

            System.out.println("Responsed Successfully!!");

            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to Responed!!!");
        }
    }
    private void viewResponse() {
        try {
            Statement stmt = connection.createStatement();
            ResultSet res = stmt.executeQuery("Select * From Response;");
            
            boolean fg = false;
            System.out.println("********************************************\n");
            while(res.next()) {
                fg = true;
                System.out.println("Response Id: " + res.getInt(1));
                System.out.println("Feedback Id: " + res.getInt(2));
                System.out.println("Date: " + res.getDate(3));
                System.out.println("Response: " + res.getString(4));
                System.out.println("Status: " + res.getString(5));
                System.out.println("********************************************\n");
            }

            if(!fg) System.out.println("No result found!!!");

            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to fetch!!!");
        }
    }
    private void updateResponse() {
        System.out.print("Enter Response Id: ");
        int rid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter new response information: ");
        String info = sc.nextLine();

        try {
            Statement stmt = connection.createStatement();
            stmt.executeUpdate("UPDATE Response SET response_text = '" + info + "', response_date = '" + new Date(System.currentTimeMillis()) + "' where response_id = " + rid + ";");
            System.out.println("Updated Successfully!!");
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to Update!!!");
        }
    }
    private void deleteResponse() {
        System.out.print("Enter Response Id to Delete: ");
        int rid = sc.nextInt();

        try {
            Statement stmt = connection.createStatement();
            stmt.executeUpdate("Delete From Response where response_id = " + rid + ";");
            System.out.println("Deleted Successfully!!");
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Unable to delete!!!");
        }
    }
    private void manageResponses() {
        System.out.println("1. Add Response of Feedback");
        System.out.println("2. View response history");
        System.out.println("3. Update response information");
        System.out.println("4. Delete an response record");
        System.out.print("Enter your choice: ");

        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                addResponse();
                break;
            case 2:
                viewResponse();
                break;
            case 3:
                updateResponse();
                break;
            case 4:
                deleteResponse();
                break;
            default:
                System.out.println("Invalid choice!!!");
                break;
        }
    }

}
