import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    private static final String dbURL = "jdbc:mysql://localhost:3306/Automobile_Inventory";
    private static final String username = "root";
    private static final String password = "coutArya7eet";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
            VehicleManager vehicleManager = new VehicleManager(connection);
            CustomerManager customerManager = new CustomerManager(connection);
            SalesTransactionManager salesTransactionManager = new SalesTransactionManager(connection);

            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("Automobile Inventory Management System");
                System.out.println("1. Manage Vehicles");
                System.out.println("2. Manage Customers");
                System.out.println("3. Manage Sales Transactions");
                System.out.println("4. Exit");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        vehicleManager.menu();
                        break;
                    case 2:
                        customerManager.menu();
                        break;
                    case 3:
                        salesTransactionManager.menu();
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

class VehicleManager {
    private Connection connection;

    public VehicleManager(Connection connection) {
        this.connection = connection;
    }

    public void menu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Vehicle Management");
            System.out.println("1. Add Vehicle");
            System.out.println("2. View Vehicles");
            System.out.println("3. Update Vehicle");
            System.out.println("4. Delete Vehicle");
            System.out.println("5. Back to Main Menu");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addVehicle();
                    break;
                case 2:
                    viewVehicles();
                    break;
                case 3:
                    updateVehicle();
                    break;
                case 4:
                    deleteVehicle();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Add a vehicle
    public void addVehicle() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter vehicle ID: ");
        int vehicleId = scanner.nextInt();
        System.out.println("Enter vehicle make: ");
        String make = scanner.next();
        System.out.println("Enter vehicle model: ");
        String model = scanner.next();
        System.out.println("Enter vehicle year: ");
        int year = scanner.nextInt();
        System.out.println("Enter vehicle price: ");
        double price = scanner.nextDouble();
        System.out.println("Enter available quantity: ");
        int quantity = scanner.nextInt();

        String sql = "INSERT INTO Vehicle VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vehicleId);
            stmt.setString(2, make);
            stmt.setString(3, model);
            stmt.setInt(4, year);
            stmt.setDouble(5, price);
            stmt.setInt(6, quantity);
            stmt.executeUpdate();
            System.out.println("Vehicle added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View vehicles
    public void viewVehicles() {
        String sql = "SELECT * FROM Vehicle";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("vehicle_id"));
                System.out.println("Make: " + rs.getString("make"));
                System.out.println("Model: " + rs.getString("model"));
                System.out.println("Year: " + rs.getInt("year"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Available Quantity: " + rs.getInt("available_quantity"));
                System.out.println("---------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update vehicle details
    public void updateVehicle() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter vehicle ID to update: ");
        int id = scanner.nextInt();
        System.out.println("Enter new make: ");
        String make = scanner.next();
        System.out.println("Enter new model: ");
        String model = scanner.next();
        System.out.println("Enter new year: ");
        int year = scanner.nextInt();
        System.out.println("Enter new price: ");
        double price = scanner.nextDouble();
        System.out.println("Enter new available quantity: ");
        int quantity = scanner.nextInt();

        String sql = "UPDATE Vehicle SET make = ?, model = ?, year = ?, price = ?, available_quantity = ? WHERE vehicle_id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, make);
            stmt.setString(2, model);
            stmt.setInt(3, year);
            stmt.setDouble(4, price);
            stmt.setInt(5, quantity);
            stmt.setInt(6, id);
            stmt.executeUpdate();
            System.out.println("Vehicle updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete a vehicle
    public void deleteVehicle() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter vehicle ID to delete: ");
        int id = scanner.nextInt();

        String sql = "DELETE FROM Vehicle WHERE vehicle_id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Vehicle deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

class CustomerManager {
    private Connection connection;

    public CustomerManager(Connection connection) {
        this.connection = connection;
    }

    // Customer menu
    public void menu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Customer Management");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customers");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCustomer();
                    break;
                case 2:
                    viewCustomers();
                    break;
                case 3:
                    updateCustomer();
                    break;
                case 4:
                    deleteCustomer();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Add a customer
    public void addCustomer() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.println("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.println("Enter customer phone number: ");
        String phoneNumber = scanner.nextLine();

        String sql = "INSERT INTO Customer VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            stmt.setString(2, name);
            stmt.setString(3, email);
            stmt.setString(4, phoneNumber);
            stmt.executeUpdate();
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View customers
    public void viewCustomers() {
        String sql = "SELECT * FROM Customer";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("customer_name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("---------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update customer credentials
    public void updateCustomer() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter customer ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter new name: ");
        String name = scanner.nextLine();
        System.out.println("Enter new email: ");
        String email = scanner.nextLine();
        System.out.println("Enter new phone number: ");
        String phoneNumber = scanner.nextLine();

        String sql = "UPDATE Customer SET customer_name = ?, email = ?, phone_number = ? WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phoneNumber);
            stmt.setInt(4, id);
            stmt.executeUpdate();
            System.out.println("Customer updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete a customer
    public void deleteCustomer() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer ID to delete: ");
        int id = scanner.nextInt();

        String sql = "DELETE FROM Customer WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Customer deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

class SalesTransactionManager {
    private Connection connection;

    public SalesTransactionManager(Connection connection) {
        this.connection = connection;
    }

    // Sales Transaction menu
    public void menu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Sales Transaction Management");
            System.out.println("1. Record Sale");
            System.out.println("2. View Sales Transactions");
            System.out.println("3. Generate Sales Report");
            System.out.println("4. Back to Main Menu");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    recordSale();
                    break;
                case 2:
                    viewSalesTransactions();
                    break;
                case 3:
                    generateSalesReport();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Record a sale
    public void recordSale() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter transaction ID: ");
        int transactionId = scanner.nextInt();
        System.out.println("Enter vehicle ID: ");
        int vehicleId = scanner.nextInt();
        System.out.println("Enter customer ID: ");
        int customerId = scanner.nextInt();
        System.out.println("Enter transaction date (YYYY-MM-DD): ");
        String date = scanner.next();
        System.out.println("Enter amount: ");
        double amount = scanner.nextDouble();

        String sql = "INSERT INTO SalesTransaction VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, transactionId);
            stmt.setInt(2, vehicleId);
            stmt.setInt(3, customerId);
            stmt.setDate(4, java.sql.Date.valueOf(date));
            stmt.setDouble(5, amount);
            stmt.executeUpdate();
            System.out.println("Sale recorded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View sales transactions
    public void viewSalesTransactions() {
        String sql = "SELECT * FROM SalesTransaction";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Transaction Date: " + rs.getDate("transaction_date"));
                System.out.println("Amount: " + rs.getDouble("amount"));
                System.out.println("---------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Generate sales report
    public void generateSalesReport() {
        String sql = "SELECT vehicle_id, SUM(amount) AS total_sales FROM SalesTransaction GROUP BY vehicle_id";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Total Sales: " + rs.getDouble("total_sales"));
                System.out.println("---------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}