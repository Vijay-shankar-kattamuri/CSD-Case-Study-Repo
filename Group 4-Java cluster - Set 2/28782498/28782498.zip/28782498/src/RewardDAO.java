import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RewardDAO {

    public void addReward(Reward reward) {
        String query = "INSERT INTO Reward (name, points_required, description) VALUES (?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, reward.getName());
            stmt.setInt(2, reward.getPointsRequired());
            stmt.setString(3, reward.getDescription());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Reward getReward(int rewardId) {
        String query = "SELECT * FROM Reward WHERE reward_id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, rewardId);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()) {
                return new Reward(rs.getInt("reward_id"), rs.getString("name"), rs.getInt("points_required"), rs.getString("description"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateReward(Reward reward) {
        String query = "UPDATE Reward SET name = ?, points_required = ?, description = ? WHERE reward_id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, reward.getName());
            stmt.setInt(2, reward.getPointsRequired());
            stmt.setString(3, reward.getDescription());
            stmt.setInt(4, reward.getRewardId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteReward(int rewardId) {
        String query = "DELETE FROM Reward WHERE reward_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, rewardId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

