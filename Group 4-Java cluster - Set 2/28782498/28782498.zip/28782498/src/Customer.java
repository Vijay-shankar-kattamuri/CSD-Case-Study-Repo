
public class Customer {
    private int Customer_Id;
    private String name;
    private String email;
    private String phone;
    private int Total_Points;
	

    // Constructor for creating a new customer
    public Customer(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    // Constructor for retrieving a customer from the database
    public Customer(int customerId, String name, String email, String phone, int totalPoints) {
        this.Customer_Id = customerId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.Total_Points = totalPoints;
    }

    // Getters and setters
    public int getCustomerId() {
        return Customer_Id;
    }

    public void setCustomerId(int customerId) {
        this.Customer_Id = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getTotalPoints() {
        return Total_Points;
    }

    public void setTotalPoints(int totalPoints) {
        this.Total_Points = totalPoints;
    }
}
