import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PurchaseDAO {

    public void addPurchase(Purchase purchase) {
        String query = "INSERT INTO Purchase (customer_id, reward_id, purchase_date, points_earned) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, purchase.getCustomerId());
            stmt.setInt(2, purchase.getRewardId());
            stmt.setDate(3, purchase.getPurchaseDate());
            stmt.setInt(4, purchase.getPointsEarned());
            stmt.executeUpdate();

            // Update customer points
            updateCustomerPoints(purchase.getCustomerId(), purchase.getPointsEarned());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Purchase getPurchase(int purchaseId){
        String query = "SELECT * FROM Purchase WHERE purchase_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, purchaseId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Purchase(rs.getInt("purchase_id"), rs.getInt("customer_id"), rs.getInt("reward_id"), rs.getDate("purchase_date"), rs.getInt("points_earned"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updatePurchase(Purchase purchase) {
        String query = "UPDATE Purchase SET customer_id = ?, reward_id = ?, purchase_date = ?, points_earned = ? WHERE purchase_id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, purchase.getCustomerId());
            stmt.setInt(2, purchase.getRewardId());
            stmt.setDate(3, purchase.getPurchaseDate());
            stmt.setInt(4, purchase.getPointsEarned());
            stmt.setInt(5, purchase.getPurchaseId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePurchase(int purchaseId) {
        String query = "DELETE FROM Purchase WHERE purchase_id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, purchaseId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateCustomerPoints(int customerId, int points) {
        String query = "UPDATE Customer SET total_points = total_points + ? WHERE customer_id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, points);
            stmt.setInt(2, customerId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
