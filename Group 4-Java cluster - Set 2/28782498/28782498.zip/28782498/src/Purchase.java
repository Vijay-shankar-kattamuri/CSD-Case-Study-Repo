
import java.sql.Date;

public class Purchase {
    private int Purchase_Id;
    private int Customer_Id;
    private int Reward_Id;
    private Date PurchaseDate;
    private int PointsEarned;

    // Constructor for creating a new purchase
    public Purchase(int customerId, int rewardId, Date purchaseDate, int pointsEarned) {
        this.Customer_Id = customerId;
        this.Reward_Id = rewardId;
        this.PurchaseDate = purchaseDate;
        this.PointsEarned = pointsEarned;
    }

    // Constructor for retrieving a purchase from the database
    public Purchase(int purchaseId, int customerId, int rewardId, Date purchaseDate, int pointsEarned) {
        this.Purchase_Id = purchaseId;
        this.Customer_Id = customerId;
        this.Reward_Id = rewardId;
        this.PurchaseDate = purchaseDate;
        this.PointsEarned = pointsEarned;
    }

    // Getters and setters
    public int getPurchaseId() {
        return Purchase_Id;
    }

    public void setPurchaseId(int purchaseId) {
        this.Purchase_Id = purchaseId;
    }

    public int getCustomerId() {
        return Customer_Id;
    }

    public void setCustomerId(int customerId) {
        this.Customer_Id = customerId;
    }

    public int getRewardId() {
        return Reward_Id;
    }

    public void setRewardId(int rewardId) {
        this.Reward_Id = rewardId;
    }

    public Date getPurchaseDate() {
        return PurchaseDate;
    }

    public void setPurchaseDate(Date purchaseDate) {
        this.PurchaseDate = purchaseDate;
    }

    public int getPointsEarned() {
        return PointsEarned;
    }

    public void setPointsEarned(int pointsEarned) {
        this.PointsEarned = pointsEarned;
    }
}

