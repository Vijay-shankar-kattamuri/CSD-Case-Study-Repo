
import java.sql.*;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final CustomerDAO customerDAO = new CustomerDAO();
    private static final RewardDAO rewardDAO = new RewardDAO();
    private static final PurchaseDAO purchaseDAO = new PurchaseDAO();

    public static void main(String[] args) {
        while (true) {
            showMenu();
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addCustomer();
                    break;
                case 2:
                    viewCustomer();
                    break;
                case 3:
                    updateCustomer();
                    break;
                case 4:
                    deleteCustomer();
                    break;
                case 5:
                    addReward();
                    break;
                case 6:
                    viewReward();
                    break;
                case 7:
                    updateReward();
                    break;
                case 8:
                    deleteReward();
                    break;
                case 9:
                    addPurchase();
                    break;
                case 10:
                    viewPurchase();
                    break;
                case 11:
                    updatePurchase();
                    break;
                case 12:
                    deletePurchase();
                    break;
                case 0:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("Customer Loyalty Program");
        System.out.println("1. Add a new customer");
        System.out.println("2. View customer details");
        System.out.println("3. Update customer information");
        System.out.println("4. Delete a customer");
        System.out.println("5. Add a new reward");
        System.out.println("6. View reward details");
        System.out.println("7. Update reward information");
        System.out.println("8. Delete a reward");
        System.out.println("9. Add a new purchase");
        System.out.println("10. View purchase details");
        System.out.println("11. Update purchase information");
        System.out.println("12. Delete a purchase");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addCustomer() {
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter email: ");
        String email = sc.nextLine();
        System.out.print("Enter phone: ");
        String phone = sc.nextLine();
        

        Customer customer = new Customer(name, email, phone);
        customerDAO.addCustomer(customer);
        System.out.println("Customer added successfully.");
    }

    private static void viewCustomer() {
        System.out.print("Enter customer ID: ");
        int customerId = sc.nextInt();
        sc.nextLine(); // consume newline

        Customer customer = customerDAO.getCustomer(customerId);
        if (customer != null) {
            System.out.println("Customer ID: " + customer.getCustomerId());
            System.out.println("Name: " + customer.getName());
            System.out.println("Email: " + customer.getEmail());
            System.out.println("Phone: " + customer.getPhone());
            System.out.println("Total Points: " + customer.getTotalPoints());
        } else {
            System.out.println("Customer not found.");
        }
    }

    private static void updateCustomer() {
        System.out.print("Enter customer ID: ");
        int customerId = sc.nextInt();
        sc.nextLine(); 

        System.out.print("Enter new name: ");
        String name = sc.nextLine();
        System.out.print("Enter new email: ");
        String email = sc.nextLine();
        System.out.print("Enter new phone: ");
        String phone = sc.nextLine();
        sc.nextLine();

        Customer customer = new Customer(customerId, name, email, phone, 0); // 0 for Total_points as it won't be updated here
        customerDAO.updateCustomer(customer);
        System.out.println("Customer updated successfully.");
    }

    private static void deleteCustomer() {
        System.out.print("Enter customer ID: ");
        int customerId = sc.nextInt();
        sc.nextLine(); // consume newline
        sc.nextLine();

        customerDAO.deleteCustomer(customerId);
        System.out.println("Customer deleted successfully.");
    }

    private static void addReward() {
        System.out.print("Enter reward name: ");
        String name = sc.nextLine();
        System.out.print("Enter points required: ");
        int pointsRequired = sc.nextInt();
        sc.nextLine(); // consume newline
        System.out.print("Enter description: ");
        String description = sc.nextLine();

        Reward reward = new Reward(name, pointsRequired, description);
        rewardDAO.addReward(reward);
        System.out.println("Reward added successfully.");
    }

    private static void viewReward() {
        System.out.print("Enter reward ID: ");
        int rewardId = sc.nextInt();
        sc.nextLine(); // consume newline

        Reward reward = rewardDAO.getReward(rewardId);
        if (reward != null) {
            System.out.println("Reward ID: " + reward.getRewardId());
            System.out.println("Name: " + reward.getName());
            System.out.println("Points Required: " + reward.getPointsRequired());
            System.out.println("Description: " + reward.getDescription());
        } else {
            System.out.println("Reward not found.");
        }
    }

    private static void updateReward() {
        System.out.print("Enter reward ID: ");
        int rewardId = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter new reward name: ");
        String name = sc.nextLine();
        System.out.print("Enter new points required: ");
        int pointsRequired = sc.nextInt();
        sc.nextLine(); // consume newline
        System.out.print("Enter new description: ");
        String description = sc.nextLine();

        Reward reward = new Reward(rewardId, name, pointsRequired, description);
        rewardDAO.updateReward(reward);
        System.out.println("Reward updated successfully.");
    }

    private static void deleteReward() {
        System.out.print("Enter reward ID: ");
        int rewardId = sc.nextInt();
        sc.nextLine(); // consume newline

        rewardDAO.deleteReward(rewardId);
        System.out.println("Reward deleted successfully.");
    }

    private static void addPurchase() {
        System.out.print("Enter customer ID: ");
        int customerId = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter reward ID: ");
        int rewardId = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter purchase date (yyyy-mm-dd): ");
        String dateStr = sc.nextLine();
        Date purchaseDate = Date.valueOf(dateStr);

        System.out.print("Enter points earned: ");
        int pointsEarned = sc.nextInt();
        sc.nextLine(); // consume newline

        Purchase purchase = new Purchase(customerId, rewardId, purchaseDate, pointsEarned);
        purchaseDAO.addPurchase(purchase);
        System.out.println("Purchase added successfully.");
    }

    private static void viewPurchase() {
        System.out.print("Enter purchase ID: ");
        int purchaseId = sc.nextInt();
        sc.nextLine(); // consume newline

        Purchase purchase = purchaseDAO.getPurchase(purchaseId);
        if (purchase != null) {
            System.out.println("Purchase ID: " + purchase.getPurchaseId());
            System.out.println("Customer ID: " + purchase.getCustomerId());
            System.out.println("Reward ID: " + purchase.getRewardId());
            System.out.println("Purchase Date: " + purchase.getPurchaseDate());
            System.out.println("Points Earned: " + purchase.getPointsEarned());
        } else {
            System.out.println("Purchase not found.");
        }
    }

    private static void updatePurchase() {
        System.out.print("Enter purchase ID: ");
        int purchaseId = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter new customer ID: ");
        int customerId = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter new reward ID: ");
        int rewardId = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter new purchase date (yyyy-mm-dd): ");
        String dateStr = sc.nextLine();
        Date purchaseDate = Date.valueOf(dateStr);

        System.out.print("Enter new points earned: ");
        int pointsEarned = sc.nextInt();
        sc.nextLine(); // consume newline

        Purchase purchase = new Purchase(purchaseId, customerId, rewardId, purchaseDate, pointsEarned);
        purchaseDAO.updatePurchase(purchase);
        System.out.println("Purchase updated successfully.");
    }

    private static void deletePurchase() {
        System.out.print("Enter purchase ID: ");
        int purchaseId = sc.nextInt();
        sc.nextLine(); // consume newline

        purchaseDAO.deletePurchase(purchaseId);
        System.out.println("Purchase deleted successfully.");
    }
}

