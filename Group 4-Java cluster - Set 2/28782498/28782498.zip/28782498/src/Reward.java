
public class Reward {
    private int Reward_Id;
    private String Name;
    private int PointsRequired;
    private String Description;

    // Constructor for creating a new reward
    public Reward(String name, int pointsRequired, String description) {
        this.Name = name;
        this.PointsRequired = pointsRequired;
        this.Description = description;
    }

    // Constructor for retrieving a reward from the database
    public Reward(int rewardId, String name, int pointsRequired, String description) {
        this.Reward_Id = rewardId;
        this.Name = name;
        this.PointsRequired = pointsRequired;
        this.Description = description;
    }

    // Getters and setters
    public int getRewardId() {
        return Reward_Id;
    }

    public void setRewardId(int rewardId) {
        this.Reward_Id = rewardId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public int getPointsRequired() {
        return PointsRequired;
    }

    public void setPointsRequired(int pointsRequired) {
        this.PointsRequired = pointsRequired;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        this.Description = description;
    }
}

