import java.sql.*;

public class DatabaseConnection {
    private static final String url = "jdbc:mysql://localhost:3306/CustomerLoyalityProgram";
    private static final String user = "Benita";
    private static final String password="Pass";
    
    // Establish a connection  to a MySql Database called CustomerLoyalityProgram
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }
}

	
	
	
/*This code defines a class DatabaseConnection that helps establish a connection to a MySQL database called CustomerLoyalityProgram 
 * running on the local machine. The getConnection method uses the DriverManager class to create a connection using the specified URL, 
 * username, and password.
 */