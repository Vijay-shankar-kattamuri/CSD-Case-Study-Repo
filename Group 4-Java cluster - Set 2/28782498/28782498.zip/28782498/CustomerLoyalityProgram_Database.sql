Create Database CustomerLoyalityProgram;
use CustomerLoyalityProgram;

CREATE TABLE Customer (
    Customer_Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Phone VARCHAR(15) UNIQUE NOT NULL,
    Total_Points INT DEFAULT 0
);

INSERT INTO Customer (Name, Email, Phone, Total_Points) VALUES 
('Benita', 'benita@gmail.com', '897614532', 100),
('Anita', 'Anita@gmail.com', '785414532', 200),
('Reeda', 'reeda@gmail.com', '8903502240', 300);

SELECT* FROM Customer;


CREATE TABLE Reward (
    Reward_Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Points_Required INT NOT NULL,
    Description TEXT
);

INSERT INTO Reward (Name, Points_Required, Description) VALUES 
('10% Off Coupon', 100, 'A coupon for 10% off your next purchase.'),
('Free Coffee', 200, 'A coupon for a free coffee.'),
('Gift Card', 300, 'A $10 gift card.');

SELECT * FROM Reward;

CREATE TABLE Purchase (
    Purchase_Id INT AUTO_INCREMENT PRIMARY KEY,
    Customer_Id INT,
    Reward_Id INT,
    Purchase_Date DATE NOT NULL,
    Points_Earned INT NOT NULL,
    FOREIGN KEY (Customer_Id) REFERENCES Customer(Customer_Id),
    FOREIGN KEY (Reward_Id) REFERENCES Reward(Reward_Id)
);

INSERT INTO Purchase (customer_id, reward_id, purchase_date, points_earned) VALUES 
(1, 1, '2024-07-01', 100),
(2, 2, '2024-07-02', 200),
(3, 3, '2024-07-03', 300);

SELECT * FROM Purchase;





