package com.aman.carservice;
// main Driver Program for the project

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Car Service Appointment Scheduling System");
            System.out.println("1. Manage Appointments");
            System.out.println("2. Manage Customers");
            System.out.println("3. Manage Services");
            System.out.println("4. Exit");
            System.out.print("//nChoose an option: ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    AppointmentManagement.manageAppointments();
                    break;
                case 2:
                    CustomerManagement.manageCustomers();
                    break;
                case 3:
                    ServiceManagement.manageServices();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
}