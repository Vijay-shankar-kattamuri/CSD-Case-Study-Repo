package com.aman.carservice;
// Program to manage the services
import java.sql.*;
import java.util.Scanner;

public class ServiceManagement {

    public static void manageServices() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Service Management");
            System.out.println("1. Add New Service");
            System.out.println("2. View Service Details");
            System.out.println("3. Update Service Information");
            System.out.println("4. Delete Service");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {  // case statements to select between options
                case 1:
                    addNewService();
                    break;
                case 2:
                    viewServiceDetails();
                    break;
                case 3:
                    updateServiceInformation();
                    break;
                case 4:
                    deleteService();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void addNewService() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter service name: ");
            String serviceName = scanner.nextLine();
            System.out.print("Enter description: ");
            String description = scanner.nextLine();
            System.out.print("Enter duration (in minutes): ");
            int duration = scanner.nextInt();
            System.out.print("Enter price: ");
            double price = scanner.nextDouble();

            String sql = "INSERT INTO Service (service_name, description, duration, price) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, serviceName);
            statement.setString(2, description);
            statement.setInt(3, duration);
            statement.setDouble(4, price);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new service was added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewServiceDetails() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter service ID: ");
            int serviceId = scanner.nextInt();

            String sql = "SELECT * FROM Service WHERE service_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, serviceId);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                System.out.println("Service ID: " + resultSet.getInt("service_id"));
                System.out.println("Service Name: " + resultSet.getString("service_name"));
                System.out.println("Description: " + resultSet.getString("description"));
                System.out.println("Duration: " + resultSet.getInt("duration") + " minutes");
                System.out.println("Price: $" + resultSet.getDouble("price"));
            } else {
                System.out.println("Service not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateServiceInformation() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter service ID to update: ");
            int serviceId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new service name: ");
            String serviceName = scanner.nextLine();
            System.out.print("Enter new description: ");
            String description = scanner.nextLine();
            System.out.print("Enter new duration (in minutes): ");
            int duration = scanner.nextInt();
            System.out.print("Enter new price: ");
            double price = scanner.nextDouble();

            String sql = "UPDATE Service SET service_name = ?, description = ?, duration = ?, price = ? WHERE service_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, serviceName);
            statement.setString(2, description);
            statement.setInt(3, duration);
            statement.setDouble(4, price);
            statement.setInt(5, serviceId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Service information updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteService() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter service ID to delete: ");
            int serviceId = scanner.nextInt();

            String sql = "DELETE FROM Service WHERE service_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, serviceId);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Service deleted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}



