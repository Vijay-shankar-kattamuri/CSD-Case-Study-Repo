package com.aman.carservice;
// Program for Appointment Management
import java.sql.*;
import java.util.Scanner;

public class AppointmentManagement {

    public static void manageAppointments() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Appointment Management");
            System.out.println("------------------------");
            System.out.println("1. Schedule New Appointment");
            System.out.println("2. View Appointment Details");
            System.out.println("3. Update Appointment Information");
            System.out.println("4. Cancel Appointment");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {  // case statements to select between options
                case 1:
                    scheduleNewAppointment();
                    break;
                case 2:
                    viewAppointmentDetails();
                    break;
                case 3:
                    updateAppointmentInformation();
                    break;
                case 4:
                    cancelAppointment();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void scheduleNewAppointment() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();

            System.out.print("\\nEnter service ID: ");
            int serviceId = scanner.nextInt();

            scanner.nextLine(); // Consume newline

            System.out.print("\\nEnter appointment date (YYYY-MM-DD): ");
            String dateStr = scanner.nextLine();

            System.out.print("\\nEnter appointment time (HH:mm:ss): ");
            String timeStr = scanner.nextLine();

            String sql =
                    "INSERT INTO Appointment (customer_id, service_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)";
            PreparedStatement statement =
                    connection.prepareStatement(sql);
            statement.setInt(1, customerId);
            statement.setInt(2, serviceId);
            statement.setDate(3, Date.valueOf(dateStr));
            statement.setTime(4, Time.valueOf(timeStr));

            int rowsInserted =
                    statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("\\nAppointment scheduled successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAppointmentDetails() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("\\nEnter appointment ID: ");
            int appointmentId = scanner.nextInt();

            String sql = "SELECT * FROM Appointment WHERE appointment_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, appointmentId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {

                System.out.println("\\nAppointment ID: " + resultSet.getInt("appointment_id"));
                System.out.println("\\nCustomer ID: " + resultSet.getInt("customer_id"));
                System.out.println("\\nService ID: " + resultSet.getInt("service_id"));
                System.out.println("\\nDate: " + resultSet.getDate("appointment_date"));
                System.out.println("\\nTime: " + resultSet.getTime("appointment_time"));
            } else {
                System.out.println("\\nAppointment not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateAppointmentInformation() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("\\nEnter appointment ID to update: ");
            int appointmentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("\\nEnter new date (YYYY-MM-DD): ");

            String dateStr = scanner.nextLine();

            System.out.print("\\nEnter new time (HH:mm:ss): ");

            String timeStr = scanner.nextLine();

            String sql = "UPDATE Appointment SET appointment_date = ?, appointment_time = ? WHERE appointment_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setDate(1, Date.valueOf(dateStr));
            statement.setTime(2, Time.valueOf(timeStr));
            statement.setInt(3, appointmentId);

            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("\\nAppointment information updated successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    private static void cancelAppointment() {

        try (Connection connection = DatabaseConnection.getConnection()) {

            Scanner scanner = new Scanner(System.in);
            System.out.print("\\nEnter appointment ID to cancel: ");

            int appointmentId = scanner.nextInt();

            String sql = "DELETE FROM Appointment WHERE appointment_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, appointmentId);
            int rowsDeleted = statement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("\\nAppointment cancelled successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
