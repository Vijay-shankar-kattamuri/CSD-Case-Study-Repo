-- Create the database
CREATE DATABASE car_service_center;

-- Use the newly created database
USE car_service_center;

-- Create the Customer table
CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone_number VARCHAR(20) NOT NULL
);

-- Create the Service table
CREATE TABLE Service (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    description TEXT,
    duration INT NOT NULL, -- duration in minutes
    price DECIMAL(10, 2) NOT NULL
);

-- Create the Appointment table
CREATE TABLE Appointment (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    service_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (service_id) REFERENCES Service(service_id)
);

-- Insert some initial data into the Service table for testing
INSERT INTO Service (service_name, description, duration, price) VALUES
('Oil', 'Standard oil change service', 30, 500),
('Tire', 'Rotate tires for even wear', 45, 1000),
('Brake', 'Inspect brake pads and rotors', 60, 700);

-- Insert some initial data into the Customer table for testing
INSERT INTO Customer (customer_name, email, phone_number) VALUES
('Aman Kumar', 'aman.kumar@example.com', '123-456-7890'),
('Rohan Kumar', 'rohan.kumar@example.com', '098-765-4321');