/**
 * 
 */
/**
 * 
 */
module Gym_Management_System {
	requires java.sql;
}