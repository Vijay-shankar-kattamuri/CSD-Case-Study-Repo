package crm_project;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        // Create tables if they do not exist
        DatabaseSetup.createTables();

        Scanner scanner = new Scanner(System.in);
        CustomerManager customerManager = new CustomerManager();
        RewardManager rewardManager = new RewardManager();
        PurchaseManager purchaseManager = new PurchaseManager();

        while (true) {
            System.out.println("Customer Loyalty Program");
            System.out.println("1. Customer Management");
            System.out.println("2. Reward Management");
            System.out.println("3. Purchase Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    customerMenu(scanner, customerManager);
                    break;
                case 2:
                    rewardMenu(scanner, rewardManager);
                    break;
                case 3:
                    purchaseMenu(scanner, purchaseManager);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void customerMenu(Scanner scanner, CustomerManager customerManager) {
        System.out.println("Customer Management");
        System.out.println("1. Add Customer");
        System.out.println("2. View Customer");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                customerManager.addCustomer();
                break;
            case 2:
                customerManager.viewCustomer();
                break;
            case 3:
                customerManager.updateCustomer();
                break;
            case 4:
                customerManager.deleteCustomer();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void rewardMenu(Scanner scanner, RewardManager rewardManager) {
        System.out.println("Reward Management");
        System.out.println("1. Add Reward");
        System.out.println("2. View Reward");
        System.out.println("3. Update Reward");
        System.out.println("4. Delete Reward");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                rewardManager.addReward();
                break;
            case 2:
                rewardManager.viewReward();
                break;
            case 3:
                rewardManager.updateReward();
                break;
            case 4:
                rewardManager.deleteReward();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void purchaseMenu(Scanner scanner, PurchaseManager purchaseManager) {
        System.out.println("Purchase Management");
        System.out.println("1. Add Purchase");
        System.out.println("2. View Purchase");
        System.out.println("3. Update Purchase");
        System.out.println("4. Delete Purchase");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                purchaseManager.addPurchase();
                break;
            case 2:
                purchaseManager.viewPurchase();
                break;
            case 3:
                purchaseManager.updatePurchase();
                break;
            case 4:
                purchaseManager.deletePurchase();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}

