package crm_project;

import java.sql.*;
import java.util.Scanner;

public class RewardManager {

    public void addReward() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter reward name: ");
        String name = scanner.nextLine();
        System.out.println("Enter points required: ");
        int pointsRequired = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter reward description: ");
        String description = scanner.nextLine();

        String query = "INSERT INTO reward (customer_name, points_required, description) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, name);
            pstmt.setInt(2, pointsRequired);
            pstmt.setString(3, description);
            pstmt.executeUpdate();
            System.out.println("Reward added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewReward() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter reward ID: ");
        int rewardId = scanner.nextInt();

        String query = "SELECT * FROM reward WHERE reward_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, rewardId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Reward ID: " + rs.getInt("reward_id"));
                System.out.println("Name: " + rs.getString("customer_name"));
                System.out.println("Points Required: " + rs.getInt("points_required"));
                System.out.println("Description: " + rs.getString("description"));
            } else {
                System.out.println("Reward not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateReward() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter reward ID: ");
        int rewardId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter new reward name: ");
        String name = scanner.nextLine();
        System.out.println("Enter new points required: ");
        int pointsRequired = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter new reward description: ");
        String description = scanner.nextLine();

        String query = "UPDATE reward SET customer_name = ?, points_required = ?, description = ? WHERE reward_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, name);
            pstmt.setInt(2, pointsRequired);
            pstmt.setString(3, description);
            pstmt.setInt(4, rewardId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Reward updated successfully.");
            } else {
                System.out.println("Reward not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteReward() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter reward ID: ");
        int rewardId = scanner.nextInt();

        String query = "DELETE FROM reward WHERE reward_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, rewardId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Reward deleted successfully.");
            } else {
                System.out.println("Reward not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

