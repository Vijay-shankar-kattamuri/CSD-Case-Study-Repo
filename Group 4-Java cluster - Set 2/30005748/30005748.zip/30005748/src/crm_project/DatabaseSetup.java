package crm_project;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

public class DatabaseSetup {
	public static void createTables() {
        String createCustomerTable = "CREATE TABLE IF NOT EXISTS customer (" +
                "customer_id INT PRIMARY KEY AUTO_INCREMENT," +
                "cust_name VARCHAR(200)," +
                "email VARCHAR(100)," +
                "phone VARCHAR(13)," +
                "total_points INT DEFAULT 0" +
                ");";

        String createRewardTable = "CREATE TABLE IF NOT EXISTS reward (" +
                "reward_id INT PRIMARY KEY AUTO_INCREMENT," +
                "customer_name VARCHAR(100)," +
                "points_required INT," +
                "description VARCHAR(100)" +
                ");";

        String createPurchaseTable = "CREATE TABLE IF NOT EXISTS purchase (" +
                "purchase_id INT PRIMARY KEY AUTO_INCREMENT," +
                "customer_id INT," +
                "reward_id INT," +
                "purchase_date DATE," +
                "points_earned INT," +
                "FOREIGN KEY (customer_id) REFERENCES customer(customer_id)," +
                "FOREIGN KEY (reward_id) REFERENCES reward(reward_id)" +
                ");";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute(createCustomerTable);
            stmt.execute(createRewardTable);
            stmt.execute(createPurchaseTable);
            System.out.println("Tables created successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
