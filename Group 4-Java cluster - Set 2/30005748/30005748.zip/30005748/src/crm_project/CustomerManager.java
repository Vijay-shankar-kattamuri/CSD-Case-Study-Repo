package crm_project;

import java.sql.*;
import java.util.Scanner;

public class CustomerManager {

    public void addCustomer() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.println("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.println("Enter customer phone: ");
        String phone = scanner.nextLine();

        String query = "INSERT INTO customer (cust_name, email, phone, total_points) VALUES (?, ?, ?, 0)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.executeUpdate();
            System.out.println("Customer added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewCustomer() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer ID: ");
        int customerId = scanner.nextInt();

        String query = "SELECT * FROM customer WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("cust_name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone: " + rs.getString("phone"));
                System.out.println("Total Points: " + rs.getInt("total_points"));
            } else {
                System.out.println("Customer not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCustomer() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter new customer name: ");
        String name = scanner.nextLine();
        System.out.println("Enter new customer email: ");
        String email = scanner.nextLine();
        System.out.println("Enter new customer phone: ");
        String phone = scanner.nextLine();

        String query = "UPDATE customer SET cust_name = ?, email = ?, phone = ? WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.setInt(4, customerId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Customer updated successfully.");
            } else {
                System.out.println("Customer not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCustomer() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer ID: ");
        int customerId = scanner.nextInt();

        String query = "DELETE FROM customer WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, customerId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Customer deleted successfully.");
            } else {
                System.out.println("Customer not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

