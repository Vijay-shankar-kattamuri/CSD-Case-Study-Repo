package crm_project;

import java.sql.*;
import java.util.Scanner;

public class PurchaseManager {

    public void addPurchase() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter customer ID: ");
        int customerId = scanner.nextInt();
        System.out.println("Enter reward ID: ");
        int rewardId = scanner.nextInt();
        System.out.println("Enter points earned: ");
        int pointsEarned = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter purchase date (YYYY-MM-DD): ");
        String purchaseDate = scanner.nextLine();

        String query = "INSERT INTO purchase (customer_id, reward_id, purchase_date, points_earned) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, customerId);
            pstmt.setInt(2, rewardId);
            pstmt.setDate(3, Date.valueOf(purchaseDate));
            pstmt.setInt(4, pointsEarned);
            pstmt.executeUpdate();

            updateCustomerPoints(customerId, pointsEarned);

            System.out.println("Purchase added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPurchase() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter purchase ID: ");
        int purchaseId = scanner.nextInt();

        String query = "SELECT * FROM purchase WHERE purchase_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, purchaseId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Purchase ID: " + rs.getInt("purchase_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Reward ID: " + rs.getInt("reward_id"));
                System.out.println("Purchase Date: " + rs.getDate("purchase_date"));
                System.out.println("Points Earned: " + rs.getInt("points_earned"));
            } else {
                System.out.println("Purchase not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePurchase() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter purchase ID: ");
        int purchaseId = scanner.nextInt();
        System.out.println("Enter new customer ID: ");
        int customerId = scanner.nextInt();
        System.out.println("Enter new reward ID: ");
        int rewardId = scanner.nextInt();
        System.out.println("Enter new points earned: ");
        int pointsEarned = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter new purchase date (YYYY-MM-DD): ");
        String purchaseDate = scanner.nextLine();

        String query = "UPDATE purchase SET customer_id = ?, reward_id = ?, purchase_date = ?, points_earned = ? WHERE purchase_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, customerId);
            pstmt.setInt(2, rewardId);
            pstmt.setDate(3, Date.valueOf(purchaseDate));
            pstmt.setInt(4, pointsEarned);
            pstmt.setInt(5, purchaseId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Purchase updated successfully.");
            } else {
                System.out.println("Purchase not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePurchase() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter purchase ID: ");
        int purchaseId = scanner.nextInt();

        String query = "DELETE FROM purchase WHERE purchase_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, purchaseId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Purchase deleted successfully.");
            } else {
                System.out.println("Purchase not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateCustomerPoints(int customerId, int pointsEarned) {
        String query = "UPDATE customer SET total_points = total_points + ? WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, pointsEarned);
            pstmt.setInt(2, customerId);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

