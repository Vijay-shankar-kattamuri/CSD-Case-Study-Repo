import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Digital Magazine Management System");
            System.out.println("1. Magazine Management");
            System.out.println("2. Article Management");
            System.out.println("3. Subscription Management");
            System.out.println("4. User Management");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageMagazines(scanner);
                    break;
                case 2:
                    manageArticles(scanner);
                    break;
                case 3:
                    manageSubscriptions(scanner);
                    break;
                case 4:
                    manageUsers(scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    private static void manageMagazines(Scanner scanner) {
        int choice;
        do {
            System.out.println("Magazine Management");
            System.out.println("1. Add a new magazine");
            System.out.println("2. View magazine details");
            System.out.println("3. Update magazine information");
            System.out.println("4. Delete a magazine");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Magazine.addMagazine(scanner);
                    break;
                case 2:
                    Magazine.viewMagazine(scanner);
                    break;
                case 3:
                    Magazine.updateMagazine(scanner);
                    break;
                case 4:
                    Magazine.deleteMagazine(scanner);
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void manageArticles(Scanner scanner) {
        int choice;
        do {
            System.out.println("Article Management");
            System.out.println("1. Add a new article");
            System.out.println("2. View article details");
            System.out.println("3. Update article information");
            System.out.println("4. Delete an article");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Article.addArticle(scanner);
                    break;
                case 2:
                    Article.viewArticle(scanner);
                    break;
                case 3:
                    Article.updateArticle(scanner);
                    break;
                case 4:
                    Article.deleteArticle(scanner);
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void manageSubscriptions(Scanner scanner) {
        int choice;
        do {
            System.out.println("Subscription Management");
            System.out.println("1. Add a new subscription");
            System.out.println("2. View subscription details");
            System.out.println("3. Update subscription information");
            System.out.println("4. Delete a subscription");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Subscription.addSubscription(scanner);
                    break;
                case 2:
                    Subscription.viewSubscription(scanner);
                    break;
                case 3:
                    Subscription.updateSubscription(scanner);
                    break;
                case 4:
                    Subscription.deleteSubscription(scanner);
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void manageUsers(Scanner scanner) {
        int choice;
        do {
            System.out.println("User Management");
            System.out.println("1. Add a new user");
            System.out.println("2. View user details");
            System.out.println("3. Update user information");
            System.out.println("4. Delete a user");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    User.addUser(scanner);
                    break;
                case 2:
                    User.viewUser(scanner);
                    break;
                case 3:
                    User.updateUser(scanner);
                    break;
                case 4:
                    User.deleteUser(scanner);
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }
}
