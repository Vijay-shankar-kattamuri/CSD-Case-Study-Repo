import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Subscription {
    public static void addSubscription(Scanner scanner) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter magazine ID: ");
        int magazineId = scanner.nextInt();
        System.out.print("Enter subscription date (YYYY-MM-DD): ");
        String subscriptionDate = scanner.next();
        System.out.print("Enter expiry date (YYYY-MM-DD): ");
        String expiryDate = scanner.next();
        System.out.print("Enter status: ");
        String status = scanner.next();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Subscription (user_id, magazine_id, subscription_date, expiry_date, status) VALUES (?, ?, ?, ?, ?)")) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, magazineId);
            pstmt.setDate(3, Date.valueOf(subscriptionDate));
            pstmt.setDate(4, Date.valueOf(expiryDate));
            pstmt.setString(5, status);
            pstmt.executeUpdate();
            System.out.println("Subscription added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewSubscription(Scanner scanner) {
        System.out.print("Enter subscription ID: ");
        int id = scanner.nextInt();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Subscription WHERE subscription_id = ?")) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("User ID: " + rs.getInt("user_id"));
                System.out.println("Magazine ID: " + rs.getInt("magazine_id"));
                System.out.println("Subscription Date: " + rs.getDate("subscription_date"));
                System.out.println("Expiry Date: " + rs.getDate("expiry_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateSubscription(Scanner scanner) {
        System.out.print("Enter subscription ID: ");
        int id = scanner.nextInt();
        System.out.print("Enter new user ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter new magazine ID: ");
        int magazineId = scanner.nextInt();
        System.out.print("Enter new subscription date (YYYY-MM-DD): ");
        String subscriptionDate = scanner.next();
        System.out.print("Enter new expiry date (YYYY-MM-DD): ");
        String expiryDate = scanner.next();
        System.out.print("Enter new status: ");
        String status = scanner.next();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Subscription SET user_id = ?, magazine_id = ?, subscription_date = ?, expiry_date = ?, status = ? WHERE subscription_id = ?")) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, magazineId);
            pstmt.setDate(3, Date.valueOf(subscriptionDate));
            pstmt.setDate(4, Date.valueOf(expiryDate));
            pstmt.setString(5, status);
            pstmt.setInt(6, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Subscription updated successfully.");
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteSubscription(Scanner scanner) {
        System.out.print("Enter subscription ID: ");
        int id = scanner.nextInt();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Subscription WHERE subscription_id = ?")) {
            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Subscription deleted successfully.");
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
