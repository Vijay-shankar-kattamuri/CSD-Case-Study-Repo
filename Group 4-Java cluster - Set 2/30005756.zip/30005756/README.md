# Digital Magazine Management System

## Table of Contents
- [Introduction](#introduction)
- [Features](#features)
- [Technologies Used](#technologies-used)
- [Setup Instructions](#setup-instructions)
- [Usage Instructions](#usage-instructions)
- [Database Schema](#database-schema)

## Introduction
The Digital Magazine Management System is a Java console application designed to manage digital magazines, articles, and subscriptions. It uses MySQL as the database and JDBC for database interactions.

## Features
- **Magazine Management**: Add, view, update, and delete magazines.
- **Article Management**: Add, view, update, and delete articles.
- **Subscription Management**: Subscribe, view, update, and cancel subscriptions.

## Technologies Used
- **Java**: Core Java for application development.
- **MySQL**: Database to store magazine, article, and subscription data.
- **JDBC**: Java Database Connectivity for database interactions.

## Setup Instructions

### Prerequisites
- **Java Development Kit (JDK)**: Ensure you have JDK installed.
- **MySQL**: Ensure you have MySQL installed and running.

### Database Setup
1. Create a MySQL database named `DigitalMagazineDB`.
2. Run the following SQL script to create the necessary tables:

    ```sql
    -- Create the database
    CREATE DATABASE DigitalMagazineDB;

    -- Use the database
    USE DigitalMagazineDB;

    -- Create Magazine Table
    CREATE TABLE Magazine (
        magazine_id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        genre VARCHAR(100),
        publication_frequency VARCHAR(50),
        publisher VARCHAR(255)
    );

    -- Create Article Table
    CREATE TABLE Article (
        article_id INT AUTO_INCREMENT PRIMARY KEY,
        magazine_id INT,
        title VARCHAR(255) NOT NULL,
        author VARCHAR(255),
        content TEXT,
        publish_date DATE,
        FOREIGN KEY (magazine_id) REFERENCES Magazine(magazine_id)
    );

    -- Create User Table
    CREATE TABLE User (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        date_of_birth DATE,
        registration_date DATE
    );

    -- Create Subscription Table
    CREATE TABLE Subscription (
        subscription_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        magazine_id INT,
        subscription_date DATE,
        expiry_date DATE,
        status VARCHAR(50),
        FOREIGN KEY (user_id) REFERENCES User(user_id),
        FOREIGN KEY (magazine_id) REFERENCES Magazine(magazine_id)
    );
    ```

### Java Application Setup
1. Clone the repository:
    ```sh
    git clone https://github.com/Sudhirdp/CSD-Case-Study-Repo.git
    ```
2. Open the project in your preferred IDE.
3. Update the database connection details in the `DigitalMagazineManagementSystem` class:
    ```java
    private static final String DB_URL = "jdbc:mysql://localhost:3306/DigitalMagazineDB";
    private static final String USER = "root";
    private static final String PASS = "password";
    ```
4. Run the `DigitalMagazineManagementSystem` class.

## Usage Instructions

### Main Menu
- Choose an option from the main menu to manage magazines, articles, or subscriptions.

### Magazine Management
- **Add a new magazine**: Enter the title, genre, publication frequency, and publisher.
- **View magazine details**: Enter the magazine ID to view details.
- **Update magazine information**: Enter the magazine ID and new details to update.
- **Delete a magazine**: Enter the magazine ID to delete.

### Article Management
- **Add a new article**: Enter the magazine ID, title, author, content, and publish date.
- **View article details**: Enter the article ID to view details.
- **Update article information**: Enter the article ID and new details to update.
- **Delete an article**: Enter the article ID to delete.

### Subscription Management
- **Subscribe to a magazine**: Enter the user ID, magazine ID, subscription date, expiry date, and status.
- **View subscription details**: Enter the subscription ID to view details.
- **Update subscription information**: Enter the subscription ID and new details to update.
- **Cancel a subscription**: Enter the subscription ID to cancel.

## Database Schema
The database schema consists of the following tables:
- **Magazine**: Stores magazine details.
- **Article**: Stores article details.
- **User**: Stores user details.
- **Subscription**: Stores subscription details.