package DB;
import java.sql.Connection;
import java.sql.DriverManager;
public class JdbcConnector {
    private static final String db_url="jdbc:mysql://localhost:3306/HospitalDB";
    private static final String username="root";
    private static final String password="Gautam@055";

    public static Connection getConnection() throws Exception {
        Connection conn = DriverManager.getConnection(db_url,username,password);
        return conn;
    }
}
