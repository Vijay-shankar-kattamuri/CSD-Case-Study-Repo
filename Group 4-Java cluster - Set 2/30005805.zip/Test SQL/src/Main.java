import DAO.DoctorManager;
import DAO.MedicalRecordManager;
import DAO.PatientManager;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception{
        Scanner scanner = new Scanner(System.in);
        PatientManager patientManager = new PatientManager();
        DoctorManager doctorManager = new DoctorManager();
        MedicalRecordManager recordManager = new MedicalRecordManager();
        while (true) {
            System.out.println("Hospital Management System");
            System.out.println("1. Manage Patients");
            System.out.println("2. Manage Doctors");
            System.out.println("3. Manage Medical Records");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        patientManager.managePatients();
                        break;
                    case 2:
                        doctorManager.manageDoctors();
                        break;
                    case 3:
                        recordManager.manageRecords();
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
