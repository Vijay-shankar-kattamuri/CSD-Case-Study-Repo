package DAO;

import DB.JdbcConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DoctorManager {
    private Connection conn;

    public DoctorManager() throws Exception{
        this.conn=JdbcConnector.getConnection();
    }

    public void manageDoctors() throws Exception {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Doctor Management");
        System.out.println("1. Add a new doctor");
        System.out.println("2. View doctor details");
        System.out.println("3. Update doctor information");
        System.out.println("4. Delete a doctor");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                addDoctor();
                break;
            case 2:
                viewDoctorDetails();
                break;
            case 3:
                updateDoctorInfo();
                break;
            case 4:
                deleteDoctor();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private void addDoctor() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter specialization: ");
        String specialization = scanner.nextLine();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        String sql = "INSERT INTO Doctor (name, specialization, contact_number, email) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, specialization);
            pstmt.setString(3, contactNumber);
            pstmt.setString(4, email);
            pstmt.executeUpdate();
            System.out.println("Doctor added successfully.");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    private void viewDoctorDetails() throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();

        String sql = "SELECT * FROM Doctor WHERE doctor_id = ?";
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, doctorId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Doctor ID: " + rs.getInt("doctor_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Specialization: " + rs.getString("specialization"));
                System.out.println("Contact Number: " + rs.getString("contact_number"));
                System.out.println("Email: " + rs.getString("email"));
            } else {
                System.out.println("Doctor not found.");
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    private void updateDoctorInfo() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new specialization: ");
        String specialization = scanner.nextLine();
        System.out.print("Enter new contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();

        String sql = "UPDATE Doctor SET name = ?, specialization = ?, contact_number = ?, email = ? WHERE doctor_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, specialization);
            pstmt.setString(3, contactNumber);
            pstmt.setString(4, email);
            pstmt.setInt(5, doctorId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Doctor information updated successfully.");
            } else {
                System.out.println("Doctor not found.");
            }
        }
    }

    private void deleteDoctor() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();

        String sql = "DELETE FROM Doctor WHERE doctor_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, doctorId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Doctor deleted successfully.");
            } else {
                System.out.println("Doctor not found.");
            }
        }
    }
}

