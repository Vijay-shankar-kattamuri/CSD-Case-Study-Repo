package DAO;

import DB.JdbcConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class PatientManager {
    private Connection conn;

    public PatientManager() throws Exception{
        this.conn=JdbcConnector.getConnection();
    }

    public void managePatients() throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Patient Management");
        System.out.println("1. Register a new patient");
        System.out.println("2. View patient details");
        System.out.println("3. Update patient information");
        System.out.println("4. Delete a patient");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                registerPatient();
                break;
            case 2:
                viewPatientDetails();
                break;
            case 3:
                updatePatientInfo();
                break;
            case 4:
                deletePatient();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private void registerPatient() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter date of birth (YYYY-MM-DD): ");
        String dob = scanner.nextLine();
        System.out.print("Enter gender: ");
        String gender = scanner.nextLine();
        System.out.print("Enter address: ");
        String address = scanner.nextLine();

        String sql = "INSERT INTO Patient (name, date_of_birth, gender, address) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, dob);
            pstmt.setString(3, gender);
            pstmt.setString(4, address);
            pstmt.executeUpdate();
            System.out.println("Patient registered successfully.");
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    private void viewPatientDetails() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();

        String sql = "SELECT * FROM Patient WHERE patient_id = ?";
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, patientId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Patient ID: " + rs.getInt("patient_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Date of Birth: " + rs.getDate("date_of_birth"));
                System.out.println("Gender: " + rs.getString("gender"));
                System.out.println("Address: " + rs.getString("address"));
            } else {
                System.out.println("Patient not found.");
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    private void updatePatientInfo() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new date of birth (YYYY-MM-DD): ");
        String dob = scanner.nextLine();
        System.out.print("Enter new gender: ");
        String gender = scanner.nextLine();
        System.out.print("Enter new address: ");
        String address = scanner.nextLine();

        String sql = "UPDATE Patient SET name = ?, date_of_birth = ?, gender = ?, address = ? WHERE patient_id = ?";
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, dob);
            pstmt.setString(3, gender);
            pstmt.setString(4, address);
            pstmt.setInt(5, patientId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Patient information updated successfully.");
            } else {
                System.out.println("Patient not found.");
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    private void deletePatient() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();

        String sql = "DELETE FROM Patient WHERE patient_id = ?";
        try {PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, patientId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Patient deleted successfully.");
            } else {
                System.out.println("Patient not found.");
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
