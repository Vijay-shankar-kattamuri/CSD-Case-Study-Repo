package DAO;

import DB.JdbcConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class MedicalRecordManager {
    private Connection conn;

    public MedicalRecordManager() throws Exception{
        this.conn=JdbcConnector.getConnection();
    }

    public void manageRecords() throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Medical Record Management");
        System.out.println("1. Create a new medical record for a patient");
        System.out.println("2. View medical record details");
        System.out.println("3. Update medical record information");
        System.out.println("4. Delete a medical record");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                createMedicalRecord();
                break;
            case 2:
                viewMedicalRecordDetails();
                break;
            case 3:
                updateMedicalRecordInfo();
                break;
            case 4:
                deleteMedicalRecord();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private void createMedicalRecord() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter diagnosis: ");
        String diagnosis = scanner.nextLine();
        System.out.print("Enter treatment: ");
        String treatment = scanner.nextLine();

        String sql = "INSERT INTO MedicalRecord (patient_id, doctor_id, date, diagnosis, treatment) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, patientId);
            pstmt.setInt(2, doctorId);
            pstmt.setString(3, date);
            pstmt.setString(4, diagnosis);
            pstmt.setString(5, treatment);
            pstmt.executeUpdate();
            System.out.println("Medical record created successfully.");
        }
    }

    private void viewMedicalRecordDetails() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter record ID: ");
        int recordId = scanner.nextInt();

        String sql = "SELECT * FROM MedicalRecord WHERE record_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, recordId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Record ID: " + rs.getInt("record_id"));
                System.out.println("Patient ID: " + rs.getInt("patient_id"));
                System.out.println("Doctor ID: " + rs.getInt("doctor_id"));
                System.out.println("Date: " + rs.getDate("date"));
                System.out.println("Diagnosis: " + rs.getString("diagnosis"));
                System.out.println("Treatment: " + rs.getString("treatment"));
            } else {
                System.out.println("Medical record not found.");
            }
        }
    }

    private void updateMedicalRecordInfo() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter record ID: ");
        int recordId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new patient ID: ");
        int patientId = scanner.nextInt();
        System.out.print("Enter new doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter new diagnosis: ");
        String diagnosis = scanner.nextLine();
        System.out.print("Enter new treatment: ");
        String treatment = scanner.nextLine();

        String sql = "UPDATE MedicalRecord SET patient_id = ?, doctor_id = ?, date = ?, diagnosis = ?, treatment = ? WHERE record_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, patientId);
            pstmt.setInt(2, doctorId);
            pstmt.setString(3, date);
            pstmt.setString(4, diagnosis);
            pstmt.setString(5, treatment);
            pstmt.setInt(6, recordId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Medical record updated successfully.");
            } else {
                System.out.println("Medical record not found.");
            }
        }
    }

    private void deleteMedicalRecord() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter record ID: ");
        int recordId = scanner.nextInt();

        String sql = "DELETE FROM MedicalRecord WHERE record_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, recordId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Medical record deleted successfully.");
            } else {
                System.out.println("Medical record not found.");
            }
        }
    }
}

