# Hospital Management System

## Overview

This project is a console-based Hospital Management System developed using Core Java, MySQL, and JDBC. The application allows users to manage patients, doctors, and medical records.

## Functionalities

1. **Patient Management:**
   - Register a new patient
   - View patient details
   - Update patient information
   - Delete a patient

2. **Doctor Management:**
   - Add a new doctor
   - View doctor details
   - Update doctor information
   - Delete a doctor

3. **Medical Record Management:**
   - Create a new medical record for a patient
   - View medical record details
   - Update medical record information
   - Delete a medical record

## Database Schema

### Patient Table
- `patient_id` (Primary Key)
- `name`
- `date_of_birth`
- `gender`
- `address`

### Doctor Table
- `doctor_id` (Primary Key)
- `name`
- `specialization`
- `contact_number`
- `email`

### Medical Record Table
- `record_id` (Primary Key)
- `patient_id` (Foreign Key references Patient Table)
- `doctor_id` (Foreign Key references Doctor Table)
- `date`
- `diagnosis`
- `treatment`

## Setup Instructions

1. **Install MySQL:**
   - Download and install MySQL from the [official website](https://dev.mysql.com/downloads/).

2. **Create Database and Tables:**
   - Use the provided SQL script to create the `HospitalDB` database and tables.

3. **Download MySQL Connector/J:**
   - Download the MySQL Connector/J from the [official website](https://dev.mysql.com/downloads/connector/j/).

4. **Set Up Java Project:**
   - Add the MySQL Connector/J JAR file to your project's build path.

5. **Run the Application:**
   - Compile and run the `Main` class to start the application.
   - Use the menu to manage patients, doctors, and medical records.

## Submission

- Upload the complete source code to a public GitHub repository.
- Provide the link to the GitHub repository.

## Example

The following is an example of how to register a new patient:

