package com.test.magazine;

import java.sql.*;
import java.util.Scanner;

public class Main {
	private static final String url = "jdbc:mysql://localhost:3306/DigitalMagazineDB";
	private static final String username = "root";
	private static final String password = "ritwick@096";

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}

		try (Scanner sc = new Scanner(System.in)) {
			while (true) // prompts the user to choose a management option or exit.
			{
				System.out.println("\nDigital Magazine Management System");
				System.out.println("1. Manage Magazines");
				System.out.println("2. Manage Articles");
				System.out.println("3. Manage Subscriptions");
				System.out.println("4. Exit");
				System.out.print("Enter your choice: ");
				int choice = sc.nextInt();

				switch (choice) {
				case 1: 
				while(true) {
					System.out.println("\nManage Magazines");
					System.out.println("1. Add Magazine");
					System.out.println("2. View Magazine");
					System.out.println("3. Update Magazine");
					System.out.println("4. Delete Magazine");
					System.out.println("5. Back to Main Menu");
					System.out.print("Enter your choice: ");
					int ch = sc.nextInt();

					switch (ch) {
					case 1:
						System.out.println("Enter Magazine Id: ");
						int mag_id = sc.nextInt();
						sc.nextLine();
						System.out.println("Enter Title: ");
						String title = sc.nextLine();
						sc.nextLine();
						System.out.println("Enter Genre: ");
						String genre = sc.nextLine();
						sc.nextLine();
						System.out.println("Enter Publisher Frequency: ");
						String pub_freq = sc.nextLine();
						sc.nextLine();
						System.out.println("Enter Publisher: ");
						String pub = sc.nextLine();
						try {
							PreparedStatement preparedStatement = connection
									.prepareStatement("INSERT INTO Magazine(magazine_id, title, genre, publication_frequency, publisher) VALUES(?, ?, ?, ?, ?)");
							preparedStatement.setLong(1, mag_id);
							preparedStatement.setString(2, title);
							preparedStatement.setString(3, genre);
							preparedStatement.setString(4, pub_freq);
							preparedStatement.setString(5, pub);
							
							int rowsAffected = preparedStatement.executeUpdate();
							if (rowsAffected > 0) {
								System.out.println("Magazine Added Successfully");
							} else {
								throw new RuntimeException("Magazine Addition failed!!");
							}
						} 
						catch (SQLException e) {
							e.printStackTrace();
						}
						break;
					case 2:
						System.out.println("Enter Magazine Id: ");
						mag_id = sc.nextInt();
						try {
							PreparedStatement preparedStatement = connection
									.prepareStatement("SELECT title FROM Magazine where magazine_id = ?");
							preparedStatement.setLong(1, mag_id);
							
							ResultSet resultSet = preparedStatement.executeQuery();
							if (resultSet.next()) {
								title = resultSet.getString("title");
								System.out.println("Title: " + title);
							} else {
								System.out.println("Invalid Id!");
							}
						} 
						catch (SQLException e) {
							e.printStackTrace();
						}
						break;
					case 3:
						//working on the update query currently
						break;
					case 4:
						System.out.println("Enter Magazine Id: ");
						mag_id = sc.nextInt();
						try {
							PreparedStatement preparedStatement = connection
									.prepareStatement("DELETE * FROM Magazine where magazine_id = ?");
							preparedStatement.setLong(1, mag_id);
						} 
						catch (SQLException e) {
							e.printStackTrace();
						}
						break;
					case 5:
						return;
					default:
						System.out.println("Invalid choice. Please try again.");
					}
					break;
				}
				
				case 2: 
				while(true) {
					System.out.println("\nManage Articles");
		            System.out.println("1. Add Article");
		            System.out.println("2. View Article");
		            System.out.println("3. Update Article");
		            System.out.println("4. Delete Article");
		            System.out.println("5. Back to Main Menu");
		            System.out.print("Enter your choice: ");
		            int ch = sc.nextInt();

		            switch (ch) {
					    //Executes different article management methods based on the user's choice.
		                case 1:
		                	System.out.println("Enter Article Id: ");
							int art_id = sc.nextInt();
							sc.nextLine();
							System.out.println("Enter Magazine Id: ");
							int mag_id = sc.nextInt();
							sc.nextLine();
							System.out.println("Enter Title: ");
							String title = sc.nextLine();
							sc.nextLine();
							System.out.println("Enter Author: ");
							String auth = sc.nextLine();
							sc.nextLine();
							System.out.println("Content: ");
							String con = sc.nextLine();
							System.out.println("Publish Date: ");
							String pub = sc.nextLine();
							try {
								PreparedStatement preparedStatement = connection
										.prepareStatement("INSERT INTO Article(article_id, magazine_id, title, author, content, publish_date) VALUES(?, ?, ?, ?, ?, ?)");
								preparedStatement.setLong(1, art_id);
								preparedStatement.setInt(2, mag_id);
								preparedStatement.setString(3, title);
								preparedStatement.setString(4, auth);
								preparedStatement.setString(5, con);
								preparedStatement.setString(6, pub);
								
								int rowsAffected = preparedStatement.executeUpdate();
								if (rowsAffected > 0) {
									System.out.println("Article Added Successfully");
								} else {
									throw new RuntimeException("Article Addition failed!!");
								}
							} 
							catch (SQLException e) {
								e.printStackTrace();
							}
		                    break;
		                case 2:
		                	System.out.println("Enter Article Id: ");
							art_id = sc.nextInt();
							try {
								PreparedStatement preparedStatement = connection
										.prepareStatement("SELECT title FROM Article where article_id = ?");
								preparedStatement.setLong(1, art_id);
								
								ResultSet resultSet = preparedStatement.executeQuery();
								if (resultSet.next()) {
									title = resultSet.getString("title");
									System.out.println("Title: " + title);
								} else {
									System.out.println("Invalid Id!");
								}
							} 
							catch (SQLException e) {
								e.printStackTrace();
							}
		                    break;
		                case 3:
		                	//working on update query
		                    break;
		                case 4:
		                	System.out.println("Enter Article Id: ");
							art_id = sc.nextInt();
							try {
								PreparedStatement preparedStatement = connection
										.prepareStatement("DELETE * FROM Article where article_id = ?");
								preparedStatement.setLong(1, art_id);
								
							} 
							catch (SQLException e) {
								e.printStackTrace();
							}
		                    break;
		                case 5:
		                    return;
		                default:
		                    System.out.println("Invalid choice. Please try again.");
		            }
				}
				case 3: 
				while(true) {
					System.out.println("\nManage Subscriptions");
		            System.out.println("1. Subscribe");
		            System.out.println("2. View Subscription");
		            System.out.println("3. Update Subscription");
		            System.out.println("4. Cancel Subscription");
		            System.out.println("5. Back to Main Menu");
		            System.out.print("Enter your choice: ");
		            int ch = sc.nextInt();

		            switch (ch) //Executes different magazine management methods based on the user's choice.
					{
		                case 1:
		                	System.out.println("Enter Subscription Id: ");
							int sub_id = sc.nextInt();
							sc.nextLine();
							System.out.println("Enter User Id: ");
							int user_id = sc.nextInt();
							sc.nextLine();
							System.out.println("Enter Magazine Id: ");
							int mag_id = sc.nextInt();
							sc.nextLine();
							System.out.println("Enter Subscription Date: ");
							String sub_date = sc.nextLine();
							sc.nextLine();
							System.out.println("Enter Expiry Date: ");
							String exp_date = sc.nextLine();
							System.out.println("Status: ");
							String stat = sc.nextLine();
							try {
								PreparedStatement preparedStatement = connection
										.prepareStatement("INSERT INTO Subscription(subscription_id, user_id, magazine_id, subscription_date, expiry_date, status) VALUES(?, ?, ?, ?, ?, ?)");
								preparedStatement.setLong(1, sub_id);
								preparedStatement.setInt(2, user_id);
								preparedStatement.setInt(3, mag_id);
								preparedStatement.setString(4, sub_date);
								preparedStatement.setString(5, exp_date);
								preparedStatement.setString(6, stat);
								
								int rowsAffected = preparedStatement.executeUpdate();
								if (rowsAffected > 0) {
									System.out.println("Subscribed Successfully");
								} else {
									throw new RuntimeException("Subscription failed!!");
								}
							} 
							catch (SQLException e) {
								e.printStackTrace();
							}
		                    break;
		                case 2:
		                	System.out.println("Enter Subscription Id: ");
							sub_id = sc.nextInt();
							try {
								PreparedStatement preparedStatement = connection
										.prepareStatement("SELECT * FROM Subscription where subscription_id = ?");
								preparedStatement.setLong(1, sub_id);
								
								ResultSet resultSet = preparedStatement.executeQuery();
								if (resultSet.next()) {
									 int sid= resultSet.getInt("subscription_id");
									 int uid= resultSet.getInt("user_id");
									 int mid= resultSet.getInt("magazine_id");
									 String sdat = resultSet.getString("subscription_date");
									 String edat = resultSet.getString("expiry_date");
									 String sta = resultSet.getString("status");
									System.out.println("Subscription ID: " + sid + ", User ID: " + uid + ", Magazine ID: " + mid + ", Subscription Date: " + sdat + ", Expiry Date: " + edat + ", Status: " + sta);
								} else {
									System.out.println("Invalid Id!");
								}
							} 
							catch (SQLException e) {
								e.printStackTrace();
							}
		                    break;
		                case 3:
		                	//working on update
		                    break;
		                case 4:
		                	System.out.println("Enter Subscription Id: ");
							sub_id = sc.nextInt();
							try {
								PreparedStatement preparedStatement = connection
										.prepareStatement("DELETE * FROM Subscription where subscription_id = ?");
								preparedStatement.setLong(1, sub_id);
								
							} 
							catch (SQLException e) {
								e.printStackTrace();
							}
		                    break;
		                case 5:
		                    return;
		                default:
		                    System.out.println("Invalid choice. Please try again.");
		            }
		            break;
				}
				
				

				}
			}
		}
	}

}
