package med;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Invent {
   
	public void update()throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter Inventory ID: ");
        String i_Id = sc.nextLine();
        System.out.print("Enter Medication ID: ");
        String med_id = sc.nextLine();
        System.out.print("Enter Supplier ID: ");
        String sid = sc.nextLine();
        System.out.print("Enter Quantity Received: ");
        int qty_recv = sc.nextInt();
        System.out.print("Enter Date Received (YYYY-MM-DD): ");
        String date_recv = sc.next();
        
        Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/inventory";
		String userName="root";
		String password="12345";
		   
		Connection con=DriverManager.getConnection(url,userName,password);
		System.out.println("connection established");
		String qry = "INSERT INTO invent (i_id, med_id, sid, qty_recv, date_recv) VALUES (?, ?, ?, ?, ?)";
		   // Execute the Required Query
		   //ResultSet rs = stm.executeQuery(qry);
		PreparedStatement pstmt = con.prepareStatement(qry);
        pstmt.setString(1,  i_Id);
        pstmt.setString(2, med_id);
        pstmt.setString(3, sid);
        pstmt.setInt(4, qty_recv);
        pstmt.setString(5, date_recv);

            // Execute the insert statement
        int rowsAffected = pstmt.executeUpdate();
        System.out.println(rowsAffected + " row(s) inserted.");
        
        String updateMedicationSQL = "UPDATE Medicine SET qty_in_stock = qty_in_stock + ? WHERE med_id = ?";
        PreparedStatement pstmtUpdate = con.prepareStatement(updateMedicationSQL);
        pstmtUpdate.setInt(1, qty_recv);
        pstmtUpdate.setString(2, med_id);
        pstmtUpdate.executeUpdate();
        System.out.print("Medicine stock updated successfully");
        con.close();
        }
	
	
	public void view()throws ClassNotFoundException, SQLException {
		   int numrows=0;
	       Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   Statement stm = con.createStatement();
		   String qry = "select * from invent";
		   // Execute the Required Query
		   ResultSet rs = stm.executeQuery(qry);
		   while(rs.next())
		   {
			   String i_id = rs.getString(1);  
		   String mid = rs.getString(2);
		   String sid = rs.getString(3);
		   //String desc = rs.getString(3);
		   int qty = rs.getInt(4);
		   String date_recv = rs.getString(5);
		   System.out.println(i_id+" "+mid+" "+sid+" "+qty+" "+date_recv);
		   numrows++;
		   }
		   if(numrows>0){
		   System.out.println(numrows+" rows fetched!");
		   }
		   else{
		   System.out.println("Data not found");
		   }
		   rs.close();
		   stm.close();
		   con.close();
	}
	
	
	public void generateLowStockAlerts()throws ClassNotFoundException, SQLException {
		 Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   int numrows=0;
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   Statement stm = con.createStatement();
		   String qry = "SELECT * FROM Medicine WHERE qty_in_stock < 10";
		   // Execute the Required Query
		   ResultSet rs = stm.executeQuery(qry);

	        while (rs.next()) {
	            String medicationId = rs.getString("med_id");
	            String name = rs.getString("name");
	            int quantityInStock = rs.getInt("qty_in_stock");
                System.out.println(medicationId +" "+ name+" "+quantityInStock);
                numrows++;
	             
	        }
	        if(numrows>0){
	        	 System.out.println(numrows+"rows fetched!");
	        }
	        else{
	        	 System.out.println("Data not found");
	        }
	        rs.close();
	        stm.close();
	        con.close();
		
	}
	
}
