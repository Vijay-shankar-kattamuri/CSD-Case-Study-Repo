package med;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.PreparedStatement;

public class Medication {

	public void add()  throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter medicine id: ");
		String mid=sc.nextLine();
		System.out.print("Enter medicine name: ");
		String mname=sc.nextLine();
		System.out.print("Enter medicine description: ");
		String desc=sc.nextLine();
		System.out.print("Enter medicine price: ");
		int price=sc.nextInt();
		System.out.print("Enter medicine quantity: ");
		int qty=sc.nextInt();
		

		Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   
		   
		   Statement stm = con.createStatement();
		   String qry = "INSERT INTO medicine (med_id, name, description, price, qty_in_stock) VALUES (?, ?, ?, ?, ?)";
		   // Execute the Required Query
		   //ResultSet rs = stm.executeQuery(qry);
		   PreparedStatement pstmt = con.prepareStatement(qry);
           pstmt.setString(1, mid);
           pstmt.setString(2, mname);
           pstmt.setString(3, desc);
           pstmt.setInt(4, price);
           pstmt.setInt(5, qty);

               // Execute the insert statement
           int rowsAffected = pstmt.executeUpdate();
           System.out.println(rowsAffected + " row(s) inserted.");
		   
		   
		   stm.close();
		   con.close();
	}
	
	public void view()throws ClassNotFoundException, SQLException {
		   int numrows=0;
	       Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   Statement stm = con.createStatement();
		   String qry = "select * from medicine";
		   // Execute the Required Query
		   ResultSet rs = stm.executeQuery(qry);
		   while(rs.next())
		   {
		   String mid = rs.getString(1);
		   String nam = rs.getString(2);
		   String desc = rs.getString(3);
		   int price = rs.getInt(4);
		   int qty = rs.getInt(5);
		   System.out.println(mid+" "+nam+" "+desc+" "+price+" "+qty);
		   numrows++;
		   }
		   if(numrows>0){
		   System.out.println(numrows+" rows fetched!");
		   }
		   else{
		   System.out.println("Data not found");
		   }
		   rs.close();
		   stm.close();
		   con.close();
	}
	
	public void update()throws ClassNotFoundException, SQLException {
			   
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter medicine id: ");
		String med_id=sc.nextLine();
		System.out.print("Enter medicine price: ");
		int price=sc.nextInt();
		//sc.nextLine();
	       Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   String qry = "UPDATE medicine SET price = ? WHERE med_id = ?";
		   // Execute the Required Query
		   PreparedStatement pstmt = con.prepareStatement(qry);
           pstmt.setInt(1, price);
           pstmt.setString(2, med_id);
           pstmt.execute();
           System.out.println("Information updated. ");
           //pstmt.close();
   		   con.close();
           }
	
	public void del()throws ClassNotFoundException, SQLException {
		   
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter medicine id: ");
		String med_id=sc.nextLine();
		//sc.nextLine();
	       Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   String qry = "delete from medicine where med_id=?";
		   // Execute the Required Query
		   PreparedStatement pstmt = con.prepareStatement(qry);
           pstmt.setString(1, med_id);
           pstmt.execute();
           System.out.println("Medicine deleted. ");
           //pstmt.close();
   		   con.close();
           }
	
}


