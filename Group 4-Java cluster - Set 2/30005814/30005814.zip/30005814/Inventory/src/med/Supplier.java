package med;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Supplier {
	public void add()  throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter supplier id: ");
		String sid=sc.nextLine();
		System.out.print("Enter supplier name: ");
		String sname=sc.nextLine();
		System.out.print("Enter email: ");
		String email=sc.nextLine();
		
		System.out.print("Enter address: ");
		String add=sc.nextLine();
		System.out.print("Enter phone no: ");
		int phone=sc.nextInt();
		//sc.nextLine();

		Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   
		   
		   Statement stm = con.createStatement();
		   String qry = "INSERT INTO supplier (sid, sname, email, address,phone) VALUES (?, ?, ?, ?, ?)";
		   // Execute the Required Query
		   //ResultSet rs = stm.executeQuery(qry);
		   PreparedStatement pstmt = con.prepareStatement(qry);
           pstmt.setString(1, sid);
           pstmt.setString(2, sname);
           pstmt.setString(3, email);
          
           pstmt.setString(4, add);
           pstmt.setInt(5, phone);

               // Execute the insert statement
           int rowsAffected = pstmt.executeUpdate();
           System.out.println(rowsAffected + " row(s) inserted.");
		   
		   
		   stm.close();
		   con.close();
	}
	
	public void view()throws ClassNotFoundException, SQLException {
		   int numrows=0;
	       Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   Statement stm = con.createStatement();
		   String qry = "select * from supplier";
		   // Execute the Required Query
		   ResultSet rs = stm.executeQuery(qry);
		   while(rs.next())
		   {
		   String sid = rs.getString(1);
		   String nam = rs.getString(2);
		   String email = rs.getString(3);
		  
		   String add = rs.getString(4);
		   int ph = rs.getInt(5);
		   System.out.println(sid+" "+nam+" "+email+" "+add+" "+ph);
		   numrows++;
		   }
		   if(numrows>0){
		   System.out.println(numrows+" rows fetched!");
		   }
		   else{
		   System.out.println("Data not found");
		   }
		   rs.close();
		   stm.close();
		   con.close();
	}
	
	public void update()throws ClassNotFoundException, SQLException {
			   
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter supplier id: ");
		String sid=sc.nextLine();
		System.out.print("Enter email: ");
		String email=sc.nextLine();
		//sc.nextLine();
	       Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   String qry = "UPDATE supplier SET email = ? WHERE sid = ?";
		   // Execute the Required Query
		   PreparedStatement pstmt = con.prepareStatement(qry);
           pstmt.setString(1, email);
           pstmt.setString(2, sid);
           pstmt.execute();
           System.out.println("Information updated. ");
           //pstmt.close();
   		   con.close();
           }
	
	public void del()throws ClassNotFoundException, SQLException {
		   
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter supplier id: ");
		String sid=sc.nextLine();
		//sc.nextLine();
	       Class.forName("com.mysql.cj.jdbc.Driver");
		   String url="jdbc:mysql://localhost:3306/inventory";
		   String userName="root";
		   String password="12345";
		   
		   Connection con=DriverManager.getConnection(url,userName,password);
		   System.out.println("connection established");
		   String qry = "delete from supplier where sid=?";
		   // Execute the Required Query
		   PreparedStatement pstmt = con.prepareStatement(qry);
           pstmt.setString(1, sid);
           pstmt.execute();
           System.out.println("Supplier deleted. ");
           //pstmt.close();
   		   con.close();
           }
	

}
