package med;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args)  throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Inventory Management System");
		int c,ans;
		do{
			System.out.println("Menu");
			System.out.println("1.Medication Management");
			System.out.println("2.Supplier Management");
			System.out.println("3.Inventory Management");
			System.out.print("Enter your choice: ");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:
				do {
					Medication m1=new Medication();
					System.out.println("Menu");
					System.out.println("1.Add new medication");
					System.out.println("2.View medication details");
					System.out.println("3.Update medication information");
					System.out.println("4.Delete medication");
					System.out.print("Enter your choice: ");
					int choice=sc.nextInt();
					if(choice==1) {
						m1.add();
					}
					if(choice==2) {
						m1.view();
					}
					if(choice==3) {
						m1.update();
					}
					if(choice==4) {
						m1.del();
					}
					System.out.print("Do you wish to continue?(1/0):  ");
					ans=sc.nextInt();
				}while(ans==1);
				break;
			case 2:
				do{
				Supplier s1=new Supplier();	
			    System.out.println("Menu");
				System.out.println("1.Add new Supplier");
				System.out.println("2.View supplier details");
				System.out.println("3.Update supplier information");
				System.out.println("4.Delete a supplier");
				System.out.print("Enter your choice: ");
				int choice=sc.nextInt();
				if(choice==1) {
					s1.add();
					}
				if(choice==2) {
					s1.view();
				}
				if(choice==3) {
					s1.update();
				}
				if(choice==4) {
					s1.del();
				}
				System.out.print("Do you wish to continue?(1/0):  ");
				ans=sc.nextInt();
			}while(ans==1);
			break;
			
			case 3:
				do{
					Invent i1=new Invent();
					System.out.println("Menu");
				System.out.println("1.Update inventory levels");
				System.out.println("2.View inventory levels");
				System.out.println("3.Generate low stock alerts");
				System.out.print("Enter your choice: ");
				int choice=sc.nextInt();
				if(choice==1) {
					//System.out.println("3aMenu");
					i1.update();
				}
				if(choice==2) {
					//System.out.println("3bMenu");
					i1.view();
				}
				if(choice==3) {
					//System.out.println("3cMenu");
					i1.generateLowStockAlerts();
				}
				System.out.print("Do you wish to continue?(1/0):  ");
				ans=sc.nextInt();
			}while(ans==1);
			break;
			
		}
		System.out.print("Do you wish to continue?(1/0):  ");
		c=sc.nextInt();
		}while(c==1);

	}

}
