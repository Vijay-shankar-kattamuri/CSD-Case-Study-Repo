/**
 * 
 */
/**
 * 
 */
module Inventory {
	requires java.sql;
}