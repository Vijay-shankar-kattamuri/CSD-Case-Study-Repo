package com.cognizant.lifeinsurancesystem;

import java.sql.*;
import java.util.Scanner;

public class ClaimManagement {
	public static void submitClaim() {
		DatabaseConnection db = new DatabaseConnection();
		try (Connection connection = db.getConnection()) {
			Scanner sc = new Scanner(System.in);

			System.out.print("Enter policy ID: ");
			int policyId = sc.nextInt();

			System.out.print("Enter policyholder ID: ");
			int policyholderId = sc.nextInt();
			sc.nextLine(); // consume newline

			System.out.print("Enter claim date (YYYY-MM-DD): ");
			String claimDate = sc.nextLine();

			System.out.print("Enter claim status: ");
			String status = sc.nextLine();

			String query = "INSERT INTO Claim (policy_id, policyholder_id, claim_date, status) VALUES (?, ?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(query)) {
				statement.setInt(1, policyId);
				
				statement.setInt(2, policyholderId);
				statement.setString(3, claimDate);
				statement.setString(4, status);
				statement.executeUpdate();
				System.out.println("Claim added successfully.");
			}
			 catch (Exception e) {
					e.printStackTrace();
					System.out.println("Exception in submitClaim method :" + e.getMessage());
				}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in submitclaim method :" + e.getMessage());
		}
	}

	public static void viewClaimDetails() {
		DatabaseConnection db = new DatabaseConnection();
		try (Connection connection = db.getConnection()){
				Scanner scanner = new Scanner(System.in);

			System.out.print("Enter claim ID to view details: ");
			int claimId = scanner.nextInt();

			String query = "SELECT * FROM Claim WHERE claim_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(query)) {
				statement.setInt(1, claimId);
				ResultSet resultSet = statement.executeQuery();
				if (resultSet.next()) {
					System.out.println("Claim ID: " + resultSet.getInt("claim_id"));
					System.out.println("Policy ID: " + resultSet.getInt("policy_id"));
					System.out.println("Policyholder ID: " + resultSet.getInt("policyholder_id"));
					System.out.println("Claim Date: " + resultSet.getString("claim_date"));
					System.out.println("Status: " + resultSet.getString("status"));
				} else {
					System.out.println("Claim not found.");
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in viewCliam method :" + e.getMessage());
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in viewCliam method :" + e.getMessage());
		}
	}

	public static void updateClaimInformation() {
		DatabaseConnection db = new DatabaseConnection();
		try (Connection connection = db.getConnection()){
				Scanner scanner = new Scanner(System.in);

			System.out.print("Enter claim ID to update: ");
			int claimId = scanner.nextInt();
			scanner.nextLine(); // consume newline

			System.out.print("Enter new policy ID: ");
			int policyId = scanner.nextInt();

			System.out.print("Enter new policyholder ID: ");
			int policyholderId = scanner.nextInt();
			scanner.nextLine(); // consume newline

			System.out.print("Enter new claim date (YYYY-MM-DD): ");
			String claimDate = scanner.nextLine();

			System.out.print("Enter new claim status: ");
			String status = scanner.nextLine();

			String query = "UPDATE Claim SET policy_id = ?, policyholder_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(query)) {
				statement.setInt(1, policyId);
				statement.setInt(2, policyholderId);
				statement.setString(3, claimDate);
				statement.setString(4, status);
				statement.setInt(5, claimId);
				int rowsUpdated = statement.executeUpdate();
				if (rowsUpdated > 0) {
					System.out.println("Claim updated successfully.");
				} else {
					System.out.println("Claim not found.");
				}
				
			}
			catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in updateclaim method :" + e.getMessage());
			}

		}catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in updateclaim method :" + e.getMessage());
		}
	}

	public static void deleteClaim() {
		DatabaseConnection db = new DatabaseConnection();
		try (Connection connection = db.getConnection()){
			Scanner scanner = new Scanner(System.in);

			System.out.print("Enter claim ID to delete: ");
			int claimId = scanner.nextInt();

			String query = "DELETE FROM Claim WHERE claim_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(query)) {
				statement.setInt(1, claimId);
				int rowsDeleted = statement.executeUpdate();
				if (rowsDeleted > 0) {
					System.out.println("Claim deleted successfully.");
				} else {
					System.out.println("Claim not found.");
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in deletecliam method :" + e.getMessage());
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in deletecliam method :" + e.getMessage());
		} 
	}
}
