package com.cognizant.lifeinsurancesystem;
import java.util.Scanner;
import java.sql.*;
public class PolicyholderManagement {
	 public static void registerPolicyholder() {
		 DatabaseConnection db = new DatabaseConnection();
	        try (Connection connection = db.getConnection()){
	             Scanner scanner = new Scanner(System.in); 

	            System.out.print("Enter policyholder name: ");
	            String name = scanner.nextLine();

	            System.out.print("Enter policyholder email: ");
	            String email = scanner.nextLine();

	            System.out.print("Enter policyholder phone number: ");
	            String phoneNumber = scanner.nextLine();

	            System.out.print("Enter policyholder address: ");
	            String address = scanner.nextLine();

	            String query = "INSERT INTO Policyholder (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
	            try (PreparedStatement statement = connection.prepareStatement(query)) {
	                statement.setString(1, name);
	                statement.setString(2, email);
	                statement.setString(3, phoneNumber);
	                statement.setString(4, address);
	                statement.executeUpdate();
	                System.out.println("Policyholder added successfully.");
	            }
	            catch (Exception e) {
					e.printStackTrace();
					System.out.println("Exception in registerpolicyholder method :" + e.getMessage());
				}

	        }  catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in registerpolicyholder method :" + e.getMessage());
			}
	    }

	    public static void viewPolicyholderDetails( ) {
	    	DatabaseConnection db = new DatabaseConnection();
	        try (Connection connection = db.getConnection()){
	             Scanner scanner = new Scanner(System.in); 

	            System.out.print("Enter policyholder ID to view details:");
	            int policyholderId = scanner.nextInt();
//	            scanner.close();
	            String query = "SELECT * FROM Policyholder WHERE policyholder_id = ?";
	            try (PreparedStatement statement = connection.prepareStatement(query)) {
	                statement.setInt(1, policyholderId);
	                ResultSet resultSet = statement.executeQuery();
	                if (resultSet.next()) {
	                    System.out.println("Policyholder ID: " + resultSet.getInt("policyholder_id"));
	                    System.out.println("Name: " + resultSet.getString("name"));
	                    System.out.println("Email: " + resultSet.getString("email"));
	                    System.out.println("Phone Number: " + resultSet.getString("phone_number"));
	                    System.out.println("Address: " + resultSet.getString("address"));
	                } else {
	                    System.out.println("Policyholder not found.");
	                }
	            }catch (Exception e) {
					e.printStackTrace();
					System.out.println("Exception in viewPolicyholderDetails method :" + e.getMessage());
	        }
	    } catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in viewPolicyholderDetails method :" + e.getMessage());
		}
	    }

	    public static void updatePolicyholderInformation() {
	    	DatabaseConnection db = new DatabaseConnection();
	        try (Connection connection = db.getConnection();
	             Scanner scanner = new Scanner(System.in)) {

	            System.out.print("Enter policyholder ID to update: ");
	            int policyholderId = scanner.nextInt();
	            scanner.nextLine(); // consume newline

	            System.out.print("Enter new policyholder name: ");
	            String name = scanner.nextLine();

	            System.out.print("Enter new policyholder email: ");
	            String email = scanner.nextLine();

	            System.out.print("Enter new policyholder phone number: ");
	            String phoneNumber = scanner.nextLine();

	            System.out.print("Enter new policyholder address: ");
	            String address = scanner.nextLine();

	            String query = "UPDATE Policyholder SET name = ?, email = ?, phone_number = ?, address = ? WHERE policyholder_id = ?";
	            try (PreparedStatement statement = connection.prepareStatement(query)) {
	                statement.setString(1, name);
	                statement.setString(2, email);
	                statement.setString(3, phoneNumber);
	                statement.setString(4, address);
	                statement.setInt(5, policyholderId);
	                int rowsUpdated = statement.executeUpdate();
	                if (rowsUpdated > 0) {
	                    System.out.println("Policyholder updated successfully.");
	                } else {
	                    System.out.println("Policyholder not found.");
	                }
	            }
	            catch (Exception e) {
					e.printStackTrace();
					System.out.println("Exception in updatePolicyholderInformation method :" + e.getMessage());
				}

	        } catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in updatePolicyholderInformation method :" + e.getMessage());
			}
	    }

	    public static void deletePolicyholder() {
	    	DatabaseConnection db = new DatabaseConnection();
	        try (Connection connection = db.getConnection()){
	             Scanner scanner = new Scanner(System.in);

	            System.out.print("Enter policyholder ID to delete: ");
	            int policyholderId = scanner.nextInt();

	            String query = "DELETE FROM Policyholder WHERE policyholder_id = ?";
	            try (PreparedStatement statement = connection.prepareStatement(query)) {
	                statement.setInt(1, policyholderId);
	                int rowsDeleted = statement.executeUpdate();
	                if (rowsDeleted > 0) {
	                    System.out.println("Policyholder deleted successfully.");
	                } else {
	                    System.out.println("Policyholder not found.");
	                }
	            }
	            catch (Exception e) {
					e.printStackTrace();
					System.out.println("Exception in deletePolicyholder method :" + e.getMessage());
				}

	        } 
	        catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in deletePolicyholder method :" + e.getMessage());
			}
	    }

}
