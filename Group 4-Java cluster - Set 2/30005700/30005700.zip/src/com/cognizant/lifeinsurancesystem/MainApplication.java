package com.cognizant.lifeinsurancesystem;
import java.util.Scanner;
public class MainApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		
		while(true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("<---Life Insurance Managaement System--->");
			System.out.println("1. manage policies");
			System.out.println("2. manage policyholders");
			System.out.println("3. manage claims");
			System.out.println("4.exit");
			System.out.println("choose an option:");
			int choice = Integer.parseInt(sc.nextLine().trim());
			
			switch(choice) {
			case 1:
				managePolicies();
				break;
			case 2:
				managePolicyholders();
				break;
			case 3:
				manageClaims();
				break;
			case 4:
				System.out.println("exiting...");
				System.exit(0);
			default:
				System.out.println("invalid choice. please try again");
			}
			
		}
		}catch(Exception e) {
			System.out.println("Exception in main class :"+e.getMessage());
		}

	}

	private static void managePolicies() {
		// TODO Auto-generated method stub
		while(true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("policy Management");
			System.out.println("1. Add Policy");
			System.out.println("2. view policy details");
			System.out.println("3. update policy information");
			System.out.println("4. delete policy");
			System.out.println("5. Back to Main Menu");
			System.out.println("Choose an option:");
			
			int choice = sc.nextInt();
			
			switch(choice) {
			case 1:
				PolicyManagement.addPolicy();
				break;
			case 2:
				PolicyManagement.viewPolicyDetails();
				break;
			case 3:
				PolicyManagement.updatePolicyInformation();
				break;
			case 4:
				PolicyManagement.deletePolicy();
				break;
			case 5:
				return;
			default:
				System.out.println("Invalid choice");
			}
		}
		
	}

	private static void managePolicyholders() {
		// TODO Auto-generated method stub
			int flag =0;
	        while (true) {
	        	Scanner scanner = new Scanner(System.in);
	            System.out.println("Policyholder Management");
	            System.out.println("1. Register Policyholder");
	            System.out.println("2. View Policyholder Details");
	            System.out.println("3. Update Policyholder Information");
	            System.out.println("4. Delete Policyholder");
	            System.out.println("5. Back to Main Menu");
	            System.out.println("Choose an option:");
	            int	choice = Integer.parseInt(scanner.nextLine().trim());
//	            scanner.close();
	            switch (choice) {
	                case 1:
	                    PolicyholderManagement.registerPolicyholder();
	                    break;
	                case 2:
	                	PolicyholderManagement.viewPolicyholderDetails( );
	                    break;
	                case 3:
	                	PolicyholderManagement.updatePolicyholderInformation();
	                    break;
	                case 4:
	                	PolicyholderManagement.deletePolicyholder();
	                    break;
	                case 5:
	                    return;
	                default:
	                    System.out.println("Invalid choice.");
		
	}
	            flag=1;
	}
	}

	private static void manageClaims() {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Claim Management");
            System.out.println("1. Submit Claim");
            System.out.println("2. View Claim Details");
            System.out.println("3. Update Claim Information");
            System.out.println("4. Delete Claim");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                	ClaimManagement.submitClaim();
                    break;
                case 2:
                	ClaimManagement.viewClaimDetails();
                    break;
                case 3:
                	ClaimManagement.updateClaimInformation();
                    break;
                case 4:
                	ClaimManagement.deleteClaim();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
		
	}

}
