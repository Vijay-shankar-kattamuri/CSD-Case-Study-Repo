package com.cognizant.lifeinsurancesystem;

import java.sql.PreparedStatement;
import java.sql.*;
import java.util.Scanner;

public class PolicyManagement {
	public static void addPolicy() {
		DatabaseConnection db = new DatabaseConnection();
		try (Connection conn = db.getConnection()) {
			Scanner sc = new Scanner(System.in);
			System.out.println("enter policy number:");
			int policyNumber = Integer.parseInt(sc.nextLine());

			System.out.println("enter policy type:");
			String type = sc.nextLine();

			System.out.print("Enter coverage amount: ");
			double coverageAmount = sc.nextDouble();

			System.out.print("Enter premium amount: ");
			double premiumAmount = sc.nextDouble();

			String que = "INSERT INTO policy(policy_number, type, coverage_amount, premium_amount) VALUES(?, ?, ?, ?)";
			try (PreparedStatement st = conn.prepareStatement(que)) {
				st.setInt(1, policyNumber);
				st.setString(2, type);
				st.setDouble(3, coverageAmount);
				st.setDouble(4, premiumAmount);
				st.executeUpdate();
				System.out.println("Policy added successfully.");
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in addPolicy method :" + e.getMessage());
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in addPolicy method :" + e.getMessage());
		}
	}

	public static void viewPolicyDetails() {
		DatabaseConnection db = new DatabaseConnection();
		try (Connection connection = db.getConnection()) {

			Scanner sc = new Scanner(System.in);

			System.out.print("Enter policy ID to view details: ");
			int policyId = sc.nextInt();

			String query = "SELECT * FROM Policy WHERE policy_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(query)) {
				statement.setInt(1, policyId);
				ResultSet resultSet = statement.executeQuery();
				if (resultSet.next()) {
					System.out.println("Policy ID: " + resultSet.getInt("policy_id"));
					System.out.println("Policy Number: " + resultSet.getString("policy_number"));
					System.out.println("Type: " + resultSet.getString("type"));
					System.out.println("Coverage Amount: " + resultSet.getDouble("coverage_amount"));
					System.out.println("Premium Amount: " + resultSet.getDouble("premium_amount"));
				} else {
					System.out.println("Policy not found.");
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in viewPolicy method :" + e.getMessage());
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in viewPolicy method :" + e.getMessage());
		}
	}

	public static void updatePolicyInformation() {
		DatabaseConnection db = new DatabaseConnection();
		try (Connection connection = db.getConnection()) {
			Scanner sc = new Scanner(System.in);

			System.out.print("Enter policy ID to update: ");
			int policyId = sc.nextInt();
			sc.nextLine(); // consume newline

			System.out.print("Enter new policy number: ");
			String policyNumber = sc.nextLine();

			System.out.print("Enter new policy type: ");
			String type = sc.nextLine();

			System.out.print("Enter new coverage amount: ");
			double coverageAmount = sc.nextDouble();

			System.out.print("Enter new premium amount: ");
			double premiumAmount = sc.nextDouble();

			String query = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(query)) {
				statement.setString(1, policyNumber);
				statement.setString(2, type);
				statement.setDouble(3, coverageAmount);
				statement.setDouble(4, premiumAmount);
				statement.setInt(5, policyId);
				int rowsUpdated = statement.executeUpdate();
				if (rowsUpdated > 0) {
					System.out.println("Policy updated successfully.");
				} else {
					System.out.println("Policy not found.");
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in updatePolicy method :" + e.getMessage());
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in updatePolicy method :" + e.getMessage());
		}
	}

	public static void deletePolicy() {
		DatabaseConnection db = new DatabaseConnection();
		try (Connection connection = db.getConnection()) {
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter policy ID to delete: ");
			int policyId = sc.nextInt();

			String query = "DELETE FROM Policy WHERE policy_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(query)) {
				statement.setInt(1, policyId);
				int rowsDeleted = statement.executeUpdate();
				if (rowsDeleted > 0) {
					System.out.println("Policy deleted successfully.");
				} else {
					System.out.println("Policy not found.");
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception in deletePolicy method :" + e.getMessage());
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in deletePolicy method :" + e.getMessage());
		}

	}

}
