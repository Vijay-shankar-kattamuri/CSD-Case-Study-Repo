package com.cognizant.lifeinsurancesystem;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

	public Connection getConnection() {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			//step2: establish connection
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/new_Schema","root","Sri@2024");
			return con;
		}catch(Exception e) {
			System.out.println("Exception while creating database connection  :"+e.getMessage());
			return null;
		}
		
	}

}
