----------Life Insurance Management System----------

## Overview

This is a console-based application to manage policies, policyholders, and claims for a life insurance management system. It demonstrates proficiency in Core Java, MySQL, and JDBC.

## Features

1. Policy Management
   - Add a new policy
   - View policy details
   - Update policy information
   - Delete a policy

2. Policyholder Management
   - Register a new policyholder
   - View policyholder details
   - Update policyholder information
   - Delete a policyholder

3. Claim Management
   - Submit a new claim
   - View claim details
   - Update claim information
   - Delete a claim

## Setup

1. Install MySQL and create a database:

CREATE DATABASE LifeInsuranceDB;

USE LifeInsuranceDB;

CREATE TABLE Policy (
    policy_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_number VARCHAR(50) NOT NULL,
    type VARCHAR(50),
    coverage_amount DECIMAL(10, 2),
    premium_amount DECIMAL(10, 2)
);

CREATE TABLE Policyholder (
    policyholder_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    phone_number VARCHAR(15),
    address VARCHAR(255)
);

CREATE TABLE Claim (
    claim_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_id INT,
    policyholder_id INT,
    claim_date DATE,
    status VARCHAR(20),
    FOREIGN KEY (policy_id) REFERENCES Policy(policy_id),
    FOREIGN KEY (policyholder_id) REFERENCES Policyholder(policyholder_id)
);

