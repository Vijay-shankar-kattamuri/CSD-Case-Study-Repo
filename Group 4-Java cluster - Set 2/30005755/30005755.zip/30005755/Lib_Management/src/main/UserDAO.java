package main;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private Connection connection;

    public UserDAO(Connection connection) {
        this.connection = connection;
    }

    public void addUser(User user) throws SQLException {
        String sql = "INSERT INTO User (user_id,username, email, date_of_birth, membership_date, membership_status) VALUES (?,?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
        	statement.setInt(1, user.getUserId());
            statement.setString(2, user.getUsername());
            statement.setString(3, user.getEmail());
            statement.setDate(4, new java.sql.Date(user.getDateOfBirth().getTime()));
            statement.setDate(5, new java.sql.Date(user.getMembershipDate().getTime()));
            statement.setString(6, user.getMembershipStatus());
            statement.executeUpdate();
        }
    }

    public User getUser(int id) throws SQLException {
        String sql = "SELECT * FROM User WHERE user_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                User user = new User();
                user.setUserId(resultSet.getInt("user_id"));
                user.setUsername(resultSet.getString("username"));
                user.setEmail(resultSet.getString("email"));
                user.setDateOfBirth(resultSet.getDate("date_of_birth"));
                user.setMembershipDate(resultSet.getDate("membership_date"));
                user.setMembershipStatus(resultSet.getString("membership_status"));
                return user;
            }
        }
        return null;
    }

    public void updateUser(User user) throws SQLException {
        String sql = "UPDATE User SET username = ?, email = ?, date_of_birth = ?, membership_date = ?, membership_status = ? WHERE user_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getEmail());
            statement.setDate(3, new java.sql.Date(user.getDateOfBirth().getTime()));
            statement.setDate(4, new java.sql.Date(user.getMembershipDate().getTime()));
            statement.setString(5, user.getMembershipStatus());
            statement.setInt(6, user.getUserId());
            statement.executeUpdate();
        }
    }

    public void deleteUser(int id) throws SQLException {
        String sql = "DELETE FROM User WHERE user_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    public List<User> getAllUsers() throws SQLException {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM User";
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                User user = new User();
                user.setUserId(resultSet.getInt("user_id"));
                user.setUsername(resultSet.getString("username"));
                user.setEmail(resultSet.getString("email"));
                user.setDateOfBirth(resultSet.getDate("date_of_birth"));
                user.setMembershipDate(resultSet.getDate("membership_date"));
                user.setMembershipStatus(resultSet.getString("membership_status"));
                users.add(user);
            }
        }
        return users;
    }
}
