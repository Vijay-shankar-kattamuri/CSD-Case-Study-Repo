package main;

import java.util.*;
import java.sql.*;


public class LibraryManagementSystem {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/LibraryDB";
    private static final String USER = "root";
    private static final String PASS = "sowmith40";

    private static Connection connection;
    private static Scanner scanner;

    public static void main(String[] args) {
        try {
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            scanner = new Scanner(System.in);
            run();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void run() {
        while (true) {
            System.out.println("1. Manage E-Books");
            System.out.println("2. Manage Authors");
            System.out.println("3. Manage Memberships");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    manageEBooks();
                    break;
                case 2:
                    manageAuthors();
                    break;
                case 3:
                    manageMemberships();
                    break;
                case 4:
                    System.exit(0);
            }
        }
    }

    private static void manageEBooks() {
        EBookDAO ebookDAO = new EBookDAO(connection);
        System.out.println("1. Add E-Book");
        System.out.println("2. View E-Book");
        System.out.println("3. Update E-Book");
        System.out.println("4. Delete E-Book");
        System.out.println("5. View All E-Books");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addEBook(ebookDAO);
                break;
            case 2:
                viewEBook(ebookDAO);
                break;
            case 3:
                updateEBook(ebookDAO);
                break;
            case 4:
                deleteEBook(ebookDAO);
                break;
            case 5:
                viewAllEBooks(ebookDAO);
                break;
        }
    }

    private static void manageAuthors() {
        AuthorDAO authorDAO = new AuthorDAO(connection);
        System.out.println("1. Add Author");
        System.out.println("2. View Author");
        System.out.println("3. Update Author");
        System.out.println("4. Delete Author");
        System.out.println("5. View All Authors");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addAuthor(authorDAO);
                break;
            case 2:
                viewAuthor(authorDAO);
                break;
            case 3:
                updateAuthor(authorDAO);
                break;
            case 4:
                deleteAuthor(authorDAO);
                break;
            case 5:
                viewAllAuthors(authorDAO);
                break;
        }
    }

    private static void manageMemberships() {
        UserDAO userDAO = new UserDAO(connection);
        System.out.println("1. Register User");
        System.out.println("2. View Membership");
        System.out.println("3. Update Membership");
        System.out.println("4. Cancel Membership");
        System.out.println("5. View All Memberships");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addUser(userDAO);
                break;
            case 2:
                viewUser(userDAO);
                break;
            case 3:
                updateUser(userDAO);
                break;
            case 4:
                deleteUser(userDAO);
                break;
            case 5:
                viewAllUsers(userDAO);
                break;
        }
    }

    private static void addEBook(EBookDAO ebookDAO) {
        try {
            EBook ebook = new EBook();
            System.out.print("Enter E-Book ID: ");
            ebook.setEbookId(scanner.nextInt());
            System.out.print("Enter title: ");
            ebook.setTitle(scanner.next());
            System.out.print("Enter genre: ");
            ebook.setGenre(scanner.next());
            System.out.print("Enter publication date (yyyy-mm-dd): ");
            ebook.setPublicationDate(java.sql.Date.valueOf(scanner.next()));
            System.out.print("Enter author ID: ");
            ebook.setAuthorId(scanner.nextInt());
            System.out.print("Enter available copies: ");
            ebook.setAvailableCopies(scanner.nextInt());
            ebookDAO.addEBook(ebook);
            System.out.println("E-Book added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewEBook(EBookDAO ebookDAO) {
        try {
            System.out.print("Enter E-Book ID: ");
            int id = scanner.nextInt();
            EBook ebook = ebookDAO.getEBook(id);
            if (ebook != null) {
                System.out.println("ID: " + ebook.getEbookId());
                System.out.println("Title: " + ebook.getTitle());
                System.out.println("Genre: " + ebook.getGenre());
                System.out.println("Publication Date: " + ebook.getPublicationDate());
                System.out.println("Author ID: " + ebook.getAuthorId());
                System.out.println("Available Copies: " + ebook.getAvailableCopies());
            } else {
                System.out.println("E-Book not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateEBook(EBookDAO ebookDAO) {
        try {
            EBook ebook = new EBook();
            System.out.print("Enter E-Book ID: ");
            ebook.setEbookId(scanner.nextInt());
            System.out.print("Enter new title: ");
            ebook.setTitle(scanner.next());
            System.out.print("Enter new genre: ");
            ebook.setGenre(scanner.next());
            System.out.print("Enter new publication date (yyyy-mm-dd): ");
            ebook.setPublicationDate(java.sql.Date.valueOf(scanner.next()));
            System.out.print("Enter new author ID: ");
            ebook.setAuthorId(scanner.nextInt());
            System.out.print("Enter new available copies: ");
            ebook.setAvailableCopies(scanner.nextInt());
            ebookDAO.updateEBook(ebook);
            System.out.println("E-Book updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteEBook(EBookDAO ebookDAO) {
        try {
            System.out.print("Enter E-Book ID: ");
            int id = scanner.nextInt();
            ebookDAO.deleteEBook(id);
            System.out.println("E-Book deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllEBooks(EBookDAO ebookDAO) {
        try {
            List<EBook> ebooks = ebookDAO.getAllEBooks();
            for (EBook ebook : ebooks) {
                System.out.println("ID: " + ebook.getEbookId());
                System.out.println("Title: " + ebook.getTitle());
                System.out.println("Genre: " + ebook.getGenre());
                System.out.println("Publication Date: " + ebook.getPublicationDate());
                System.out.println("Author ID: " + ebook.getAuthorId());
                System.out.println("Available Copies: " + ebook.getAvailableCopies());
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addAuthor(AuthorDAO authorDAO) {
        try {
            Author author = new Author();
            System.out.print("Enter Author ID: ");
            author.setAuthorId(scanner.nextInt());
            System.out.print("Enter name: ");
            author.setName(scanner.next());
            System.out.print("Enter bio: ");
            author.setBio(scanner.next());
            System.out.print("Enter nationality: ");
            author.setNationality(scanner.next());
            
            System.out.print("Enter birth date (yyyy-mm-dd): ");
            author.setBirthDate(java.sql.Date.valueOf(scanner.next()));
            authorDAO.addAuthor(author);
            System.out.println("Author added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAuthor(AuthorDAO authorDAO) {
        try {
            System.out.print("Enter Author ID: ");
            int id = scanner.nextInt();
            Author author = authorDAO.getAuthor(id);
            if (author != null) {
                System.out.println("ID: " + author.getAuthorId());
                System.out.println("Name: " + author.getName());
                System.out.println("Bio: " + author.getBio());
                System.out.println("Nationality: " + author.getNationality());
                System.out.println("Birth Date: " + author.getBirthDate());
            } else {
                System.out.println("Author not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateAuthor(AuthorDAO authorDAO) {
        try {
            Author author = new Author();
            System.out.print("Enter Author ID: ");
            author.setAuthorId(scanner.nextInt());
            System.out.print("Enter new name: ");
            author.setName(scanner.next());
            System.out.print("Enter new bio: ");
            author.setBio(scanner.next());
            System.out.print("Enter new nationality: ");
            author.setNationality(scanner.next());
            System.out.print("Enter new birth date (yyyy-mm-dd): ");
            author.setBirthDate(java.sql.Date.valueOf(scanner.next()));
            authorDAO.updateAuthor(author);
            System.out.println("Author updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteAuthor(AuthorDAO authorDAO) {
        try {
            System.out.print("Enter Author ID: ");
            int id = scanner.nextInt();
            authorDAO.deleteAuthor(id);
            System.out.println("Author deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllAuthors(AuthorDAO authorDAO) {
        try {
            List<Author> authors = authorDAO.getAllAuthors();
            for (Author author : authors) {
                System.out.println("ID: " + author.getAuthorId());
                System.out.println("Name: " + author.getName());
                System.out.println("Bio: " + author.getBio());
                System.out.println("Nationality: " + author.getNationality());
                System.out.println("Birth Date: " + author.getBirthDate());
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addUser(UserDAO userDAO) {
        try {
            User user = new User();
            System.out.print("Enter User ID: ");
            user.setUserId(scanner.nextInt());
            System.out.print("Enter username: ");
            user.setUsername(scanner.next());
            System.out.print("Enter email: ");
            user.setEmail(scanner.next());
            System.out.print("Enter date of birth (yyyy-mm-dd): ");
            user.setDateOfBirth(java.sql.Date.valueOf(scanner.next()));
            System.out.print("Enter membership date (yyyy-mm-dd): ");
            user.setMembershipDate(java.sql.Date.valueOf(scanner.next()));
            System.out.print("Enter membership status: ");
            user.setMembershipStatus(scanner.next());
            userDAO.addUser(user);
            System.out.println("User registered successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewUser(UserDAO userDAO) {
        try {
            System.out.print("Enter User ID: ");
            int id = scanner.nextInt();
            User user = userDAO.getUser(id);
            if (user != null) {
                System.out.println("ID: " + user.getUserId());
                System.out.println("Username: " + user.getUsername());
                System.out.println("Email: " + user.getEmail());
                System.out.println("Date of Birth: " + user.getDateOfBirth());
                System.out.println("Membership Date: " + user.getMembershipDate());
                System.out.println("Membership Status: " + user.getMembershipStatus());
            } else {
                System.out.println("User not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateUser(UserDAO userDAO) {
        try {
            User user = new User();
            System.out.print("Enter User ID: ");
            user.setUserId(scanner.nextInt());
            System.out.print("Enter new username: ");
            user.setUsername(scanner.next());
            System.out.print("Enter new email: ");
            user.setEmail(scanner.next());
            System.out.print("Enter new date of birth (yyyy-mm-dd): ");
            user.setDateOfBirth(java.sql.Date.valueOf(scanner.next()));
            System.out.print("Enter new membership date (yyyy-mm-dd): ");
            user.setMembershipDate(java.sql.Date.valueOf(scanner.next()));
            System.out.print("Enter new membership status: ");
            user.setMembershipStatus(scanner.next());
            userDAO.updateUser(user);
            System.out.println("User updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteUser(UserDAO userDAO) {
        try {
            System.out.print("Enter User ID: ");
            int id = scanner.nextInt();
            userDAO.deleteUser(id);
            System.out.println("User deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllUsers(UserDAO userDAO) {
        try {
            List<User> users = userDAO.getAllUsers();
            for (User user : users) {
                System.out.println("ID: " + user.getUserId());
                System.out.println("Username: " + user.getUsername());
                System.out.println("Email: " + user.getEmail());
                System.out.println("Date of Birth: " + user.getDateOfBirth());
                System.out.println("Membership Date: " + user.getMembershipDate());
                System.out.println("Membership Status: " + user.getMembershipStatus());
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
