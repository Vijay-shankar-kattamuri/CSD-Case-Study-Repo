package main;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EBookDAO {
    private Connection connection;

    public EBookDAO(Connection connection) {
        this.connection = connection;
    }

    public void addEBook(EBook ebook) throws SQLException {
        String sql = "INSERT INTO Ebook (ebook_id,title, genre, publication_date, author_id, available_copies) VALUES (?,?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
        	statement.setInt(1, ebook.getEbookId());
            statement.setString(2, ebook.getTitle());
            statement.setString(3, ebook.getGenre());
            statement.setDate(4, new java.sql.Date(ebook.getPublicationDate().getTime()));
            statement.setInt(5, ebook.getAuthorId());
            statement.setInt(6, ebook.getAvailableCopies());
            statement.executeUpdate();
        }
    }

    public EBook getEBook(int id) throws SQLException {
        String sql = "SELECT * FROM Ebook WHERE ebook_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                EBook ebook = new EBook();
                ebook.setEbookId(resultSet.getInt("ebook_id"));
                ebook.setTitle(resultSet.getString("title"));
                ebook.setGenre(resultSet.getString("genre"));
                ebook.setPublicationDate(resultSet.getDate("publication_date"));
                ebook.setAuthorId(resultSet.getInt("author_id"));
                ebook.setAvailableCopies(resultSet.getInt("available_copies"));
                return ebook;
            }
        }
        return null;
    }

    public void updateEBook(EBook ebook) throws SQLException {
        String sql = "UPDATE Ebook SET title = ?, genre = ?, publication_date = ?, author_id = ?, available_copies = ? WHERE ebook_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, ebook.getTitle());
            statement.setString(2, ebook.getGenre());
            statement.setDate(3, new java.sql.Date(ebook.getPublicationDate().getTime()));
            statement.setInt(4, ebook.getAuthorId());
            statement.setInt(5, ebook.getAvailableCopies());
            statement.setInt(6, ebook.getEbookId());
            statement.executeUpdate();
        }
    }

    public void deleteEBook(int id) throws SQLException {
        String sql = "DELETE FROM Ebook WHERE ebook_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    public List<EBook> getAllEBooks() throws SQLException {
        List<EBook> ebooks = new ArrayList<>();
        String sql = "SELECT * FROM Ebook";
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                EBook ebook = new EBook();
                ebook.setEbookId(resultSet.getInt("ebook_id"));
                ebook.setTitle(resultSet.getString("title"));
                ebook.setGenre(resultSet.getString("genre"));
                ebook.setPublicationDate(resultSet.getDate("publication_date"));
                ebook.setAuthorId(resultSet.getInt("author_id"));
                ebook.setAvailableCopies(resultSet.getInt("available_copies"));
                ebooks.add(ebook);
            }
        }
        return ebooks;
    }
}
