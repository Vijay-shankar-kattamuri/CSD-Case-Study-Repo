package main;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AuthorDAO {
    private Connection connection;

    public AuthorDAO(Connection connection) {
        this.connection = connection;
    }

    public void addAuthor(Author author) throws SQLException {
        String sql = "INSERT INTO Author (author_id,name, bio, nationality, birth_date) VALUES (?,?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
        	statement.setInt(1, author.getAuthorId());
            statement.setString(2, author.getName());
            statement.setString(3, author.getBio());
            statement.setString(4, author.getNationality());
            statement.setDate(5, new java.sql.Date(author.getBirthDate().getTime()));
            statement.executeUpdate();
        }
    }

    public Author getAuthor(int id) throws SQLException {
        String sql = "SELECT * FROM Author WHERE author_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Author author = new Author();
                author.setAuthorId(resultSet.getInt("author_id"));
                author.setName(resultSet.getString("name"));
                author.setBio(resultSet.getString("bio"));
                author.setNationality(resultSet.getString("nationality"));
                author.setBirthDate(resultSet.getDate("birth_date"));
                return author;
            }
        }
        return null;
    }

    public void updateAuthor(Author author) throws SQLException {
        String sql = "UPDATE Author SET name = ?, bio = ?, nationality = ?, birth_date = ? WHERE author_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, author.getName());
            statement.setString(2, author.getBio());
            statement.setString(3, author.getNationality());
            statement.setDate(4, new java.sql.Date(author.getBirthDate().getTime()));
            statement.setInt(5, author.getAuthorId());
            statement.executeUpdate();
        }
    }

    public void deleteAuthor(int id) throws SQLException {
        String sql = "DELETE FROM Author WHERE author_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    public List<Author> getAllAuthors() throws SQLException {
        List<Author> authors = new ArrayList<>();
        String sql = "SELECT * FROM Author";
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                Author author = new Author();
                author.setAuthorId(resultSet.getInt("author_id"));
                author.setName(resultSet.getString("name"));
                author.setBio(resultSet.getString("bio"));
                author.setNationality(resultSet.getString("nationality"));
                author.setBirthDate(resultSet.getDate("birth_date"));
                authors.add(author);
            }
        }
        return authors;
    }
}
