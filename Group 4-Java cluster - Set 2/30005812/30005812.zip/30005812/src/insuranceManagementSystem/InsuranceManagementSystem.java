package insuranceManagementSystem;

import java.sql.SQLException;
import java.util.Scanner;

public class InsuranceManagementSystem {
	
	public static void main(String[] args) {
		
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
        	System.out.println();
            System.out.println("Insurance Management System");
            System.out.println();
            System.out.println("Policy Management Option Available");
            System.out.println();
            System.out.println("1. Add Policy");
            System.out.println("2. View Policy");
            System.out.println("3. Update Policy");
            System.out.println("4. Delete Policy");
            System.out.println();
            System.out.println("Customer Management Option Available");
            System.out.println();
            System.out.println("5. Register Customer");
            System.out.println("6. View Customer");
            System.out.println("7. Update Customer");
            System.out.println("8. Delete Customer");
            System.out.println();
            System.out.println("Claim Management Option Available");
            System.out.println();
            System.out.println("9. Submit Claim");
            System.out.println("10. View Claim");
            System.out.println("11. Update Claim");
            System.out.println("12. Delete Claim");
            System.out.println();
            System.out.println("Close the Management System");
            System.out.println();
            System.out.println("13. Exit");
            System.out.println();
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Policy Number: ");
                        String policyNumber = scanner.nextLine();
                        System.out.print("Enter Type: ");
                        String type = scanner.nextLine();
                        System.out.print("Enter Coverage Amount: ");
                        double coverageAmount = scanner.nextDouble();
                        System.out.print("Enter Premium Amount: ");
                        double premiumAmount = scanner.nextDouble();
                        Policy.addPolicy(policyNumber, type, coverageAmount, premiumAmount);
                        break;
                    case 2:
                        System.out.print("Enter Policy ID: ");
                        int policyId = scanner.nextInt();
                        Policy.viewPolicy(policyId);
                        break;
                    case 3:
                        System.out.print("Enter Policy ID: ");
                        policyId = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Policy Number: ");
                        policyNumber = scanner.nextLine();
                        System.out.print("Enter Type: ");
                        type = scanner.nextLine();
                        System.out.print("Enter Coverage Amount: ");
                        coverageAmount = scanner.nextDouble();
                        System.out.print("Enter Premium Amount: ");
                        premiumAmount = scanner.nextDouble();
                        Policy.updatePolicy(policyId, policyNumber, type, coverageAmount, premiumAmount);
                        break;
                    case 4:
                        System.out.print("Enter Policy ID: ");
                        policyId = scanner.nextInt();
                        Policy.deletePolicy(policyId);
                        break;
                    case 5:
                        System.out.print("Enter Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter Phone Number: ");
                        String phoneNumber = scanner.nextLine();
                        System.out.print("Enter Address: ");
                        String address = scanner.nextLine();
                        Customer.addCustomer(name, email, phoneNumber, address);
                        break;
                    case 6:
                        System.out.print("Enter Customer ID: ");
                        int customerId = scanner.nextInt();
                        Customer.viewCustomer(customerId);
                        break;
                    case 7:
                        System.out.print("Enter Customer ID: ");
                        customerId = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Name: ");
                        name = scanner.nextLine();
                        System.out.print("Enter Email: ");
                        email = scanner.nextLine();
                        System.out.print("Enter Phone Number: ");
                        phoneNumber = scanner.nextLine();
                        System.out.print("Enter Address: ");
                        address = scanner.nextLine();
                        Customer.updateCustomer(customerId, name, email, phoneNumber, address);
                        break;
                    case 8:
                        System.out.print("Enter Customer ID: ");
                        customerId = scanner.nextInt();
                        Customer.deleteCustomer(customerId);
                        break;
                    case 9:
                        System.out.print("Enter Policy ID: ");
                        policyId = scanner.nextInt();
                        System.out.print("Enter Customer ID: ");
                        customerId = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Claim Date (YYYY-MM-DD): ");
                        String claimDate = scanner.nextLine();
                        System.out.print("Enter Status: ");
                        String status = scanner.nextLine();
                        Claim.submitClaim(policyId, customerId, claimDate, status);
                        break;
                    case 10:
                        System.out.print("Enter Claim ID: ");
                        int claimId = scanner.nextInt();
                        Claim.viewClaim(claimId);
                        break;
                    case 11:
                        System.out.print("Enter Claim ID: ");
                        claimId = scanner.nextInt();
                        System.out.print("Enter Policy ID: ");
                        policyId = scanner.nextInt();
                        System.out.print("Enter Customer ID: ");
                        customerId = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Claim Date (YYYY-MM-DD): ");
                        claimDate = scanner.nextLine();
                        System.out.print("Enter Status: ");
                        status = scanner.nextLine();
                        Claim.updateClaim(claimId, policyId, customerId, claimDate, status);
                        break;
                    case 12:
                        System.out.print("Enter Claim ID: ");
                        claimId = scanner.nextInt();
                        Claim.deleteClaim(claimId);
                        break;
                    case 13:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
