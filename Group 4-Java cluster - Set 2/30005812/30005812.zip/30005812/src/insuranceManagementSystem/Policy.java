package insuranceManagementSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Policy {
	
	public static void addPolicy(String policyNumber, String type, double coverageAmount, double premiumAmount) throws SQLException {
        String query = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, policyNumber);
            pst.setString(2, type);
            pst.setDouble(3, coverageAmount);
            pst.setDouble(4, premiumAmount);
            pst.executeUpdate();
            System.out.println("Policy added successfully.");
        }
    }
	
	public static void viewPolicy(int policyId) throws SQLException {
        String query = "SELECT * FROM Policy WHERE policy_id = ?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, policyId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                System.out.println("Policy ID: " + rs.getInt("policy_id"));
                System.out.println("Policy Number: " + rs.getString("policy_number"));
                System.out.println("Type: " + rs.getString("type"));
                System.out.println("Coverage Amount: " + rs.getDouble("coverage_amount"));
                System.out.println("Premium Amount: " + rs.getDouble("premium_amount"));
            } else {
                System.out.println("Policy not found.");
            }
        }
    }
	
	public static void updatePolicy(int policyId, String policyNumber, String type, double coverageAmount, double premiumAmount) throws SQLException {
        String query = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, policyNumber);
            pst.setString(2, type);
            pst.setDouble(3, coverageAmount);
            pst.setDouble(4, premiumAmount);
            pst.setInt(5, policyId);
            int rowsUpdated = pst.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Policy updated successfully.");
            } else {
                System.out.println("Policy not found.");
            }
        }
    }
	
	public static void deletePolicy(int policyId) throws SQLException {
        String query = "DELETE FROM Policy WHERE policy_id = ?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, policyId);
            int rowsDeleted = pst.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Policy deleted successfully.");
            } else {
                System.out.println("Policy not found.");
            }
        }
    }

}
