package insuranceManagementSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Claim {
	
	public static void submitClaim(int policyId, int customerId, String claimDate, String status) throws SQLException {
        String query = "INSERT INTO Claim (policy_id, customer_id, claim_date, status) VALUES (?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, policyId);
            pst.setInt(2, customerId);
            pst.setString(3, claimDate);
            pst.setString(4, status);
            pst.executeUpdate();
            System.out.println("Claim submitted successfully.");
        }
    }
	
	public static void viewClaim(int claimId) throws SQLException {
        String query = "SELECT * FROM Claim WHERE claim_id = ?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, claimId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                System.out.println("Claim ID: " + rs.getInt("claim_id"));
                System.out.println("Policy ID: " + rs.getInt("policy_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Claim Date: " + rs.getDate("claim_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Claim not found.");
            }
        }
    }
	
	public static void updateClaim(int claimId, int policyId, int customerId, String claimDate, String status) throws SQLException {
        String query = "UPDATE Claim SET policy_id = ?, customer_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, policyId);
            pst.setInt(2, customerId);
            pst.setString(3, claimDate);
            pst.setString(4, status);
            pst.setInt(5, claimId);
            int rowsUpdated = pst.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Claim updated successfully.");
            } else {
                System.out.println("Claim not found.");
            }
        }
    }
	
	public static void deleteClaim(int claimId) throws SQLException {
        String query = "DELETE FROM Claim WHERE claim_id = ?";
        try (Connection con = DatabaseConnection.getConnection(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, claimId);
            int rowsDeleted = pst.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Claim deleted successfully.");
            } else {
                System.out.println("Claim not found.");
            }
        }
    }

}
