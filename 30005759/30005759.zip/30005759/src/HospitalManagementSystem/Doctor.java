package HospitalManagementSystem;

import java.sql.*;
import java.util.Scanner;

public class Doctor {
    private final Connection connection;
    private final Scanner scanner;

    public Doctor(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void addDoctor() {
        System.out.print("Enter Doctor Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Doctor Specialization: ");
        String specialization = scanner.nextLine();
        System.out.print("Enter Doctor Contact Number: ");
        String contactNumber = scanner.nextLine();

        String query = "INSERT INTO Doctor (name, specialization, contact_number) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, specialization);
            preparedStatement.setString(3, contactNumber);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Doctor Added Successfully!");
            } else {
                System.out.println("Failed to add Doctor!");
            }
        } catch (SQLException e) {
            System.err.println("Error adding doctor.");
            e.printStackTrace();
        }
    }

    public void viewDoctors() {
        String query = "SELECT * FROM Doctor";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            System.out.println("Doctors: ");
            System.out.println("+------------+--------------------+-----------------+-----------------+");
            System.out.println("| Doctor Id  | Name               | Specialization  | Contact Number  |");
            System.out.println("+------------+--------------------+-----------------+-----------------+");
            while (resultSet.next()) {
                int doctorId = resultSet.getInt("doctor_id");
                String name = resultSet.getString("name");
                String specialization = resultSet.getString("specialization");
                String contactNumber = resultSet.getString("contact_number");
                System.out.printf("| %-10d | %-18s | %-15s | %-15s |\n", doctorId, name, specialization, contactNumber);
                System.out.println("+------------+--------------------+-----------------+-----------------+");
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving doctors.");
            e.printStackTrace();
        }
    }

    public boolean getDoctorById(int id) {
        String query = "SELECT * FROM Doctor WHERE doctor_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next();  // Returns true if there is at least one row in the result set
            }
        } catch (SQLException e) {
            System.err.println("Error checking doctor by ID.");
            e.printStackTrace();
        }
        return false;
    }
}