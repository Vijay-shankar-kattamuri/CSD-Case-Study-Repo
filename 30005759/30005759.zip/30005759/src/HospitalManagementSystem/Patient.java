package HospitalManagementSystem;

import java.sql.*;
import java.util.Scanner;

public class Patient {
    private final Connection connection;
    private final Scanner scanner;

    public Patient(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void addPatient() {
        System.out.print("Enter Patient Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Patient Date of Birth (YYYY-MM-DD): ");
        String dateOfBirth = scanner.nextLine();
        System.out.print("Enter Patient Gender (M/F/O): ");
        String gender = scanner.nextLine().toUpperCase(); // Normalize gender input
        System.out.print("Enter Patient Contact Number: ");
        String contactNumber = scanner.nextLine();

        // Validate inputs
        if (!isValidGender(gender)) {
            System.out.println("Invalid gender input. Please use 'M', 'F', or 'O'.");
            return;
        }

        String query = "INSERT INTO Patient (name, date_of_birth, gender, contact_number) VALUES (?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setDate(2, Date.valueOf(dateOfBirth));
            preparedStatement.setString(3, gender);
            preparedStatement.setString(4, contactNumber);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Patient Added Successfully!");
            } else {
                System.out.println("Failed to add Patient!");
            }
        } catch (SQLException e) {
            System.err.println("Error adding patient.");
            e.printStackTrace();
        }
    }

    public void viewPatients() {
        String query = "SELECT * FROM Patient";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            System.out.println("Patients: ");
            System.out.println("+------------+--------------------+----------------+--------+-----------------+");
            System.out.println("| Patient Id | Name               | Date of Birth  | Gender | Contact Number  |");
            System.out.println("+------------+--------------------+----------------+--------+-----------------+");
            while (resultSet.next()) {
                int patientId = resultSet.getInt("patient_id");
                String name = resultSet.getString("name");
                Date dateOfBirth = resultSet.getDate("date_of_birth");
                String gender = resultSet.getString("gender");
                String contactNumber = resultSet.getString("contact_number");
                System.out.printf("| %-10d | %-18s | %-14s | %-6s | %-15s |\n", patientId, name, dateOfBirth, gender, contactNumber);
                System.out.println("+------------+--------------------+----------------+--------+-----------------+");
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving patients.");
            e.printStackTrace();
        }
    }

    public boolean getPatientById(int id) {
        String query = "SELECT * FROM Patient WHERE patient_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next();  // Returns true if there is at least one row in the result set
            }
        } catch (SQLException e) {
            System.err.println("Error checking patient by ID.");
            e.printStackTrace();
        }
        return false;
    }

    private boolean isValidGender(String gender) {
        return gender.equals("M") || gender.equals("F") || gender.equals("O");
    }
}