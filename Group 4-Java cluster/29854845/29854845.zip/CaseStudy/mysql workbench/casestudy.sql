create database supplychain;
use supplychain;
create table product(
	product_id int primary key auto_increment,
    name varchar(40) not null,
    description text,
    price decimal(10,2) not null,
    quantity_in_stock int not null);
    
create table supplier(
	supplier_id int primary key auto_increment,
    name varchar(40) not null,
    email varchar(40) not null,
    phone_number int not null,
    address text not null);    
   
create table `order`(
	order_id int auto_increment primary key,    
	product_id int not null,
	supplier_id int not null,
	order_date date not null,
	delivery_date date,
	status enum('placed', 'delivered', 'cancelled') not null default 'placed',
	foreign key (product_id) references product(product_id),
	foreign key (supplier_id) references supplier(supplier_id));
