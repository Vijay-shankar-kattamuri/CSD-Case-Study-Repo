package casestudy;
import java.sql.*;
import java.util.Scanner;

public class Supplychain {
    private static final String url = "jdbc:mysql://localhost:3306/Supplychain";
    private static final String username = "root";
    private static final String password = "balaji12";

    private Connection conn;
    private Statement st;
    private PreparedStatement pst;
    private ResultSet rs;
    public void Createconnection(){
        try {
            conn = DriverManager.getConnection(url,username,password);
            st = conn.createStatement();
            if (conn == null) {
                System.err.println("Error connecting to database: Connection is null");
                System.exit(1);
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to database: " + e.getMessage());
            System.exit(1);
        }
    }
    public void displayMenu() {
        System.out.println("Inventory Management System");
        System.out.println("----------------------------");
        System.out.println("1. Manage Products");
        System.out.println("2. Manage Suppliers");
        System.out.println("3. Manage Orders");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }
    public void manageProducts() {
        System.out.println("Manage Products");
        System.out.println("--------------");
        System.out.println("1. Add Product");
        System.out.println("2. Update Product");
        System.out.println("3. Delete Product");
        System.out.println("4. Back to Main Menu");
        System.out.print("Enter your choice: ");

        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                addProduct();
                break;
            case 2:
                updateProduct();
                break;
            case 3:
                deleteProduct();
                break;
            case 4:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
                manageProducts();
        }
    }
    public void manageSuppliers() {
        System.out.println("Manage Suppliers");
        System.out.println("--------------");
        System.out.println("1. Add Supplier");
        System.out.println("2. Update Supplier");
        System.out.println("3. Delete Supplier");
        System.out.println("4. Back to Main Menu");
        System.out.print("Enter your choice: ");

        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                addSupplier();
                break;
            case 2:
                updateSupplier();
                break;
            case 3:
                deleteSupplier();
                break;
            case 4:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
                manageSuppliers();
        }
    }
    public void manageOrders() {
        System.out.println("Manage Orders");
        System.out.println("------------");
        System.out.println("1. Place Order");
        System.out.println("2. Cancel Order");
        System.out.println("3. View Orders");
        System.out.println("4. Back to Main Menu");
        System.out.print("Enter your choice: ");

        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                placeOrder();
                break;
            case 2:
                cancelOrder();
                break;
            case 3:
                viewOrders();
                break;
            case 4:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
                manageOrders();
        }
    }
    public void addProduct() {
        System.out.print("Enter product name: ");
        String name = new Scanner(System.in).nextLine();
        System.out.print("Enter product description: ");
        String description = new Scanner(System.in).nextLine();
        System.out.print("Enter product price: ");
        double price = new Scanner(System.in).nextDouble();
        System.out.print("Enter product quantity in stock: ");
        int quantityInStock = new Scanner(System.in).nextInt();

        try {
            pst = conn.prepareStatement("insert into Product (name, description, price, quantity_in_stock) values (?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, name);
            pst.setString(2, description);
            pst.setDouble(3, price);
            pst.setInt(4, quantityInStock);
            pst.executeUpdate();
            ResultSet rs = pst.getGeneratedKeys();
            if (rs.next()) {
                int productId = rs.getInt(1);
                System.out.println("Product added successfully! Product ID: " + productId);
            }
        } catch (SQLException e) {
            System.err.println("Error adding product: " + e.getMessage());
        }
    }
    public void updateProduct() {
        System.out.print("Enter product ID: ");
        int productId = new Scanner(System.in).nextInt();
        System.out.print("Enter new product name: ");
        String name = new Scanner(System.in).nextLine();
        System.out.print("Enter new product description: ");
        String description = new Scanner(System.in).nextLine();
        System.out.print("Enter new product price: ");
        double price = new Scanner(System.in).nextDouble();
        System.out.print("Enter new product quantity in stock: ");
        int quantityInStock = new Scanner(System.in).nextInt();

        try {
            pst = conn.prepareStatement("update product set name = ?, description = ?, price = ?, quantity_in_stock = ? where product_id = ?");
            pst.setString(1, name);
            pst.setString(2, description);
            pst.setDouble(3, price);
            pst.setInt(4, quantityInStock);
            pst.setInt(5, productId);
            pst.executeUpdate();
            System.out.println("Product updated successfully!");
        } catch (SQLException e) {
            System.err.println("Error updating product: " + e.getMessage());
        }
    }

    public void deleteProduct() {
        System.out.print("Enter product ID: ");
        int productId = new Scanner(System.in).nextInt();

        try {
            pst = conn.prepareStatement("delete from product where product_id = ?");
            pst.setInt(1, productId);
            pst.executeUpdate();
            System.out.println("Product deleted successfully!");
        } catch (SQLException e) {
            System.err.println("Error deleting product: " + e.getMessage());
        }
    }

    public void addSupplier() {
        System.out.print("Enter supplier name: ");
        String name = new Scanner(System.in).nextLine();
        System.out.print("Enter supplier email: ");
        String email = new Scanner(System.in).nextLine();
        System.out.print("Enter supplier phone number: ");
        String phoneNumber = new Scanner(System.in).nextLine();
        System.out.print("Enter supplier address: ");
        String address = new Scanner(System.in).nextLine();

        try {
            pst = conn.prepareStatement("insert into supplier (name, email, phone_number, address) values (?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, phoneNumber);
            pst.setString(4, address);
            pst.executeUpdate();
            ResultSet rs = pst.getGeneratedKeys();
            if (rs.next()) {
                int supplierId = rs.getInt(1);
                System.out.println("Supplier added successfully! Supplier ID: " + supplierId);
            }
        } catch (SQLException e) {
            System.err.println("Error adding supplier: " + e.getMessage());
        }
    }

    public void updateSupplier() {
        System.out.print("Enter supplier ID: ");
        int supplierId = new Scanner(System.in).nextInt();
        System.out.print("Enter new supplier name: ");
        String name = new Scanner(System.in).nextLine();
        System.out.print("Enter supplier email: ");
        String email = new Scanner(System.in).nextLine();
        System.out.print("Enter new supplier address: ");
        String address = new Scanner(System.in).nextLine();
        System.out.print("Enter new supplier phone number: ");
        String phoneNumber = new Scanner(System.in).nextLine();

        try {
            pst = conn.prepareStatement("update supplier set supplier_id = ?, name = ?,email = ?, phone_number = ?, address = ? WHERE supplier_id = ?");
            pst.setInt(1, supplierId);
            pst.setString(2, name);
            pst.setString(3, email);
            pst.setString(4, phoneNumber);
            pst.setString(5, address);
            pst.executeUpdate();
            System.out.println("Supplier updated successfully!");
        } catch (SQLException e) {
            System.err.println("Error updating supplier: " + e.getMessage());
        }
    }

    public void deleteSupplier() {
        System.out.print("Enter supplier ID: ");
        int supplierId = new Scanner(System.in).nextInt();

        try {
            pst = conn.prepareStatement("delete from supplier where supplier_id = ?");
            pst.setInt(1, supplierId);
            pst.executeUpdate();
            System.out.println("Supplier deleted successfully!");
        } catch (SQLException e) {
            System.err.println("Error deleting supplier: " + e.getMessage());
        }
    }

    public void placeOrder() {
        System.out.print("Enter product ID: ");
        int productId = new Scanner(System.in).nextInt();
        System.out.print("Enter supplier ID: ");
        int supplierId = new Scanner(System.in).nextInt();
        System.out.print("Enter quantity to order: ");
        int quantityToOrder = new Scanner(System.in).nextInt();

        try {
            rs = st.executeQuery("select quantity_in_stock from product where product_id = " + productId);
            if (rs.next()) {
                int quantityInStock = rs.getInt("quantity_in_stock");
                if (quantityInStock >= quantityToOrder) {
                    pst = conn.prepareStatement("insert into `order` (product_id, supplier_id, order_date, delivery_date, status) VALUES (?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
                    pst.setInt(1, productId);
                    pst.setInt(2, supplierId);
                    pst.setDate(3, new Date(System.currentTimeMillis()));
                    pst.setDate(4, new Date(System.currentTimeMillis() + 604800000)); // 7 days(1 week) from now
                    pst.setString(5, "placed");
                    pst.executeUpdate();
                    ResultSet rs2 = pst.getGeneratedKeys();
                    if (rs2.next()) {
                        int orderId = rs2.getInt(1);
                        System.out.println("Order placed successfully! Order ID: " + orderId);
                    }
                    pst = conn.prepareStatement("update product set quantity_in_stock =? where product_id =?");
                    pst.setInt(1, quantityInStock - quantityToOrder);
                    pst.setInt(2, productId);
                    pst.executeUpdate();
                } else {
                    System.out.println("Not enough stock available!");
                }
            } else {
                System.out.println("Product not found!");
            }
        } catch (SQLException e) {
            System.err.println("Error placing order: " + e.getMessage());
        }
    }

    public void cancelOrder() {
        System.out.print("Enter order ID: ");
        int orderId = new Scanner(System.in).nextInt();

        try {
            rs = st.executeQuery("select product_id from `order` where order_id = " + orderId);
            if (rs.next()) {
                int p_id = rs.getInt("product_id");
                pst = conn.prepareStatement("select quantity from `order` where order_id = ?");
                pst.setInt(1, orderId);
                rs = pst.executeQuery();
                if (rs.next()) {
                    int quantity = rs.getInt("quantity");
                    pst = conn.prepareStatement("update product set quantity_in_stock = quantity_in_stock + ? where product_id = ?");
                    pst.setInt(1, quantity);
                    pst.setInt(2, p_id);
                    pst.executeUpdate();
                    pst = conn.prepareStatement("update `order` set status = ? where order_id = ?");
                    pst.setString(1, "cancelled");
                    pst.setInt(2, orderId);
                    pst.executeUpdate();
                    System.out.println("Order cancelled successfully!");
                } else {
                    System.out.println("Order not found!");
                }
            } else {
                System.out.println("Order not found!");
            }
        } catch (SQLException e) {
            System.err.println("Error cancelling order: " + e.getMessage());
        }
    }

    public void viewOrders() {
        try {
            rs = st.executeQuery("select * from `order`");
            while (rs.next()) {
                int orderId = rs.getInt("order_id");
                int productId = rs.getInt("product_id");
                int supplierId = rs.getInt("supplier_id");
                Date orderDate = rs.getDate("order_date");
                Date deliveryDate = rs.getDate("delivery_date");
                String status = rs.getString("status");
                System.out.println("Order ID: " + orderId + ", Product ID: " + productId + ", Supplier ID: " + supplierId + ", Order Date: " + orderDate + ", Delivery Date: " + deliveryDate + ", Status: " + status);
            }
        } catch (SQLException e) {
            System.err.println("Error viewing orders: " + e.getMessage());
        }
    }
    public void closeConnection() {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing result set: " + e.getMessage());
        }

        try {
            if (pst != null) {
                pst.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing prepared statement: " + e.getMessage());
        }

        try {
            if (st != null) {
                st.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing statement: " + e.getMessage());
        }

        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
    public static void main(String[] args) {
        Supplychain obj1 = new Supplychain();
        obj1.Createconnection();
        Scanner scanner = new Scanner(System.in);

        try {
            while (true) {
                obj1.displayMenu();
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        obj1.manageProducts();
                        break;
                    case 2:
                        obj1.manageSuppliers();
                        break;
                    case 3:
                        obj1.manageOrders();
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        obj1.closeConnection();
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            obj1.closeConnection();
        }
    }
}
