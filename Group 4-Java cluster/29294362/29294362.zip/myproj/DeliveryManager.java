package myproj;

//DeliveryManager.java
import java.sql.*;
import java.util.Scanner;

public class DeliveryManager {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/courier_db";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Aj@20011291";

 public static void scheduleDelivery() {
     try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
          Scanner scanner = new Scanner(System.in)) {

         System.out.print("Enter parcel ID: ");
         int parcelId = scanner.nextInt();
         System.out.print("Enter customer ID: ");
         int customerId = scanner.nextInt();
         scanner.nextLine();  // Consume newline
         System.out.print("Enter delivery date (YYYY-MM-DD): ");
         String deliveryDate = scanner.nextLine();
         System.out.print("Enter delivery status: ");
         String deliveryStatus = scanner.nextLine();
         System.out.print("Enter delivery cost: ");
         double deliveryCost = scanner.nextDouble();

         String sql = "INSERT INTO Delivery (parcel_id, customer_id, delivery_date, delivery_status, delivery_cost) VALUES (?, ?, ?, ?, ?)";
         try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setInt(1, parcelId);
             pstmt.setInt(2, customerId);
             pstmt.setString(3, deliveryDate);
             pstmt.setString(4, deliveryStatus);
             pstmt.setDouble(5, deliveryCost);
             pstmt.executeUpdate();
             System.out.println("Delivery scheduled successfully.");
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
 }

 public static void updateDeliveryStatus() {
     try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
          Scanner scanner = new Scanner(System.in)) {

         System.out.print("Enter delivery ID: ");
         int deliveryId = scanner.nextInt();
         scanner.nextLine();  // Consume newline
         System.out.print("Enter new delivery status: ");
         String deliveryStatus = scanner.nextLine();

         String sql = "UPDATE Delivery SET delivery_status = ? WHERE delivery_id = ?";
         try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setString(1, deliveryStatus);
             pstmt.setInt(2, deliveryId);
             pstmt.executeUpdate();
             System.out.println("Delivery status updated successfully.");
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
 }

 public static void viewDeliveryHistory() {
     try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
          Scanner scanner = new Scanner(System.in)) {

         System.out.print("Enter customer ID: ");
         int customerId = scanner.nextInt();

         String sql = "SELECT * FROM Delivery WHERE customer_id = ?";
         try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setInt(1, customerId);
             ResultSet rs = pstmt.executeQuery();
             while (rs.next()) {
                 System.out.println("Delivery ID: " + rs.getInt("delivery_id"));
                 System.out.println("Parcel ID: " + rs.getInt("parcel_id"));
                 System.out.println("Customer ID: " + rs.getInt("customer_id"));
                 System.out.println("Delivery Date: " + rs.getString("delivery_date"));
                 System.out.println("Delivery Status: " + rs.getString("delivery_status"));
                 System.out.println("Delivery Cost: " + rs.getDouble("delivery_cost"));
             }
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
 }

 public static void calculateDeliveryCosts() {
     try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
          Scanner scanner = new Scanner(System.in)) {

         System.out.print("Enter customer ID: ");
         int customerId = scanner.nextInt();

         String sql = "SELECT SUM(delivery_cost) AS total_cost FROM Delivery WHERE customer_id = ?";
         try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setInt(1, customerId);
             ResultSet rs = pstmt.executeQuery();
             if (rs.next()) {
                 System.out.println("Total Delivery Cost: " + rs.getDouble("total_cost"));
             }
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
 }
}

