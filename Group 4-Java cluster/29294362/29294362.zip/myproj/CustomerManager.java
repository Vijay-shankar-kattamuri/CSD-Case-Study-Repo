package myproj;

//CustomerManager.java
import java.sql.*;
import java.util.Scanner;

public class CustomerManager {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/courier_db";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Aj@20011291";
 public static void registerCustomer() {
     try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
          Scanner scanner = new Scanner(System.in)) {

         System.out.print("Enter customer name: ");
         String customerName = scanner.nextLine();
         System.out.print("Enter email: ");
         String email = scanner.nextLine();
         System.out.print("Enter phone number: ");
         String phoneNumber = scanner.nextLine();

         String sql = "INSERT INTO Customer (customer_name, email, phone_number) VALUES (?, ?, ?)";
         try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setString(1, customerName);
             pstmt.setString(2, email);
             pstmt.setString(3, phoneNumber);
             pstmt.executeUpdate();
             System.out.println("Customer registered successfully.");
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
 }

 public static void viewCustomer() {
     try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
          Scanner scanner = new Scanner(System.in)) {

         System.out.print("Enter customer ID: ");
         int customerId = scanner.nextInt();

         String sql = "SELECT * FROM Customer WHERE customer_id = ?";
         try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setInt(1, customerId);
             ResultSet rs = pstmt.executeQuery();
             while (rs.next()) {
                 System.out.println("Customer ID: " + rs.getInt("customer_id"));
                 System.out.println("Customer Name: " + rs.getString("customer_name"));
                 System.out.println("Email: " + rs.getString("email"));
                 System.out.println("Phone Number: " + rs.getString("phone_number"));
             }
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
 }

 public static void updateCustomer() {
     try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
          Scanner scanner = new Scanner(System.in)) {

         System.out.print("Enter customer ID: ");
         int customerId = scanner.nextInt();
         scanner.nextLine();  // Consume newline
         System.out.print("Enter new customer name: ");
         String customerName = scanner.nextLine();
         System.out.print("Enter new email: ");
         String email = scanner.nextLine();
         System.out.print("Enter new phone number: ");
         String phoneNumber = scanner.nextLine();

         String sql = "UPDATE Customer SET customer_name = ?, email = ?, phone_number = ? WHERE customer_id = ?";
         try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setString(1, customerName);
             pstmt.setString(2, email);
             pstmt.setString(3, phoneNumber);
             pstmt.setInt(4, customerId);
             pstmt.executeUpdate();
             System.out.println("Customer updated successfully.");
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
 }

 public static void deleteCustomer() {
     try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
          Scanner scanner = new Scanner(System.in)) {

         System.out.print("Enter customer ID: ");
         int customerId = scanner.nextInt();

         String sql = "DELETE FROM Customer WHERE customer_id = ?";
         try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setInt(1, customerId);
             pstmt.executeUpdate();
             System.out.println("Customer deleted successfully.");
         }
     } catch (SQLException e) {
         e.printStackTrace();
     }
 }
}

