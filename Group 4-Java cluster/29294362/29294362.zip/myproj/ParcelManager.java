package myproj;

import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ParcelManager {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/courier_db";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Aj@20011291";
	public static void addParcel() {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
    
            System.out.print("Enter sender name: ");
            String senderName = scanner.nextLine();
            System.out.print("Enter sender address: ");
            String senderAddress = scanner.nextLine();
            System.out.print("Enter recipient name: ");
            String recipientName = scanner.nextLine();
            System.out.print("Enter recipient address: ");
            String recipientAddress = scanner.nextLine();
            System.out.print("Enter weight: ");
            while (!scanner.hasNextDouble()) {
                System.out.println("Invalid input. Please enter a numeric value for weight.");
                scanner.next(); // Clear the invalid input
            }
            double weight = scanner.nextDouble();
            scanner.nextLine();  // Consume newline
            System.out.print("Enter status: ");
            String status = scanner.nextLine();
    
            String sql = "INSERT INTO Parcel (sender_name, sender_address, recipient_name, recipient_address, weight, status) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, senderName);
                pstmt.setString(2, senderAddress);
                pstmt.setString(3, recipientName);
                pstmt.setString(4, recipientAddress);
                pstmt.setDouble(5, weight);
                pstmt.setString(6, status);
                pstmt.executeUpdate();
                System.out.println("Parcel added successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

    public static void viewParcel() {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter parcel ID: ");
            int parcelId = scanner.nextInt();

            String sql = "SELECT * FROM Parcel WHERE parcel_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, parcelId);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    System.out.println("Parcel ID: " + rs.getInt("parcel_id"));
                    System.out.println("Sender Name: " + rs.getString("sender_name"));
                    System.out.println("Sender Address: " + rs.getString("sender_address"));
                    System.out.println("Recipient Name: " + rs.getString("recipient_name"));
                    System.out.println("Recipient Address: " + rs.getString("recipient_address"));
                    System.out.println("Weight: " + rs.getDouble("weight"));
                    System.out.println("Status: " + rs.getString("status"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateParcel() {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter parcel ID: ");
            int parcelId = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            System.out.print("Enter new sender name: ");
            String senderName = scanner.nextLine();
            System.out.print("Enter new sender address: ");
            String senderAddress = scanner.nextLine();
            System.out.print("Enter new recipient name: ");
            String recipientName = scanner.nextLine();
            System.out.print("Enter new recipient address: ");
            String recipientAddress = scanner.nextLine();
            System.out.print("Enter new weight: ");
            double weight = scanner.nextDouble();
            scanner.nextLine();  // Consume newline
            System.out.print("Enter new status: ");
            String status = scanner.nextLine();

            String sql = "UPDATE Parcel SET sender_name = ?, sender_address = ?, recipient_name = ?, recipient_address = ?, weight = ?, status = ? WHERE parcel_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, senderName);
                pstmt.setString(2, senderAddress);
                pstmt.setString(3, recipientName);
                pstmt.setString(4, recipientAddress);
                pstmt.setDouble(5, weight);
                pstmt.setString(6, status);
                pstmt.setInt(7, parcelId);
                pstmt.executeUpdate();
                System.out.println("Parcel updated successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
