package myproj;

import java.util.Scanner;

public class Myapplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("Courier Service Management System");
            System.out.println("1. Parcel Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Delivery Operations");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        parcelManagementMenu(scanner);
                        break;
                    case 2:
                        customerManagementMenu(scanner);
                        break;
                    case 3:
                        deliveryOperationsMenu(scanner);
                        break;
                    case 4:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Consume the invalid input
            }
        }
        scanner.close();
    }

    private static void parcelManagementMenu(Scanner scanner) {
        boolean exit = false;
    
        while (!exit) {
            System.out.println("Parcel Management");
            System.out.println("1. Add New Parcel");
            System.out.println("2. View Parcel Details");
            System.out.println("3. Update Parcel Information");
            System.out.println("4. Delete Parcel");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Consume the invalid input
            }
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            switch (choice) {
                case 1:
                    ParcelManager.addParcel();
                    break;
                case 2:
                    ParcelManager.viewParcel();
                    break;
                case 3:
                    ParcelManager.updateParcel();
                    break;
                case 4:
                    // Note: The switch case for deletion (4) should be marked as such,
                    // it looks like you meant to exit the menu instead of deleting a parcel.
                    // So if it's meant to delete, add a break here, otherwise, it's fine to exit the menu.
                    ParcelManager.updateParcel();
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    

    private static void customerManagementMenu(Scanner scanner) {
        boolean exit = false;

        while (!exit) {
            System.out.println("Customer Management");
            System.out.println("1. Register New Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer Information");
            System.out.println("4. Delete Customer Account");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        CustomerManager.registerCustomer();
                        break;
                    case 2:
                        CustomerManager.viewCustomer();
                        break;
                    case 3:
                        CustomerManager.updateCustomer();
                        break;
                    case 4:
                        CustomerManager.deleteCustomer();
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Consume the invalid input
            }
        }
    }

    private static void deliveryOperationsMenu(Scanner scanner) {
        boolean exit = false;

        while (!exit) {
            System.out.println("Delivery Operations");
            System.out.println("1. Schedule Parcel Delivery");
            System.out.println("2. Update Delivery Status");
            System.out.println("3. View Delivery History");
            System.out.println("4. Calculate Delivery Costs");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        DeliveryManager.scheduleDelivery();
                        break;
                    case 2:
                        DeliveryManager.updateDeliveryStatus();
                        break;
                    case 3:
                        DeliveryManager.viewDeliveryHistory();
                        break;
                    case 4:
                        DeliveryManager.calculateDeliveryCosts();
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Consume the invalid input
            }
        }
    }
}
