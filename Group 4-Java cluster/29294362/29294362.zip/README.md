<h1>Courier Service Management System</h1>

<p>This project is a menu-based console application developed in Core Java. It simulates a courier service management system, allowing users to manage parcels, customers, and delivery operations. The application interacts with a MySQL database using JDBC.</p>

<h2>Features</h2>
<ul>
    <li><strong>Parcel Management</strong>
        <ul>
            <li>Add new parcels for delivery</li>
            <li>View parcel details</li>
            <li>Update parcel information</li>
            <li>Delete parcels</li>
        </ul>
    </li>
    <li><strong>Customer Management</strong>
        <ul>
            <li>Register new customers</li>
            <li>View customer details</li>
            <li>Update customer information</li>
            <li>Delete customer accounts</li>
        </ul>
    </li>
    <li><strong>Delivery Operations</strong>
        <ul>
            <li>Schedule parcel deliveries</li>
            <li>Update delivery status</li>
            <li>View delivery history</li>
            <li>Calculate delivery costs</li>
        </ul>
    </li>
</ul>

<h2>Database Schema</h2>

<h3>Parcel Table</h3>
<ul>
    <li>parcel_id (Primary Key)</li>
    <li>sender_name</li>
    <li>sender_address</li>
    <li>recipient_name</li>
    <li>recipient_address</li>
    <li>weight</li>
    <li>status (Scheduled, In Transit, Delivered)</li>
</ul>

<h3>Customer Table</h3>
<ul>
    <li>customer_id (Primary Key)</li>
    <li>customer_name</li>
    <li>email</li>
    <li>phone_number</li>
</ul>

<h3>Delivery Table</h3>
<ul>
    <li>delivery_id (Primary Key)</li>
    <li>parcel_id (Foreign Key references Parcel Table)</li>
    <li>customer_id (Foreign Key references Customer Table)</li>
    <li>delivery_date</li>
    <li>delivery_status</li>
    <li>delivery_cost</li>
</ul>

<h2>Setup and Usage Instructions</h2>

<h3>Prerequisites</h3>
<ul>
    <li>Java Development Kit (JDK) installed</li>
    <li>MySQL Database installed</li>
    <li>MySQL Connector/J (JDBC Driver for MySQL) added to the project</li>
</ul>

<h3>Database Setup</h3>
<ol>
    <li>Create a database named <code>courier_service</code> in MySQL.</li>
    <li>Create the necessary tables using the following SQL commands:
        <pre>
CREATE DATABASE courier_service;

USE courier_service;

CREATE TABLE Parcel (
    parcel_id INT AUTO_INCREMENT PRIMARY KEY,
    sender_name VARCHAR(255),
    sender_address VARCHAR(255),
    recipient_name VARCHAR(255),
    recipient_address VARCHAR(255),
    weight DOUBLE,
    status VARCHAR(50)
);

CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255),
    email VARCHAR(255),
    phone_number VARCHAR(20)
);

CREATE TABLE Delivery (
    delivery_id INT AUTO_INCREMENT PRIMARY KEY,
    parcel_id INT,
    customer_id INT,
    delivery_date DATE,
    delivery_status VARCHAR(50),
    delivery_cost DOUBLE,
    FOREIGN KEY (parcel_id) REFERENCES Parcel(parcel_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);
        </pre>
    </li>
</ol>

<h3>Application Setup</h3>
<ol>
    <li>Clone the repository from GitHub:
        <pre>git clone https://github.com/your-username/courier-service-management.git</pre>
    </li>
    <li>Navigate to the project directory:
        <pre>cd courier-service-management</pre>
    </li>
    <li>Open the project in your preferred Java IDE (e.g., IntelliJ IDEA, Eclipse).</li>
    <li>Ensure that the MySQL Connector/J library is added to the project's build path.</li>
    <li>Update the <code>JDBC_URL</code>, <code>JDBC_USER</code>, and <code>JDBC_PASSWORD</code> constants in the <code>ParcelManager</code>, <code>CustomerManager</code>, and <code>DeliveryManager</code> classes with your MySQL database connection details.</li>
</ol>

<h3>Running the Application</h3>
<ol>
    <li>Compile and run the <code>Myapplication</code> class:
        <pre>
javac myproj/Myapplication.java
java myproj.Myapplication
        </pre>
    </li>
    <li>Follow the on-screen instructions to navigate through the menu options and manage parcels, customers, and delivery operations.</li>
</ol>

<h2>Exception Handling</h2>
<p>The application handles various exceptions to provide user-friendly error messages and ensure smooth execution. Common exceptions handled include:</p>
<ul>
    <li><code>SQLException</code> for database-related errors</li>
    <li><code>InputMismatchException</code> for invalid user inputs</li>
</ul>

<h2>Code Conventions</h2>
<p>The code follows standard Java coding conventions for readability and maintainability. Proper documentation is provided for classes and methods.</p>
