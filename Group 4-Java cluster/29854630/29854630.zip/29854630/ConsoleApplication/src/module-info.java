/**
 * 
 */
/**
 * 
 */
module ConsoleApplication {
	requires java.sql;
}