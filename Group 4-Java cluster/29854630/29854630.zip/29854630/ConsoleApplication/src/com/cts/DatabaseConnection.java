/*
 * MySql Database Connection what we already designed. 
 */

//package declaration
package com.cts;

//import statements
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DatabaseConnection {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/healthinsurance_db";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Prabhudev@123";

    //object connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
    }
    
}//closing of class

