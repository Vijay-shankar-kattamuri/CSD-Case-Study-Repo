/*
 * First feature of HealthInsuranceManagementSystem is PolicyManagement implementation
 */

//package declaration
package com.cts;

//import statements
import java.sql.*;
import java.util.Scanner;

//PolicyManagement class creation
public class PolicyManagement {
    public static void policyManagement(Scanner scanner, Connection connection) {
        System.out.println("Policy Management");
        System.out.println("1. Add a new policy");
        System.out.println("2. View policy details");
        System.out.println("3. Update policy information");
        System.out.println("4. Delete a policy");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                addNewPolicy(scanner, connection);
                break;
            case 2:
                viewPolicyDetails(scanner, connection);
                break;
            case 3:
                updatePolicyInformation(scanner, connection);
                break;
            case 4:
                deletePolicy(scanner, connection);
                break;
            default:
                System.out.println("Invalid choice...");
        }
    }
    
    //addNewPolicy method
    private static void addNewPolicy(Scanner scanner, Connection connection) {
    	
    	//creating Prepared statement
        try (PreparedStatement ps = connection.prepareStatement("INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)")) {
            
        	System.out.print("Enter policy number: ");
            String policyNumber = scanner.nextLine();
            System.out.print("Enter policy type: ");
            String type = scanner.nextLine();
            System.out.print("Enter coverage amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter premium amount: ");
            double premiumAmount = scanner.nextDouble();
            scanner.nextLine();

            ps.setString(1, policyNumber);
            ps.setString(2, type);
            ps.setDouble(3, coverageAmount);
            ps.setDouble(4, premiumAmount);
            
            //execute statement
            int rowsAffected = ps.executeUpdate();
            
            //status of addNewPolicy
            if (rowsAffected > 0) {
                System.out.println("Policy added successfully.");
            } else {
                System.out.println("Failed to add policy.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing AddnewPolicy method
    
    //viewPolicyDetails method
    private static void viewPolicyDetails(Scanner scanner, Connection connection) {
        System.out.print("Enter policy ID to view: ");
        int policyId = scanner.nextInt();
        scanner.nextLine();
        
        //creation of PreaparedStatement
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM Policy WHERE policy_id = ?")) {
            ps.setInt(1, policyId);
            
            //Execute the statement
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Policy ID: " + rs.getInt("policy_id"));
                System.out.println("Policy Number: " + rs.getString("policy_number"));
                System.out.println("Type: " + rs.getString("type"));
                System.out.println("Coverage Amount: " + rs.getDouble("coverage_amount"));
                System.out.println("Premium Amount: " + rs.getDouble("premium_amount"));
            } else {
                System.out.println("Policy not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing viewPolicyDetails method

    //UpdatePolicyinformation method
    private static void updatePolicyInformation(Scanner scanner, Connection connection) {
        System.out.print("Enter policy ID to update: ");
        int policyId = scanner.nextInt();
        scanner.nextLine();

        //create PreparedStatement
        try (PreparedStatement ps = connection.prepareStatement("UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?")) {
            System.out.print("Enter new policy number: ");
            String policyNumber = scanner.nextLine();
            System.out.print("Enter new policy type: ");
            String type = scanner.nextLine();
            System.out.print("Enter new coverage amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter new premium amount: ");
            double premiumAmount = scanner.nextDouble();
            scanner.nextLine();  // takes newline

            //updating policyinformation
            ps.setString(1, policyNumber);
            ps.setString(2, type);
            ps.setDouble(3, coverageAmount);
            ps.setDouble(4, premiumAmount);
            ps.setInt(5, policyId);
            
            //ExecuteStatement
            int rowsAffected = ps.executeUpdate();
            
            //status of update
            if (rowsAffected > 0) {
                System.out.println("Policy updated successfully.");
            } else {
                System.out.println("Failed to update policy.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing UpdatePolicy method

    //deletePolicy method
    private static void deletePolicy(Scanner scanner, Connection connection) {
        System.out.print("Enter policy ID to delete: ");
        int policyId = scanner.nextInt();
        scanner.nextLine();  // takes newline

        //creating Prepared Statement
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM Policy WHERE policy_id = ?")) {
            ps.setInt(1, policyId);

            //ExecuteStatement
            int rowsAffected = ps.executeUpdate();
            
            //Policy status
            if (rowsAffected > 0) {
                System.out.println("Policy deleted successfully.");
            } else {
                System.out.println("Failed to delete policy.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//delete policy method
}//closing class
