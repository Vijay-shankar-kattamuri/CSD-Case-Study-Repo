/*
 * A menu-based console application that having functionalities like Manage Policies, Members, and Claims 
 */

//package declaration
package com.cts;

//import statements that are needed
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;


//InsuranceManagementSystem class declaration
public class InsuranceManagementSystem {
    private static Connection connection;

    public static void main(String[] args) {
        try {
        	//connection to the database
            connection = DatabaseConnection.getConnection();
            displayMenu();//display when connection is successful
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }//closing of main method
    
    //displayMenu method is to display InsuranceManagementSystem Functionalities
    private static void displayMenu() {
    	//Scanner object creation is to read the input from the user
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Insurance Management System");
            System.out.println("1. Policy Management");
            System.out.println("2. Member Management");
            System.out.println("3. Claim Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    PolicyManagement.policyManagement(scanner, connection);
                    break;
                case 2:
                    MemberManagement.memberManagement(scanner, connection);
                    break;
                case 3:
                    ClaimManagement.claimManagement(scanner, connection);
                    break;
                case 4:
                    System.out.println("Exiting the Menu...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }//closing of while
    }//closing of method
}//closing of the class
