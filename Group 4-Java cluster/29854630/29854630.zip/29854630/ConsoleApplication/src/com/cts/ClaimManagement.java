/*
 * Third feature of HealthInsuranceManagementSystem ClaimManagement implementation
 */

//package declaration
package com.cts;

//import statements
import java.sql.*;
import java.util.Scanner;

//ClaimManagement class creation
public class ClaimManagement {
    public static void claimManagement(Scanner scanner, Connection connection) {
        System.out.println("Claim Management");
        System.out.println("1. Submit a new claim");
        System.out.println("2. View claim details");
        System.out.println("3. Update claim information");
        System.out.println("4. Delete a claim");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                submitNewClaim(scanner, connection);
                break;
            case 2:
                viewClaimDetails(scanner, connection);
                break;
            case 3:
                updateClaimInformation(scanner, connection);
                break;
            case 4:
                deleteClaim(scanner, connection);
                break;
            default:
                System.out.println("Invalid choice...");
        }
    }

    //SubmitnewClaim method
    private static void submitNewClaim(Scanner scanner, Connection connection) {
    	//creating PreparedStatement
        try (PreparedStatement ps = connection.prepareStatement("INSERT INTO Claim (policy_id, member_id, claim_date, status) VALUES (?, ?, ?, ?)")) {
            System.out.print("Enter policy ID: ");
            int policyId = scanner.nextInt();
            System.out.print("Enter member ID: ");
            int memberId = scanner.nextInt();
            scanner.nextLine();  // takes newline
            System.out.print("Enter claim date (YYYY-MM-DD): ");
            String claimDate = scanner.nextLine();
            System.out.print("Enter claim status (submitted/processed): ");
            String status = scanner.nextLine();

            ps.setInt(1, policyId);
            ps.setInt(2, memberId);
            ps.setDate(3, Date.valueOf(claimDate));
            ps.setString(4, status);

            //ExecuteStatement
            int rowsAffected = ps.executeUpdate();
            
            //status of submit claim
            if (rowsAffected > 0) {
                System.out.println("Claim submitted successfully.");
            } else {
                System.out.println("Failed to submit claim.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing submitnewclaim

    //viewClaimDetails method
    private static void viewClaimDetails(Scanner scanner, Connection connection) {
        System.out.print("Enter claim ID to view: ");
        int claimId = scanner.nextInt();
        scanner.nextLine();  // takes newline

        //creating Prepared Statement
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM Claim WHERE claim_id = ?")) {
            ps.setInt(1, claimId);
            //Execute Statement
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Claim ID: " + rs.getInt("claim_id"));
                System.out.println("Policy ID: " + rs.getInt("policy_id"));
                System.out.println("Member ID: " + rs.getInt("member_id"));
                System.out.println("Claim Date: " + rs.getDate("claim_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Claim not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing viewclaimDetails method

    //updateClaimInformation method
    private static void updateClaimInformation(Scanner scanner, Connection connection) {
        System.out.print("Enter claim ID to update: ");
        int claimId = scanner.nextInt();
        scanner.nextLine();  // takes newline

        //creating PreapredStatement
        try (PreparedStatement ps = connection.prepareStatement("UPDATE Claim SET policy_id = ?, member_id = ?, claim_date = ?, status = ? WHERE claim_id = ?")) {
            System.out.print("Enter new policy ID: ");
            int policyId = scanner.nextInt();
            System.out.print("Enter new member ID: ");
            int memberId = scanner.nextInt();
            scanner.nextLine();  // takes newline
            System.out.print("Enter new claim date (YYYY-MM-DD): ");
            String claimDate = scanner.nextLine();
            System.out.print("Enter new claim status (submitted/processed): ");
            String status = scanner.nextLine();

            ps.setInt(1, policyId);
            ps.setInt(2, memberId);
            ps.setDate(3, Date.valueOf(claimDate));
            ps.setString(4, status);
            ps.setInt(5, claimId);

            //ExecuteStatement
            int rowsAffected = ps.executeUpdate();
            //status of updateClaiminformation
            if (rowsAffected > 0) {
                System.out.println("Claim information updated successfully.");
            } else {
                System.out.println("Failed to update claim information.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing updateClaimInformation

    //deleteClaim method
    private static void deleteClaim(Scanner scanner, Connection connection) {
        System.out.print("Enter claim ID to delete: ");
        int claimId = scanner.nextInt();
        scanner.nextLine();  // takes newline
        
        //creating PreparedStatement
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM Claim WHERE claim_id = ?")) {
            ps.setInt(1, claimId);

            //ExecuteStatement
            int rowsAffected = ps.executeUpdate();
            //Status of delete Claim
            if (rowsAffected > 0) {
                System.out.println("Claim deleted successfully.");
            } else {
                System.out.println("Failed to delete claim.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing deleteClaim method
}//closing ClaimManagement class

