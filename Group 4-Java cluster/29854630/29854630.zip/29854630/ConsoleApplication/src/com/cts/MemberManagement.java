/*
 * Second feature of HealthInsuranceManagementSystem MemberManagement implementation
 * Pattern is used to create matcher object that can match character sequences 
 */

//package declaration
package com.cts;

//import statements
import java.sql.*;
import java.util.Scanner;
import java.util.regex.Pattern;

//MemberManagement class creation
public class MemberManagement {
	//mail pattern contains the caps,small,numbers,underscore
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    //phone number contains integers from 0 to 9 and contains 10 digits
    private static final Pattern PHONE_PATTERN = Pattern.compile(
            "^[0-9]{10}$");

    public static void memberManagement(Scanner scanner, Connection connection) {
        System.out.println("Member Management");
        System.out.println("1. Register a new member");
        System.out.println("2. View member details");
        System.out.println("3. Update member information");
        System.out.println("4. Delete a member");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // takes newline

        switch (choice) {
            case 1:
                registerNewMember(scanner, connection);
                break;
            case 2:
                viewMemberDetails(scanner, connection);
                break;
            case 3:
                updateMemberInformation(scanner, connection);
                break;
            case 4:
                deleteMember(scanner, connection);
                break;
            default:
                System.out.println("Invalid choice...");
        }
    }

    //registerNewMember method
    private static void registerNewMember(Scanner scanner, Connection connection) {
    	
    	//create PreparedStatement
        try (PreparedStatement ps = connection.prepareStatement("INSERT INTO Member (name, date_of_birth, email, phone_number) VALUES (?, ?, ?, ?)")) {
            
        	System.out.print("Enter member name: ");
            String name = scanner.nextLine();
            //validations checks for name
            if (name.isEmpty()) {
                System.out.println("Name cannot be empty.");
                return;
            }
            
            System.out.print("Enter date of birth (YYYY-MM-DD): ");
            String dob = scanner.nextLine();
            //validation check for date of birth
            if (!isValidDate(dob)) {
                System.out.println("Invalid date format. Please use YYYY-MM-DD.");
                return;
            }

            System.out.print("Enter email: ");
            String email = scanner.nextLine();
            //validation check for email
            if (!EMAIL_PATTERN.matcher(email).matches()) {
                System.out.println("Invalid email format.");
                return;
            }

            System.out.print("Enter phone number: ");
            String phoneNumber = scanner.nextLine();
            //validation checks for phone number
            if (!PHONE_PATTERN.matcher(phoneNumber).matches()) {
                System.out.println("Invalid phone number format.It Must be 10 digits.");
                return;
            }

            ps.setString(1, name);
            ps.setDate(2, Date.valueOf(dob));
            ps.setString(3, email);
            ps.setString(4, phoneNumber);

            //ExecuteStatement
            int rowsAffected = ps.executeUpdate();
            
            //update on member register
            if (rowsAffected > 0) {
                System.out.println("Member registered successfully.");
            } else {
                System.out.println("Failed to register member.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing registerNewMember method

    //viewMemberdetails method
    private static void viewMemberDetails(Scanner scanner, Connection connection) {
        System.out.print("Enter member ID to view: ");
        int memberId = scanner.nextInt();
        scanner.nextLine();  // takes newline

        //create PreparedStatement
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM Member WHERE member_id = ?")) {
            ps.setInt(1, memberId);
            //ExecuteStatement
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Member ID: " + rs.getInt("member_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Date of Birth: " + rs.getDate("date_of_birth"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
            } else {
                System.out.println("Member not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing viewMemberdetails method

    //updateMember method
    private static void updateMemberInformation(Scanner scanner, Connection connection) {
        System.out.print("Enter member ID to update: ");
        int memberId = scanner.nextInt();
        scanner.nextLine();  // takes newline

        //create PreparedStatement
        try (PreparedStatement ps = connection.prepareStatement("UPDATE Member SET name = ?, date_of_birth = ?, email = ?, phone_number = ? WHERE member_id = ?")) {
            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            //validation check
            if (name.isEmpty()) {
                System.out.println("Name cannot be empty.");
                return;
            }

            System.out.print("Enter new date of birth (YYYY-MM-DD): ");
            String dob = scanner.nextLine();
            //validation check
            if (!isValidDate(dob)) {
                System.out.println("Invalid date format. Please use YYYY-MM-DD.");
                return;
            }

            System.out.print("Enter new email: ");
            String email = scanner.nextLine();
            //validation check
            if (!EMAIL_PATTERN.matcher(email).matches()) {
                System.out.println("Invalid email format.");
                return;
            }

            System.out.print("Enter new phone number: ");
            String phoneNumber = scanner.nextLine();
            //validation check
            if (!PHONE_PATTERN.matcher(phoneNumber).matches()) {
                System.out.println("Invalid phone number format. It Must be 10 digits.");
                return;
            }

            ps.setString(1, name);
            ps.setDate(2, Date.valueOf(dob));
            ps.setString(3, email);
            ps.setString(4, phoneNumber);
            ps.setInt(5, memberId);

            //Execute the Statement
            int rowsAffected = ps.executeUpdate();
            //status of updateMember
            if (rowsAffected > 0) {
                System.out.println("Member information updated successfully.");
            } else {
                System.out.println("Failed to update member information.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing UpdateMember method

    //deleteMember method
    private static void deleteMember(Scanner scanner, Connection connection) {
        System.out.print("Enter member ID to delete: ");
        int memberId = scanner.nextInt();
        scanner.nextLine();  // takes newline

        //create PreparedStatement
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM Member WHERE member_id = ?")) {
            ps.setInt(1, memberId);

            //Execute Statement
            int rowsAffected = ps.executeUpdate();
            
            //status of member delete
            if (rowsAffected > 0) {
                System.out.println("Member deleted successfully.");
            } else {
                System.out.println("Failed to delete member.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//closing deleteMember
    
    //validation for date
    private static boolean isValidDate(String date) {
        try {
            Date.valueOf(date);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}


