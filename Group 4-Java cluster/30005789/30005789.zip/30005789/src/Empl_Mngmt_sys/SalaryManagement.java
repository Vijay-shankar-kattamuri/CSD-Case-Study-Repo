package Empl_Mngmt_sys;
import java.sql.*;
import java.sql.Date;
import java.sql.Time;

import java.util.*;
public class SalaryManagement {
 
    public static void setSalary() {
        try{
        	Connection conn = DatabaseConnection.getConnection();
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter employee ID: ");
            int employeeId = sc.nextInt();
            System.out.print("Enter salary amount: ");
            double salaryAmount = sc.nextDouble();
            System.out.print("Enter payment date: ");
            String paymentDate = sc.next();

            String query = "INSERT INTO Salary (employee_id, salary_amount, payment_date) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, employeeId);
                pstmt.setDouble(2, salaryAmount);
                pstmt.setDate(3, Date.valueOf(paymentDate));
                pstmt.executeUpdate();
                System.out.println("Salary set successfully.");
           
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
}
    public static void viewSalary() 
    {
        try {
        	Connection conn = DatabaseConnection.getConnection();
             Scanner sc = new Scanner(System.in); 

            System.out.print("Enter salary ID: ");
            int salaryId = sc.nextInt();

            String query = "select * from Salary where salary_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, salaryId);
            ResultSet rs = pstmt.executeQuery(); 
              if (rs.next()) {
                        System.out.println("Salary ID: " + rs.getInt("salary_id"));
                        System.out.println("Employee ID: " + rs.getInt("employee_id"));
                        System.out.println("Salary Amount: " + rs.getDouble("salary_amount"));
                        System.out.println("Payment Date: " + rs.getDate("payment_date"));
              } else {
                        System.out.println("Salary not found.");
                    }
    }    
         catch (SQLException e) {
            e.printStackTrace();
        }
} 
    
    
    public static void updateSalary() {
        try {
            Connection conn = DatabaseConnection.getConnection();
             Scanner sc = new Scanner(System.in);

            System.out.print("Enter salary ID: ");
            int salaryId = sc.nextInt();
            System.out.print("Enter new employee ID: ");
            int employeeId = sc.nextInt();
            System.out.print("Enter new salary amount: ");
            double salaryAmount = sc.nextDouble();
            System.out.print("Enter new payment date (YYYY-MM-DD): ");
            String paymentDate = sc.next();

            String query = "update Salary set employee_id = ?, salary_amount = ?, payment_date = ? where salary_id = ?";
             PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, employeeId);
                pstmt.setDouble(2, salaryAmount);
                pstmt.setDate(3, Date.valueOf(paymentDate));
                pstmt.setInt(4, salaryId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Salary updated successfully.");
                } else {
                    System.out.println("Salary not found.");
                }
            }

         catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void deleteSalary() {
        try {
        	Connection conn = DatabaseConnection.getConnection();
             Scanner sc = new Scanner(System.in);

            System.out.print("Enter salary ID: ");
            int salaryId = sc.nextInt();

            String query = "delete from Salary where salary_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, salaryId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Salary deleted successfully.");
                } else {
                    System.out.println("Salary not found.");
                }
            }

         catch (SQLException e) {
            e.printStackTrace();
        }
    }
 /*   public static void main(String []args) {
		//setSalary();
		//viewSalary();
    	//updateSalary();
		deleteSalary();
		}    */
}