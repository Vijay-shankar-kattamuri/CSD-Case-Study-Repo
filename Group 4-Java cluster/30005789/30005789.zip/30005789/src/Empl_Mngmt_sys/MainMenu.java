package Empl_Mngmt_sys;
import java.util.*;
public class MainMenu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Employee Management System ---");
            System.out.println("1. Add a new employee");
            System.out.println("2. View employee details");
            System.out.println("3. Update employee information");
            System.out.println("4. Delete an employee");
            System.out.println("5. Assign a shift to an employee");
            System.out.println("6. View shift details");
            System.out.println("7. Update shift information");
            System.out.println("8. Delete a shift");
            System.out.println("9. Set a salary for an employee");
            System.out.println("10. View salary details");
            System.out.println("11. Update salary information");
            System.out.println("12. Delete a salary record");
            System.out.println("13. Exit");
            System.out.println();
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

	        switch (choice) {
            case 1:
                EmployeeManagement.addEmployee();
                break;
            case 2:
                EmployeeManagement.viewEmployee();
                break;
            case 3:
                EmployeeManagement.updateEmployee();
                break;
            case 4:
                EmployeeManagement.deleteEmployee();
                break;
            case 5:
                ShiftManagement.assignShift();
                break;
            case 6:
                ShiftManagement.viewShift();
                break;
            case 7:
                ShiftManagement.updateShift();
                break;
            case 8:
                ShiftManagement.deleteShift();
                break;
            case 9:
                SalaryManagement.setSalary();
                break;
            case 10:
                SalaryManagement.viewSalary();
                break;
            case 11:
                SalaryManagement.updateSalary();
                break;
            case 12:
                SalaryManagement.deleteSalary();
                break;
            case 13:
                System.out.println("Exiting the application.");
                System.exit(0);
            default:
                System.out.println("Invalid choice.Enter corrrect choice.");
        }
    }
}
}
	