package Empl_Mngmt_sys;
import java.sql.*;
import java.util.*;

public class ShiftManagement {
	public static void assignShift() {
		try {
			Connection conn = DatabaseConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter EmployeeId:");
			int employeeId = sc.nextInt();
			System.out.println("Enter shift date:");
			String shiftDate = sc.next();
			System.out.println("Enter startTime:");
			String startTime = sc.next();
			System.out.println("Enter Endtime:");
			String endTime = sc.next();
			
			String query = "insert into shift (employee_id,shift_date,start_time,end_time) values(?,?,?,?)";
			PreparedStatement pstmt =  conn.prepareStatement(query);
			pstmt.setInt(1, employeeId);
			pstmt.setString(2, shiftDate);
			pstmt.setString(3, startTime);
			pstmt.setString(4, endTime);
			pstmt.executeUpdate();
			System.out.println("Shift assigned suceessfully");
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public static void viewShift() {
		try {
			Connection conn = DatabaseConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter shiftId:");
			int shiftId = sc.nextInt();
			String query = "select * from shift where shift_id=?";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, shiftId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				System.out.println("shiftID: "+rs.getInt(1));
				System.out.println("EmployeeID: "+rs.getInt(2));
				System.out.println("Shift Date: "+rs.getString(3));
				System.out.println("start Time: "+rs.getString(4));
				System.out.println("End Time: "+rs.getString(5));
		}
		else {
			System.out.println("Employee with id="+shiftId+" is not found");
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void updateShift() {
		try {
			Connection conn =  DatabaseConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter shiftId:");
			int shiftId = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter EmployeeId:");
			int employeeId = sc.nextInt();
			System.out.println("Enter shift date:");
			String shiftDate = sc.next();
			System.out.println("Enter startTime:");
			String startTime = sc.next();
			System.out.println("Enter Endtime:");
			String endTime = sc.next();
			
			String query = "update shift set employee_id=?,shift_date=?,start_time=?,end_time=? where shift_id=?";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, employeeId);
			pstmt.setString(2, shiftDate);
			pstmt.setString(3, startTime);
			pstmt.setString(4, endTime);
			pstmt.setInt(5, shiftId);
			int rowsaffected = pstmt.executeUpdate();
			if(rowsaffected>0)
				System.out.println("Shift table updated successfully");
			else
				System.out.println("Employee with ShiftId "+shiftId+" not found");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public static void deleteShift() {
		try {
			Connection conn = DatabaseConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter shiftId:");
			int shiftId = sc.nextInt();
			sc.nextLine();
			String query = "delete from shift where shift_id=?";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, shiftId);
			int affectRows = pstmt.executeUpdate();
			if (affectRows>0) 
				System.out.println("Shift deleted successfully");
			else
				System.out.println("Employee with ShiftId "+shiftId+" not found");
					
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	 public static void main(String []args) {
		//assignShift();
		 //viewShift();
		//updateShift();
		 //deleteShift();
		}                   
}
