package Empl_Mngmt_sys;
import java.sql.*;
import java.util.*;

public class EmployeeManagement {
	public static void addEmployee() {
		try {
			Connection conn = DatabaseConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter name:");
			String name = sc.nextLine();
			System.out.println("Enter email:");
			String email = sc.nextLine();
			System.out.println("Enter phone:");
			String phone = sc.nextLine();
			System.out.println("Enter position:");
			String position = sc.nextLine();
			String query = "insert into employee (name,email,phone,position) values (?,?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1,name);
			pstmt.setString(2, email);
			pstmt.setString(3, phone);
			pstmt.setString(4, position);
			pstmt.executeUpdate();
			System.out.println("Employee record added sucessfully");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
    
	public static void viewEmployee() {
		try {
			Connection conn = DatabaseConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter employeeID:");
			int employeeId = sc.nextInt();
			String query = "select * from employee where employee_id=?";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, employeeId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				System.out.println("EmployeeID: "+rs.getInt(1));
				System.out.println("Name: "+rs.getString(2));
				System.out.println("Email: "+rs.getString(3));
				System.out.println("Phone: "+rs.getString(4));
				System.out.println("Position: "+rs.getString(5));
			}
			else {
				System.out.println("Employee with id="+employeeId+" is not found");
				
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void updateEmployee() {
		try {
			Connection conn = DatabaseConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter EmployeeID:");
			int employeeId = sc.nextInt();
			sc.nextLine();
			
			System.out.println("Enter name:");
			String name = sc.nextLine();
			System.out.println("Enter email:");
			String email = sc.nextLine();
			System.out.println("Enter phone:");
			String phone = sc.nextLine();
			System.out.println("Enter position:");
			String position = sc.nextLine();
			
			String query = "update employee set name=?,email=?,phone=?,position=? where employee_id=?";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1, name);
			pstmt.setString(2, email);
			pstmt.setString(3, phone);
			pstmt.setString(4, position);
			pstmt.setInt(5, employeeId);
			int rowsaffected = pstmt.executeUpdate();
			if(rowsaffected>0)
				System.out.println("Employee updated successfully");
			else
				System.out.println("Employee with id "+employeeId+" not found");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void deleteEmployee() {
		try {
			Connection conn = DatabaseConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter EmployeeID:");
			int employeeId = sc.nextInt();
			String query = "delete from employee where employee_id=?";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, employeeId);
			int rowsaffected = pstmt.executeUpdate();
			if(rowsaffected>0) 
				System.out.println("Employee deleted successfully");
			else
				System.out.println("Employee with id "+employeeId+" not found");	
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
  /*   public static void main(String []args) {
		//addEmployee();
		viewEmployee();
		//updateEmployee();
		//deleteEmployee();
	}  
	*/                        
}
