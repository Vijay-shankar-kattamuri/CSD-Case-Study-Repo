create database Employee_Management_System;
use Employee_Management_System;
create table Employee(
				employee_id int primary key auto_increment,
                name varchar(100),
                email varchar(100),
                phone varchar(15),
                position varchar(50)
                );

create table Shift(
				shift_id int primary key auto_increment,
                employee_id int,
                shift_date date,
                start_time time,
                end_time time,
                foreign key(employee_id) references Employee(employee_id)
                );
create table Salary(
				salary_id int primary key auto_increment,
                employee_id int,
                salary_amount decimal(10,2),
                payment_date date,
                foreign key (employee_id) references Employee(employee_id)
                );
                
SELECT * FROM employee_management_system.shift;
use Employee_Management_System;
update employee set employee_id=4 where employee_id=5;