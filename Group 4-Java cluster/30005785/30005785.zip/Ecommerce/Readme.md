E-commerce Order Management System

Overview

The E-commerce Order Management System is a Java-based application designed to manage products, customers, and orders. This system provides functionalities to add, view, update, and delete products and customers, as well as create, view, update, and cancel orders. The application uses MySQL for persistent storage and JDBC for database interactions.

Project Structure

- `.classpath`: Configuration file for the Java classpath.
- `.project`: Configuration file for the Eclipse project.
- `bin/`: Directory containing compiled Java class files.
  - `com/ecommerce/`: Package containing compiled class files.
    - `Customer.class`
    - `CustomerDAO.class`
    - `DatabaseConnection.class`
    - `ECommerceApp.class`
    - `Order.class`
    - `OrderDAO.class`
    - `OrderItem.class`
    - `Product.class`
    - `ProductDAO.class`
- `lib/`: Directory containing external libraries.
  - `mysql-connector-java-8.0.26.jar`: MySQL Connector library for database connectivity.
- `src/`: Directory containing source code files.
  - `com/ecommerce/`: Package containing source code files.
    - `Customer.java`: Defines the Customer class representing a customer.
    - `CustomerDAO.java`: Provides functionalities to manage customers.
    - `DatabaseConnection.java`: Handles database connectivity.
    - `ECommerceApp.java`: Main class to run the application.
    - `Order.java`: Defines the Order class representing an order.
    - `OrderDAO.java`: Provides functionalities to manage orders.
    - `OrderItem.java`: Defines the OrderItem class representing items in an order.
    - `Product.java`: Defines the Product class representing a product.
    - `ProductDAO.java`: Provides functionalities to manage products.

Prerequisites

- Java Development Kit (JDK) 8 or higher
- MySQL database
- MySQL Connector/J library (included in `lib` directory)
- Eclipse IDE (or any other IDE with Java support)