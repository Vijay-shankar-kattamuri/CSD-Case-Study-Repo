package ecommerce;

import java.util.Date;
import java.util.Scanner;

public class ECommerceApp {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Manage Products");
            System.out.println("2. Manage Customers");
            System.out.println("3. Manage Orders");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageProducts();
                    break;
                case 2:
                    manageCustomers();
                    break;
                case 3:
                    manageOrders();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void manageProducts() {
        ProductDAO productDAO = new ProductDAO();

        while (true) {
            System.out.println("1. Add Product");
            System.out.println("2. View Product");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Product product = new Product();
                    System.out.print("Enter product name: ");
                    product.setName(scanner.next());
                    System.out.print("Enter product description: ");
                    product.setDescription(scanner.next());
                    System.out.print("Enter product price: ");
                    product.setPrice(scanner.nextDouble());
                    System.out.print("Enter product quantity in stock: ");
                    product.setQuantityInStock(scanner.nextInt());
                    productDAO.addProduct(product);
                    System.out.println("Product added successfully.");
                    break;
                case 2:
                    System.out.print("Enter product ID: ");
                    int productId = scanner.nextInt();
                    product = productDAO.getProduct(productId);
                    if (product != null) {
                        System.out.println("Product ID: " + product.getProductId());
                        System.out.println("Name: " + product.getName());
                        System.out.println("Description: " + product.getDescription());
                        System.out.println("Price: " + product.getPrice());
                        System.out.println("Quantity in Stock: " + product.getQuantityInStock());
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter product ID to update: ");
                    productId = scanner.nextInt();
                    product = productDAO.getProduct(productId);
                    if (product != null) {
                        System.out.print("Enter new name: ");
                        product.setName(scanner.next());
                        System.out.print("Enter new description: ");
                        product.setDescription(scanner.next());
                        System.out.print("Enter new price: ");
                        product.setPrice(scanner.nextDouble());
                        System.out.print("Enter new quantity in stock: ");
                        product.setQuantityInStock(scanner.nextInt());
                        productDAO.updateProduct(product);
                        System.out.println("Product updated successfully.");
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter product ID to delete: ");
                    productId = scanner.nextInt();
                    productDAO.deleteProduct(productId);
                    System.out.println("Product deleted successfully.");
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void manageCustomers() {
        CustomerDAO customerDAO = new CustomerDAO();

        while (true) {
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Customer customer = new Customer();
                    System.out.print("Enter customer name: ");
                    customer.setName(scanner.next());
                    System.out.print("Enter customer email: ");
                    customer.setEmail(scanner.next());
                    System.out.print("Enter customer phone number: ");
                    customer.setPhoneNumber(scanner.next());
                    System.out.print("Enter customer address: ");
                    customer.setAddress(scanner.next());
                    customerDAO.addCustomer(customer);
                    System.out.println("Customer added successfully.");
                    break;
                case 2:
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    customer = customerDAO.getCustomer(customerId);
                    if (customer != null) {
                        System.out.println("Customer ID: " + customer.getCustomerId());
                        System.out.println("Name: " + customer.getName());
                        System.out.println("Email: " + customer.getEmail());
                        System.out.println("Phone Number: " + customer.getPhoneNumber());
                        System.out.println("Address: " + customer.getAddress());
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter customer ID to update: ");
                    customerId = scanner.nextInt();
                    customer = customerDAO.getCustomer(customerId);
                    if (customer != null) {
                        System.out.print("Enter new name: ");
                        customer.setName(scanner.next());
                        System.out.print("Enter new email: ");
                        customer.setEmail(scanner.next());
                        System.out.print("Enter new phone number: ");
                        customer.setPhoneNumber(scanner.next());
                        System.out.print("Enter new address: ");
                        customer.setAddress(scanner.next());
                        customerDAO.updateCustomer(customer);
                        System.out.println("Customer updated successfully.");
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter customer ID to delete: ");
                    customerId = scanner.nextInt();
                    customerDAO.deleteCustomer(customerId);
                    System.out.println("Customer deleted successfully.");
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void manageOrders() {
        OrderDAO orderDAO = new OrderDAO();

        while (true) {
            System.out.println("1. Create Order");
            System.out.println("2. View Order");
            System.out.println("3. Update Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Order order = new Order();
                    System.out.print("Enter customer ID: ");
                    order.setCustomerId(scanner.nextInt());
                    order.setOrderDate(new Date());
                    System.out.print("Enter total amount: ");
                    order.setTotalAmount(scanner.nextDouble());
                    order.setStatus("pending");
                    orderDAO.createOrder(order);
                    System.out.println("Order created successfully.");
                    break;
                case 2:
                    System.out.print("Enter order ID: ");
                    int orderId = scanner.nextInt();
                    order = orderDAO.getOrder(orderId);
                    if (order != null) {
                        System.out.println("Order ID: " + order.getOrderId());
                        System.out.println("Customer ID: " + order.getCustomerId());
                        System.out.println("Order Date: " + order.getOrderDate());
                        System.out.println("Total Amount: " + order.getTotalAmount());
                        System.out.println("Status: " + order.getStatus());
                    } else {
                        System.out.println("Order not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter order ID to update: ");
                    orderId = scanner.nextInt();
                    order = orderDAO.getOrder(orderId);
                    if (order != null) {
                        System.out.print("Enter new customer ID: ");
                        order.setCustomerId(scanner.nextInt());
                        System.out.print("Enter new total amount: ");
                        order.setTotalAmount(scanner.nextDouble());
                        System.out.print("Enter new status: ");
                        order.setStatus(scanner.next());
                        orderDAO.updateOrder(order);
                        System.out.println("Order updated successfully.");
                    } else {
                        System.out.println("Order not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter order ID to cancel: ");
                    orderId = scanner.nextInt();
                    orderDAO.cancelOrder(orderId);
                    System.out.println("Order cancelled successfully.");
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
}
