/**
 * 
 */
/**
 * 
 */
module test {
	requires java.sql;
}