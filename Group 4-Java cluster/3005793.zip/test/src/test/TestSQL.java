package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;



public class TestSQL {

	public static void main(String[] args) throws SQLException {
		
		
		Connection con = DriverManager.getConnection("jdbc:mysql://192.168.1.2:3306/timepass", "root", "Mohammed:1");


	Statement stmt = con.createStatement();
	
	String s ="INSERT INTO sys VALUES(103,'SMITH')";
	
	stmt.execute(s);
	
	con.close();
	
	System.out.println("Query executrd.....");
	}

}
