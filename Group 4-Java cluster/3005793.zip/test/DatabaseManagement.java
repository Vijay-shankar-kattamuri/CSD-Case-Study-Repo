package com.mui.jdbcproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DatabaseManagement {
    static String userName = "root";
    static String password = "xxxxxxx";
    static String dbms = "mysql";
    static String serverName = "localhost";
    static String portNumber = "3306";
    static String dbName = "members";
    static Connection connection = null;

    public static void main(String[] args) {
        try {
            connection = DriverManager.getConnection(
                "jdbc:mysql://" + serverName + ":" + portNumber + "/" + dbName, userName, password);
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("Select a table to manage:");
                System.out.println("1. Member");
                System.out.println("2. Trainer");
                System.out.println("3. Class");
                System.out.println("4. Exit");
                int tableChoice = scanner.nextInt();
                scanner.nextLine(); 

                if (tableChoice == 4) break;

                String tableName = "";
                switch (tableChoice) {
                    case 1:
                        tableName = "member";
                        break;
                    case 2:
                        tableName = "trainer";
                        break;
                    case 3:
                        tableName = "class";
                        break;
                    default:
                        System.out.println("Invalid choice");
                        continue;
                }

                System.out.println("Select an operation:");
                System.out.println("1. Add");
                System.out.println("2. Delete");
                System.out.println("3. Update");
                System.out.println("4. Go Back");
                int operationChoice = scanner.nextInt();
                scanner.nextLine(); 

                if (operationChoice == 4) continue;

                switch (operationChoice) {
                    case 1:
                        addEntry(scanner, tableName);
                        break;
                    case 2:
                        deleteEntry(scanner, tableName);
                        break;
                    case 3:
                        updateEntry(scanner, tableName);
                        break;
                    default:
                        System.out.println("Invalid choice");
                }
            }
            connection.close();
            scanner.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addEntry(Scanner scanner, String tableName) throws SQLException {
        PreparedStatement preparedStatement = null;
        switch (tableName) {
            case "member":
                System.out.println("Enter member ID:");
                int memberId = scanner.nextInt();
                scanner.nextLine(); 
                System.out.println("Enter name:");
                String name = scanner.nextLine();
                System.out.println("Enter email:");
                String email = scanner.nextLine();
                System.out.println("Enter phone number:");
                String phoneNumber = scanner.nextLine();
                System.out.println("Enter membership type:");
                String membershipType = scanner.nextLine();
                preparedStatement = connection.prepareStatement(
                    "INSERT INTO member (member_id, name, email, phone_number, membership_type) VALUES (?, ?, ?, ?, ?)");
                preparedStatement.setInt(1, memberId);
                preparedStatement.setString(2, name);
                preparedStatement.setString(3, email);
                preparedStatement.setString(4, phoneNumber);
                preparedStatement.setString(5, membershipType);
                break;
            case "trainer":
                System.out.println("Enter trainer ID:");
                int trainerId = scanner.nextInt();
                scanner.nextLine(); 
                System.out.println("Enter name:");
                name = scanner.nextLine();
                System.out.println("Enter email:");
                email = scanner.nextLine();
                System.out.println("Enter phone number:");
                phoneNumber = scanner.nextLine();
                System.out.println("Enter specialization:");
                String specialization = scanner.nextLine();
                preparedStatement = connection.prepareStatement(
                    "INSERT INTO trainer (trainer_id, name, email, phone_number, specialization) VALUES (?, ?, ?, ?, ?)");
                preparedStatement.setInt(1, trainerId);
                preparedStatement.setString(2, name);
                preparedStatement.setString(3, email);
                preparedStatement.setString(4, phoneNumber);
                preparedStatement.setString(5, specialization);
                break;
            case "class":
                System.out.println("Enter class ID:");
                int classId = scanner.nextInt();
                System.out.println("Enter trainer ID:");
                trainerId = scanner.nextInt();
                scanner.nextLine(); 
                System.out.println("Enter class name:");
                String className = scanner.nextLine();
                System.out.println("Enter schedule (YYYY-MM-DD HH:MM:SS):");
                String schedule = scanner.nextLine();
                System.out.println("Enter capacity:");
                int capacity = scanner.nextInt();
                scanner.nextLine(); 
                System.out.println("Enter status (scheduled/cancelled):");
                String status = scanner.nextLine();
                preparedStatement = connection.prepareStatement(
                    "INSERT INTO class (class_id, trainer_id, class_name, schedule, capacity, status) VALUES (?, ?, ?, ?, ?, ?)");
                preparedStatement.setInt(1, classId);
                preparedStatement.setInt(2, trainerId);
                preparedStatement.setString(3, className);
                preparedStatement.setString(4, schedule);
                preparedStatement.setInt(5, capacity);
                preparedStatement.setString(6, status);
                break;
        }
        if (preparedStatement != null) {
            preparedStatement.executeUpdate();
            System.out.println("Entry added successfully.");
        }
    }

    private static void deleteEntry(Scanner scanner, String tableName) throws SQLException {
        System.out.println("Enter ID to delete:");
        int id = scanner.nextInt();
        scanner.nextLine();
        String query = "";
        switch (tableName) {
            case "member":
                query = "DELETE FROM member WHERE member_id = ?";
                break;
            case "trainer":
                query = "DELETE FROM trainer WHERE trainer_id = ?";
                break;
            case "class":
                query = "DELETE FROM class WHERE class_id = ?";
                break;
        }

        if (!query.isEmpty()) {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            System.out.println("Entry deleted successfully.");
        }
    }

    private static void updateEntry(Scanner scanner, String tableName) throws SQLException {
        System.out.println("Enter ID to update:");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        PreparedStatement preparedStatement = null;
        switch (tableName) {
            case "member":
                System.out.println("Enter new name:");
                String name = scanner.nextLine();
                System.out.println("Enter new email:");
                String email = scanner.nextLine();
                System.out.println("Enter new phone number:");
                String phoneNumber = scanner.nextLine();
                System.out.println("Enter new membership type:");
                String membershipType = scanner.nextLine();
                preparedStatement = connection.prepareStatement(
                    "UPDATE member SET name = ?, email = ?, phone_number = ?, membership_type = ? WHERE member_id = ?");
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, email);
                preparedStatement.setString(3, phoneNumber);
                preparedStatement.setString(4, membershipType);
                preparedStatement.setInt(5, id);
                break;
            case "trainer":
                System.out.println("Enter new name:");
                name = scanner.nextLine();
                System.out.println("Enter new email:");
                email = scanner.nextLine();
                System.out.println("Enter new phone number:");
                phoneNumber = scanner.nextLine();
                System.out.println("Enter new specialization:");
                String specialization = scanner.nextLine();
                preparedStatement = connection.prepareStatement(
                    "UPDATE trainer SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE trainer_id = ?");
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, email);
                preparedStatement.setString(3, phoneNumber);
                preparedStatement.setString(4, specialization);
                preparedStatement.setInt(5, id);
                break;
            case "class":
                System.out.println("Enter new trainer ID:");
                int trainerId = scanner.nextInt();
                scanner.nextLine(); 
                System.out.println("Enter new class name:");
                String className = scanner.nextLine();
                System.out.println("Enter new schedule (YYYY-MM-DD HH:MM:SS):");
                String schedule = scanner.nextLine();
                System.out.println("Enter new capacity:");
                int capacity = scanner.nextInt();
                scanner.nextLine(); 
                System.out.println("Enter new status (scheduled/cancelled):");
                String status = scanner.nextLine();
                preparedStatement = connection.prepareStatement(
                    "UPDATE class SET trainer_id = ?, class_name = ?, schedule = ?, capacity = ?, status = ? WHERE class_id = ?");
                preparedStatement.setInt(1, trainerId);
                preparedStatement.setString(2, className);
                preparedStatement.setString(3, schedule);
                preparedStatement.setInt(4, capacity);
                preparedStatement.setString(5, status);
                preparedStatement.setInt(6, id);
                break;
        }
        if (preparedStatement != null) {
            preparedStatement.executeUpdate();
            System.out.println("Entry updated successfully.");
        }
    }
}
