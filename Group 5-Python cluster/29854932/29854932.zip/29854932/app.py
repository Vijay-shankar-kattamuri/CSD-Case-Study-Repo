import modules.flight as flight
import modules.passenger as passenger
import modules.report as report
import datetime
import modules.reservation as reservation
from tabulate import tabulate

def main():
    print()
    print(" Welcome to Flight Reservation System ".center(100, "="))
    while True:
        print("1. Flight Management")
        print("2. Passenger Management")
        print("3. Reservation Management")
        print("4. Generate Reports")
        print("5. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            while True:
                print(" Flight Management ".center(50, "="))
                print("1. Add Flight")
                print("2. Update Flight")
                print("3. Delete Flight")
                print("4. Get Flight")
                print("5. Get all Flights")
                print("6. Exit")
                flight_choice = input("Enter your choice: ")
                try:
                    if flight_choice == "1":
                        id = int(input("Enter flight ID: "))
                        airline = input("Enter airline: ")
                        destination = input("Enter destination: ")
                        while True:
                            try:
                                departure_time_str = input("Enter departure time (yyyy-mm-dd hh:mm): ")
                                departure_time = datetime.datetime.strptime(departure_time_str, '%Y-%m-%d %H:%M')
                                break
                            except ValueError:
                                print("Invalid date format. Please use yyyy-mm-dd hh:mm format.")
                        available_seats = int(input("Enter available seats: "))
                        fl = flight.Flight(id, airline, destination, departure_time, available_seats)
                        fl.add_flight()
                    elif flight_choice == "2":
                        id = int(input("Enter flight ID to update: "))
                        airline = input("Enter new airline: ")
                        destination = input("Enter new destination: ")
                        while True:
                            try:
                                departure_time_str = input("Enter new departure time (yyyy-mm-dd hh:mm): ")
                                departure_time = datetime.datetime.strptime(departure_time_str, '%Y-%m-%d %H:%M')
                                break
                            except ValueError:
                                print("Invalid date format. Please use yyyy-mm-dd hh:mm format.")
                        available_seats = int(input("Enter new available seats: "))
                        fl = flight.Flight(id, airline, destination, departure_time, available_seats)
                        fl.update_flight()
                    elif flight_choice == "3":
                        id = int(input("Enter flight ID to delete: "))
                        fl = flight.Flight(id, "", "", None, 0)
                        fl.delete_flight()
                    elif flight_choice == "4":
                        id = int(input("Enter flight ID to get: "))
                        flight_data = flight.Flight.get_flight(id)
                        if flight_data:
                            print(" Flight Details ".center(50, "="))
                            print(f"Flight ID: {flight_data[0]}")
                            print(f"Airline: {flight_data[1]}")
                            print(f"Destination: {flight_data[2]}")
                            print(f"Departure Time: {flight_data[3]}")
                            print(f"Available Seats: {flight_data[4]}")
                            print("=" * 50)
                        else:
                            print("Flight not found")
                    elif flight_choice == "5":
                        flights = flight.Flight.get_all_flights()
                        if flights:
                            print(" All Flights ".center(50, "="))
                            headers = ["Flight ID", "Airline", "Destination", "Departure Time", "Available Seats"]
                            print(tabulate(flights, headers=headers, tablefmt="grid"))
                        else:
                            print("No flights found")
                    elif flight_choice == "6":
                        print(" Exiting Flight Management ".center(50, "="))
                        break
                    else:
                        print("Invalid choice. Please try again")
                except ValueError:
                    print("Invalid input. Please try again")
        elif choice == "2":
            while True:
                print(" Passenger Management ".center(50, "="))
                print("1. Add Passenger")
                print("2. Update Passenger")
                print("3. Delete Passenger")
                print("4. Get Passenger")
                print("5. View all Passengers")
                print("6. Exit")
                passenger_choice = input("Enter your choice: ")
                try:
                    if passenger_choice == "1":
                        passenger_id = int(input("Enter passenger ID: "))
                        name = input("Enter passenger name: ")
                        contact_info = input("Enter contact info: ")
                        psg = passenger.Passenger(passenger_id, name, contact_info)
                        psg.add_passenger()
                    elif passenger_choice == "2":
                        passenger_id = int(input("Enter passenger ID to update: "))
                        name = input("Enter new name: ")
                        contact_info = input("Enter new contact info: ")
                        psg = passenger.Passenger(passenger_id, name, contact_info)
                        psg.update_passenger()
                    elif passenger_choice == "3":
                        passenger_id = int(input("Enter passenger ID to delete: "))
                        psg = passenger.Passenger(passenger_id, None, None)
                        psg.delete_passenger()
                    elif passenger_choice == "4":
                        passenger_id = int(input("Enter passenger ID to get details: "))
                        passenger_data = passenger.Passenger.get_passenger(passenger_id)
                        if passenger_data:
                            print(" Passenger Details ".center(50, "="))
                            print(f"Passenger ID: {passenger_data[0]}")
                            print(f"Name: {passenger_data[1]}")
                            print(f"Contact Info: {passenger_data[2]}")
                            print("=" * 50)
                        else:
                            print("Passenger not found.")
                    elif passenger_choice == "5":
                        passengers = passenger.Passenger.get_all_passengers()
                        if passengers:
                            print(" All Passengers ".center(50, "="))
                            headers = ["ID", "Name", "Contact Info"]
                            print(tabulate(passengers, headers=headers, tablefmt="grid"))
                        else:
                            print("No passengers found.")
                    elif passenger_choice == "6":
                        print(" Exiting Passenger Management ".center(50, "="))
                        break
                    else:
                        print("Invalid choice. Please try again")
                except ValueError:
                    print("Invalid input. Please try again")
        elif choice == "3":
            while True:
                print(" Reservation Management ".center(50, "="))
                print("1. Add Reservation")
                print("2. Update Reservation")
                print("3. Delete Reservation")
                print("4. Get Reservation")
                print("5. View All Reservations")
                print("6. Exit")
                reservation_choice = input("Enter your choice: ")
                try:
                    if reservation_choice == "1":
                        reservation_id = int(input("Enter reservation ID: "))
                        passenger_id = int(input("Enter passenger ID: "))
                        flight_id = int(input("Enter flight ID: "))
                        seat_number = input("Enter seat number: ")
                        reservation_date = datetime.datetime.strptime(input("Enter reservation date (yyyy-mm-dd): "), '%Y-%m-%d').date()
                        res = reservation.Reservation(reservation_id, passenger_id, flight_id, seat_number, reservation_date)
                        res.add_reservation()
                    elif reservation_choice == "2":
                        reservation_id = int(input("Enter reservation ID to update: "))
                        passenger_id = int(input("Enter new passenger ID: "))
                        flight_id = int(input("Enter new flight ID: "))
                        seat_number = input("Enter new seat number: ")
                        reservation_date = datetime.datetime.strptime(input("Enter new reservation date (yyyy-mm-dd): "), '%Y-%m-%d').date()
                        res = reservation.Reservation(reservation_id, passenger_id, flight_id, seat_number, reservation_date)
                        res.update_reservation()
                    elif reservation_choice == "3":
                        reservation_id = int(input("Enter reservation ID to delete: "))
                        res = reservation.Reservation(reservation_id, None, None, None, None)
                        res.delete_reservation()
                    elif reservation_choice == "4":
                        reservation_id = int(input("Enter reservation ID to get details: "))
                        reservation_data = reservation.Reservation.get_reservation(reservation_id)
                        if reservation_data:
                            print(f"Reservation ID: {reservation_data[0]}")
                            print(f"Passenger ID: {reservation_data[1]}")
                            print(f"Flight ID: {reservation_data[2]}")
                            print(f"Seat Number: {reservation_data[3]}")
                            print(f"Reservation Date: {reservation_data[4]}")
                        else:
                            print("Reservation not found.")
                    elif reservation_choice == "5":
                        reservations = reservation.Reservation.get_all_reservations()
                        if reservations:
                            print(" All Reservations ".center(50, "="))
                            headers = ["ID", "Passenger ID", "Flight ID", "Seat Number", "Reservation Date"]
                            tabulate(reservations, headers=headers, tablefmt="grid")
                            print("=" * 50)
                        else:
                            print("No reservations found.")
                    elif reservation_choice == "6":
                        print(" Exiting Reservation Management ".center(50, "="))
                        break
                    else:
                        print("Invalid choice. Please try again")
                except ValueError:
                    print("Invalid input. Please try again")
        elif choice == "4":
            print(" Generating Reports ".center(50, "="))
            rep = report.Report()
            rep.generate_report()
        elif choice == "5":
            print(" Thank you for using Flight Reservation System ".center(100, "="))
            print()
            break
        else:
            print("Invalid choice. Please try again")

if __name__ == "__main__":
    main()