import mysql.connector
from mysql.connector import Error
import datetime

class Passenger:
    def __init__(self, passenger_id, name, contact_info):
        self.passenger_id = passenger_id
        self.name = name
        self.contact_info = contact_info
        self.mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
        self.mycursor = self.mydb.cursor()

    def __del__(self):
        self.disconnect_db()

    def disconnect_db(self):
        if self.mydb.is_connected():
            self.mycursor.close()
            self.mydb.close()
            print("Connection closed")

    def check_passenger_exists(self, passenger_id):
        try:
            sql = "SELECT 1 FROM passenger WHERE passenger_id = %s"
            self.mycursor.execute(sql, (passenger_id,))
            return self.mycursor.fetchone() is not None
        except Error as e:
            print(f"Error checking passenger existence for passenger_id {passenger_id}: {e}")
            return False

    def add_passenger(self):
        if self.check_passenger_exists(self.passenger_id):
            print(f"Passenger with ID {self.passenger_id} already exists.")
            return
        try:
            sql = """INSERT INTO passenger (passenger_id, name, contact_info)
                     VALUES (%s, %s, %s)"""
            self.mycursor.execute(sql, (self.passenger_id, self.name, self.contact_info))
            self.mydb.commit()
            print(f"Passenger {self.name} added successfully")
        except Error as e:
            print(f"Error adding passenger {self.name}: {e}")

    def update_passenger(self):
        if not self.check_passenger_exists(self.passenger_id):
            print(f"Passenger with ID {self.passenger_id} does not exist.")
            return
        try:
            sql = """UPDATE passenger SET name = %s, contact_info = %s
                     WHERE passenger_id = %s"""
            self.mycursor.execute(sql, (self.name, self.contact_info, self.passenger_id))
            self.mydb.commit()
            print(f"Passenger {self.name} updated successfully")
        except Error as e:
            print(f"Error updating passenger {self.name}: {e}")

    def delete_passenger(self):
        if not self.check_passenger_exists(self.passenger_id):
            print(f"Passenger with ID {self.passenger_id} does not exist.")
            return
        try:
            sql = "DELETE FROM passenger WHERE passenger_id = %s"
            self.mycursor.execute(sql, (self.passenger_id,))
            self.mydb.commit()
            print(f"Passenger with ID {self.passenger_id} deleted successfully")
        except Error as e:
            print(f"Error deleting passenger with ID {self.passenger_id}: {e}")

    @staticmethod
    def get_passenger(passenger_id):
        try:
            mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
            mycursor = mydb.cursor()
            sql = "SELECT * FROM passenger WHERE passenger_id = %s"
            mycursor.execute(sql, (passenger_id,))
            passenger_data = mycursor.fetchone()
            if passenger_data:
                return passenger_data
            else:
                print(f"Passenger with ID {passenger_id} not found")
                return None
        except Error as e:
            print(f"Error getting passenger with ID {passenger_id}: {e}")
        finally:
            Passenger.disconnect(mydb, mycursor)

    @staticmethod
    def get_all_passengers():
        try:
            mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
            mycursor = mydb.cursor()
            sql = "SELECT * FROM passenger"
            mycursor.execute(sql)
            passengers = mycursor.fetchall()
            return passengers
        except Error as e:
            print(f"Error getting all passengers: {e}")
            return []
        finally:
            Passenger.disconnect(mydb, mycursor)

    @staticmethod
    def disconnect(mydb, mycursor):
        if mydb.is_connected():
            mycursor.close()
            mydb.close()
            print("Connection closed")
        else:
            print("Connection already closed")