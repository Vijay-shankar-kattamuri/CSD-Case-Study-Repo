import datetime
import mysql.connector
from mysql.connector import Error

class Flight:
    def __init__(self, flight_id, airline, destination, departure_time, available_seats):
        self.flight_id = flight_id
        self.airline = airline
        self.destination = destination
        self.departure_time = departure_time
        self.available_seats = available_seats
        self.mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
        self.mycursor = self.mydb.cursor()

    def __del__(self):
        self.disconnect_db()
    
    @staticmethod
    def disconnect(mydb, mycursor):
        if mydb.is_connected():
            mycursor.close()
            mydb.close()
            print("Connection closed")
        else:
            print("Connection closed")

    def disconnect_db(self):
        if self.mydb.is_connected():
            self.mycursor.close()
            self.mydb.close()
            print("Connection closed")
        else:
            print("Connection already closed")

    def check_flight_exists(self, flight_id):
        try:
            sql = "SELECT * FROM flight WHERE flight_id = %s"
            values = (flight_id,)
            self.mycursor.execute(sql, values)
            flight_data = self.mycursor.fetchone()
            return flight_data is not None
        except Error as e:
            print(f"Error checking flight existence for flight_id {flight_id}: {e}")
            return False
    
    def add_flight(self):
        try:
            if self.check_flight_exists(self.flight_id):
                print(f"Flight with ID {self.flight_id} already exists.")
                return
            sql = "INSERT INTO flight (flight_id, airline, destination, departure_time, available_seats) VALUES (%s, %s, %s, %s, %s)"
            values = (self.flight_id, self.airline, self.destination, self.departure_time, self.available_seats)
            self.mycursor.execute(sql, values)
            self.mydb.commit()
            print(f"Flight {self.flight_id} added successfully")
        except Error as e:
            print(f"Error adding flight {self.flight_id}: {e}")

    def update_flight(self):
        try:
            if not self.check_flight_exists(self.flight_id):
                print(f"Flight with ID {self.flight_id} not exist.")
                return
            sql = "UPDATE flight SET airline = %s, destination = %s, departure_time = %s, available_seats = %s WHERE flight_id = %s"
            values = (self.airline, self.destination, self.departure_time, self.available_seats, self.flight_id)
            self.mycursor.execute(sql, values)
            self.mydb.commit()
            print(f"Flight {self.flight_id} updated successfully")
        except Error as e:
            print(f"Error updating flight {self.flight_id}: {e}")
        

    def delete_flight(self):
        try:
            if not self.check_flight_exists(self.flight_id):
                print(f"Flight with ID {self.flight_id} not exist.")
                return
            sql = "DELETE FROM flight WHERE flight_id = %s"
            values = (self.flight_id,)
            self.mycursor.execute(sql, values)
            self.mydb.commit()
            print(f"Flight {self.flight_id} deleted successfully")
        except Error as e:
            print(f"Error deleting flight {self.flight_id}: {e}")

    @staticmethod
    def get_flight(flight_id):
        try:
            mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
            mycursor = mydb.cursor()
            sql = "SELECT * FROM flight WHERE flight_id = %s"
            values = (flight_id,)
            mycursor.execute(sql, values)
            flight_data = mycursor.fetchone()
            if flight_data:
                return flight_data
            else:
                print(f"Flight with ID {flight_id} not found")
                return None
        except Error as e:
            print(f"Error getting flight {flight_id}: {e}")
        finally:
            Flight.disconnect(mydb, mycursor)

    @staticmethod
    def get_all_flights():
        try:
            mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
            mycursor = mydb.cursor()
            mycursor.execute("SELECT * FROM flight")
            flights = mycursor.fetchall()
            if flights:
                return flights
            else:
                print("No flights found")
                return None
        except Error as e:
            print(f"Error getting all flights: {e}")
        finally:
            Flight.disconnect(mydb, mycursor)