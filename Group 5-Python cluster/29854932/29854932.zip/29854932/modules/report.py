# 29854932
from tabulate import tabulate
import mysql.connector
from mysql.connector import Error

class Report:
    def __init__(self):
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="myPASSWORD",
            database="my_db"
        )
        self.mycursor = self.mydb.cursor()

    def disconnect_db(self):
        if self.mydb.is_connected():
            self.mycursor.close()
            self.mydb.close()
            print("Database connection closed.")

    def get_all_flights(self):
        try:
            self.mycursor.execute("SELECT * FROM flight")
            flights = self.mycursor.fetchall()
            return flights
        except Error as e:
            print(f"Error fetching flights: {e}")
            return []

    def get_all_passengers(self):
        try:
            self.mycursor.execute("SELECT * FROM passenger")
            passengers = self.mycursor.fetchall()
            return passengers
        except Error as e:
            print(f"Error fetching passengers: {e}")
            return []

    def get_all_reservations(self):
        try:
            self.mycursor.execute("SELECT * FROM reservations")
            reservations = self.mycursor.fetchall()
            return reservations
        except Error as e:
            print(f"Error fetching reservations: {e}")
            return []

    def generate_report(self):
        flights = self.get_all_flights()
        passengers = self.get_all_passengers()
        reservations = self.get_all_reservations()

        if flights:
            print("Flights Report")
            print(tabulate(flights, headers=["ID", "Airline", "Destination", "Departure Time", "Available Seats"], tablefmt="pretty"))
        else:
            print("No flights found.")

        if passengers:
            print("\nPassengers Report")
            print(tabulate(passengers, headers=["Passenger ID", "Name", "Contact Info"], tablefmt="pretty"))
        else:
            print("No passengers found.")

        if reservations:
            print("\nReservations Report")
            print(tabulate(reservations, headers=["Reservation ID", "Passenger ID", "Flight ID", "Seat Number", "Reservation Date"], tablefmt="pretty"))
        else:
            print("No reservations found.")
        self.disconnect_db()
