import mysql.connector
from mysql.connector import Error

class Reservation:
    def __init__(self, reservation_id, passenger_id, flight_id, seat_number, reservation_date):
        self.reservation_id = reservation_id
        self.passenger_id = passenger_id
        self.flight_id = flight_id
        self.seat_number = seat_number
        self.reservation_date = reservation_date
        self.mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
        self.mycursor = self.mydb.cursor()

    def __del__(self):
        self.disconnect_db()

    def disconnect_db(self):
        if self.mydb.is_connected():
            self.mycursor.close()
            self.mydb.close()
            print("Connection closed")

    def check_reservation_exists(self, reservation_id):
        try:
            sql = "SELECT 1 FROM reservations WHERE reservation_id = %s"
            self.mycursor.execute(sql, (reservation_id,))
            return self.mycursor.fetchone() is not None
        except Error as e:
            print(f"Error checking reservation existence for reservation_id {reservation_id}: {e}")
            return False

    def add_reservation(self):
        if self.check_reservation_exists(self.reservation_id):
            print(f"Reservation with ID {self.reservation_id} already exists.")
            return
        try:
            sql = """INSERT INTO reservations (reservation_id, passenger_id, flight_id, seat_number, reservation_date)
                     VALUES (%s, %s, %s, %s, %s)"""
            self.mycursor.execute(sql, (self.reservation_id, self.passenger_id, self.flight_id, self.seat_number, self.reservation_date))
            self.mydb.commit()
            print(f"Reservation {self.reservation_id} added successfully")
        except Error as e:
            print(f"Error adding reservation {self.reservation_id}: {e}")

    def update_reservation(self):
        if not self.check_reservation_exists(self.reservation_id):
            print(f"Reservation with ID {self.reservation_id} does not exist.")
            return
        try:
            sql = """UPDATE reservations SET passenger_id = %s, flight_id = %s, seat_number = %s, reservation_date = %s
                     WHERE reservation_id = %s"""
            self.mycursor.execute(sql, (self.passenger_id, self.flight_id, self.seat_number, self.reservation_date, self.reservation_id))
            self.mydb.commit()
            print(f"Reservation {self.reservation_id} updated successfully")
        except Error as e:
            print(f"Error updating reservation {self.reservation_id}: {e}")

    def delete_reservation(self):
        if not self.check_reservation_exists(self.reservation_id):
            print(f"Reservation with ID {self.reservation_id} does not exist.")
            return
        try:
            sql = "DELETE FROM reservations WHERE reservation_id = %s"
            self.mycursor.execute(sql, (self.reservation_id,))
            self.mydb.commit()
            print(f"Reservation with ID {self.reservation_id} deleted successfully")
        except Error as e:
            print(f"Error deleting reservation with ID {self.reservation_id}: {e}")

    @staticmethod
    def get_reservation(reservation_id):
        try:
            mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
            mycursor = mydb.cursor()
            sql = "SELECT * FROM reservations WHERE reservation_id = %s"
            mycursor.execute(sql, (reservation_id,))
            reservation_data = mycursor.fetchone()
            if reservation_data:
                return reservation_data
            else:
                print(f"Reservation with ID {reservation_id} not found")
                return None
        except Error as e:
            print(f"Error getting reservation with ID {reservation_id}: {e}")
        finally:
            Reservation.disconnect(mydb, mycursor)

    @staticmethod
    def get_all_reservations():
        try:
            mydb = mysql.connector.connect(host="localhost", user="root", password="myPASSWORD", database="my_db")
            mycursor = mydb.cursor()
            sql = "SELECT * FROM reservations"
            mycursor.execute(sql)
            reservations = mycursor.fetchall()
            return reservations
        except Error as e:
            print(f"Error getting all reservations: {e}")
            return []
        finally:
            Reservation.disconnect(mydb, mycursor)

    @staticmethod
    def disconnect(mydb, mycursor):
        if mydb.is_connected():
            mycursor.close()
            mydb.close()
            print("Connection closed")
        else:
            print("Connection already closed")