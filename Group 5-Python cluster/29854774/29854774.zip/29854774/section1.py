from datetime import datetime

class Flight:
    def __init__(self, flight_id, airline, destination, departure_time, available_seats):
        self.flight_id = flight_id
        self.airline = airline
        self.destination = destination
        self.departure_time = departure_time
        self.available_seats = available_seats

    def update_flight(self, airline=None, destination=None, departure_time=None, available_seats=None):
        if airline is not None:
            self.airline = airline
        if destination is not None:
            self.destination = destination
        if departure_time is not None:
            self.departure_time = departure_time
        if available_seats is not None:
            self.available_seats = available_seats

    def __str__(self):
        return f"Flight {self.flight_id}: {self.airline} to {self.destination} at {self.departure_time}, Seats available: {self.available_seats}"


class Reservation:
    def __init__(self, reservation_id, passenger_name, flight_id, seat_number, reservation_date=None):
        self.reservation_id = reservation_id
        self.passenger_name = passenger_name
        self.flight_id = flight_id
        self.seat_number = seat_number
        self.reservation_date = reservation_date or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def update_reservation(self, passenger_name=None, flight_id=None, seat_number=None):
        if passenger_name is not None:
            self.passenger_name = passenger_name
        if flight_id is not None:
            self.flight_id = flight_id
        if seat_number is not None:
            self.seat_number = seat_number

    def __str__(self):
        return f"Reservation {self.reservation_id}: {self.passenger_name} on flight {self.flight_id} seat {self.seat_number} at {self.reservation_date}"


class AirlineReservationSystem:
    def __init__(self):
        self.flights = {}
        self.reservations = {}

    def add_flight(self, flight):
        if flight.flight_id in self.flights:
            raise ValueError(f"Flight {flight.flight_id} already exists.")
        self.flights[flight.flight_id] = flight

    def update_flight(self, flight_id, **kwargs):
        if flight_id not in self.flights:
            raise ValueError(f"Flight {flight_id} does not exist.")
        self.flights[flight_id].update_flight(**kwargs)

    def delete_flight(self, flight_id):
        if flight_id not in self.flights:
            raise ValueError(f"Flight {flight_id} does not exist.")
        del self.flights[flight_id]

    def add_reservation(self, reservation):
        if reservation.reservation_id in self.reservations:
            raise ValueError(f"Reservation {reservation.reservation_id} already exists.")
        if reservation.flight_id not in self.flights:
            raise ValueError(f"Flight {reservation.flight_id} does not exist.")
        if self.flights[reservation.flight_id].available_seats <= 0:
            raise ValueError(f"No available seats on flight {reservation.flight_id}.")
        self.flights[reservation.flight_id].available_seats -= 1
        self.reservations[reservation.reservation_id] = reservation

    def update_reservation(self, reservation_id, **kwargs):
        if reservation_id not in self.reservations:
            raise ValueError(f"Reservation {reservation_id} does not exist.")
        self.reservations[reservation_id].update_reservation(**kwargs)

    def cancel_reservation(self, reservation_id):
        if reservation_id not in self.reservations:
            raise ValueError(f"Reservation {reservation_id} does not exist.")
        flight_id = self.reservations[reservation_id].flight_id
        self.flights[flight_id].available_seats += 1
        del self.reservations[reservation_id]

    def get_passengers_on_flight(self, flight_id):
        if flight_id not in self.flights:
            raise ValueError(f"Flight {flight_id} does not exist.")
        passengers = [res for res in self.reservations.values() if res.flight_id == flight_id]
        return passengers

    def __str__(self):
        flights_str = "\n".join(str(flight) for flight in self.flights.values())
        reservations_str = "\n".join(str(reservation) for reservation in self.reservations.values())
        return f"Flights:\n{flights_str}\n\nReservations:\n{reservations_str}"


def main():
    system = AirlineReservationSystem()

    while True:
        print("\nAirline Reservation Management System")
        print("1. Add Flight")
        print("2. Update Flight")
        print("3. Delete Flight")
        print("4. Add Reservation")
        print("5. Update Reservation")
        print("6. Cancel Reservation")
        print("7. List Passengers on Flight")
        print("8. Exit")
        
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                flight_id = input("Enter flight ID: ")
                airline = input("Enter airline: ")
                destination = input("Enter destination: ")
                departure_time = input("Enter departure time (YYYY-MM-DD HH:MM): ")
                available_seats = int(input("Enter available seats: "))
                flight = Flight(flight_id, airline, destination, departure_time, available_seats)
                system.add_flight(flight)
                print("Flight added successfully.")

            elif choice == '2':
                flight_id = input("Enter flight ID to update: ")
                airline = input("Enter new airline (leave blank to keep current): ")
                destination = input("Enter new destination (leave blank to keep current): ")
                departure_time = input("Enter new departure time (leave blank to keep current): ")
                available_seats = input("Enter new available seats (leave blank to keep current): ")
                kwargs = {
                    "airline": airline if airline else None,
                    "destination": destination if destination else None,
                    "departure_time": departure_time if departure_time else None,
                    "available_seats": int(available_seats) if available_seats else None
                }
                system.update_flight(flight_id, **{k: v for k, v in kwargs.items() if v is not None})
                print("Flight updated successfully.")

            elif choice == '3':
                flight_id = input("Enter flight ID to delete: ")
                system.delete_flight(flight_id)
                print("Flight deleted successfully.")

            elif choice == '4':
                reservation_id = input("Enter reservation ID: ")
                passenger_name = input("Enter passenger name: ")
                flight_id = input("Enter flight ID: ")
                seat_number = input("Enter seat number: ")
                reservation = Reservation(reservation_id, passenger_name, flight_id, seat_number)
                system.add_reservation(reservation)
                print("Reservation added successfully.")

            elif choice == '5':
                reservation_id = input("Enter reservation ID to update: ")
                passenger_name = input("Enter new passenger name (leave blank to keep current): ")
                flight_id = input("Enter new flight ID (leave blank to keep current): ")
                seat_number = input("Enter new seat number (leave blank to keep current): ")
                kwargs = {
                    "passenger_name": passenger_name if passenger_name else None,
                    "flight_id": flight_id if flight_id else None,
                    "seat_number": seat_number if seat_number else None
                }
                system.update_reservation(reservation_id, **{k: v for k, v in kwargs.items() if v is not None})
                print("Reservation updated successfully.")

            elif choice == '6':
                reservation_id = input("Enter reservation ID to cancel: ")
                system.cancel_reservation(reservation_id)
                print("Reservation cancelled successfully.")

            elif choice == '7':
                flight_id = input("Enter flight ID to list passengers: ")
                passengers = system.get_passengers_on_flight(flight_id)
                if passengers:
                    print("Passengers on flight:")
                    for passenger in passengers:
                        print(passenger)
                else:
                    print("No passengers found for this flight.")

            elif choice == '8':
                print("Exiting the system.")
                break

            else:
                print("Invalid choice. Please try again.")
        
        except ValueError as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
