-- Create the database
CREATE DATABASE AirlineReservationSystem;

-- Use the created database
USE AirlineReservationSystem;

-- Create the Flights table
CREATE TABLE Flights (
    flight_id INT PRIMARY KEY,
    airline VARCHAR(100),
    destination VARCHAR(100),
    departure_time DATETIME,
    available_seats INT
);

-- Create the Passengers table
CREATE TABLE Passengers (
    passenger_id INT PRIMARY KEY,
    name VARCHAR(100),
    contact_info VARCHAR(100)
);

-- Create the Reservations table
CREATE TABLE Reservations (
    reservation_id INT PRIMARY KEY,
    passenger_id INT,
    flight_id INT,
    seat_number VARCHAR(10),
    reservation_date DATE,
    FOREIGN KEY (passenger_id) REFERENCES Passengers(passenger_id),
    FOREIGN KEY (flight_id) REFERENCES Flights(flight_id)
);
-- Insert values into Flights table
INSERT INTO Flights (flight_id, airline, destination, departure_time, available_seats)
VALUES 
(1, 'Airline A', 'New York', '2024-08-01 10:00:00', 50),
(2, 'Airline B', 'Los Angeles', '2024-08-01 15:00:00', 60),
(3, 'Airline C', 'Chicago', '2024-08-02 09:00:00', 70),
(4, 'Airline D', 'Miami', '2024-08-02 14:00:00', 80),
(5, 'Airline E', 'Dallas', '2024-08-03 18:00:00', 90);

-- Insert values into Passengers table
INSERT INTO Passengers (passenger_id, name, contact_info)
VALUES 
(1, 'John Doe', 'john.doe@example.com'),
(2, 'Jane Smith', 'jane.smith@example.com'),
(3, 'Alice Johnson', 'alice.johnson@example.com'),
(4, 'Bob Brown', 'bob.brown@example.com'),
(5, 'Charlie Davis', 'charlie.davis@example.com');

-- Insert values into Reservations table
INSERT INTO Reservations (reservation_id, passenger_id, flight_id, seat_number, reservation_date)
VALUES 
(1, 1, 1, 'A1', '2024-07-15'),
(2, 2, 1, 'A2', '2024-07-16'),
(3, 3, 2, 'B1', '2024-07-17'),
(4, 4, 3, 'C1', '2024-07-18'),
(5, 5, 4, 'D1', '2024-07-19'),
(6, 1, 5, 'E1', '2024-07-20'),
(7, 2, 3, 'C2', '2024-07-21'),
(8, 3, 4, 'D2', '2024-07-22'),
(9, 4, 2, 'B2', '2024-07-23'),
(10, 5, 1, 'A3', '2024-07-24');

SELECT 
    flight_id, 
    COUNT(*) AS total_seats_booked
FROM 
    Reservations
GROUP BY 
    flight_id;
    
SELECT 
    p.name AS passenger_name, 
    f.flight_id, 
    f.airline, 
    f.destination, 
    f.departure_time
FROM 
    Passengers p
JOIN 
    Reservations r ON p.passenger_id = r.passenger_id
JOIN 
    Flights f ON r.flight_id = f.flight_id;

SELECT 
    f.flight_id, 
    f.airline, 
    f.destination, 
    f.departure_time, 
    f.available_seats
FROM 
    Flights f
LEFT JOIN 
    Reservations r ON f.flight_id = r.flight_id
WHERE 
    r.reservation_id IS NULL;

SELECT 
    p.name AS passenger_name, 
    COUNT(r.flight_id) AS flights_booked
FROM 
    Passengers p
JOIN 
    Reservations r ON p.passenger_id = r.passenger_id
GROUP BY 
    p.name
HAVING 
    COUNT(r.flight_id) > 3;

SELECT 
    flight_id, 
    airline, 
    destination, 
    departure_time, 
    available_seats
FROM 
    Flights
WHERE 
    available_seats < 5;

