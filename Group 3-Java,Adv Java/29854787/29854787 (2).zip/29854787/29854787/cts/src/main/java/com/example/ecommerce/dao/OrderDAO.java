package com.example.ecommerce.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.ecommerce.model.Order;

public class OrderDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/ecommerce";
    private String jdbcUsername = "root";
    private String jdbcPassword = "password";

    private static final String INSERT_ORDER_SQL = "INSERT INTO `order`" +
            "  (customer_id, product_id, quantity, order_date, status) VALUES " +
            " (?, ?, ?, ?, ?);";

    private static final String SELECT_ORDER_BY_ID = "select order_id, customer_id, product_id, quantity, order_date, status from `order` where order_id =?";
    private static final String SELECT_ALL_ORDERS = "select * from `order`";
    private static final String DELETE_ORDER_SQL = "delete from `order` where order_id = ?;";
    private static final String UPDATE_ORDER_SQL = "update `order` set customer_id = ?, product_id= ?, quantity =?, order_date =?, status =? where order_id = ?;";

    public OrderDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void addOrder(Order order) throws SQLException {
        try (Connection connection = getConnection(); 
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ORDER_SQL)) {
            preparedStatement.setInt(1, order.getCustomerId());
            preparedStatement.setInt(2, order.getProductId());
            preparedStatement.setInt(3, order.getQuantity());
            preparedStatement.setDate(4, Date.valueOf(order.getOrderDate()));
            preparedStatement.setString(5, order.getStatus());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Order viewOrder(int orderId) {
        Order order = null;
        try (Connection connection = getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ORDER_BY_ID);) {
            preparedStatement.setInt(1, orderId);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int customerId = rs.getInt("customer_id");
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");
                Date orderDate = rs.getDate("order_date");
                String status = rs.getString("status");
                order = new Order(orderId, customerId, productId, quantity, orderDate.toLocalDate(), status);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return order;
    }

    public List<Order> selectAllOrders() {
        List<Order> orders = new ArrayList<>();
        try (Connection connection = getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_ORDERS);) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int orderId = rs.getInt("order_id");
                int customerId = rs.getInt("customer_id");
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");
                Date orderDate = rs.getDate("order_date");
                String status = rs.getString("status");
                orders.add(new Order(orderId, customerId, productId, quantity, orderDate.toLocalDate(), status));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return orders;
    }

    public boolean deleteOrder(int orderId) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(DELETE_ORDER_SQL);) {
            statement.setInt(1, orderId);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateOrder(Order order) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(UPDATE_ORDER_SQL);) {
            statement.setInt(1, order.getCustomerId());
            statement.setInt(2, order.getProductId());
            statement.setInt(3, order.getQuantity());
            statement.setDate(4, Date.valueOf(order.getOrderDate()));
            statement.setString(5, order.getStatus());
            statement.setInt(6, order.getOrderId());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
