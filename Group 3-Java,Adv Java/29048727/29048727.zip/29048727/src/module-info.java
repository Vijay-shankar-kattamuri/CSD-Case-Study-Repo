/**
 * 
 */
/**
 * 
 */
module Customer_Electronic_Store_Management_System {
	requires java.sql;
}