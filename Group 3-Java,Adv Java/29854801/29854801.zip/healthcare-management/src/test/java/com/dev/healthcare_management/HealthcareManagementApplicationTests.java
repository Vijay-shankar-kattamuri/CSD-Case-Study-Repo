package com.dev.healthcare_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
