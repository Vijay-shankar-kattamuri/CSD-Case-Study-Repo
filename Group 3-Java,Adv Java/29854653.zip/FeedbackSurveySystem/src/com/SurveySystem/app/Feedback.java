package com.SurveySystem.app;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Feedback {
    private int feedbackId;
    private int customerId;
    private Date feedbackDate;
    private String feedbackText;
    private int rating;


    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public Date getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(Date feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    public String getFeedbackText() {
        return feedbackText;
    }

    public void setFeedbackText(String feedbackText) {
        this.feedbackText = feedbackText;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

   
    public void insertFeedback() {
        String sql = "INSERT INTO feedback (customer_id, feedback_date, feedback_text, rating) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, this.customerId);
            statement.setDate(2,new java.sql.Date(this.feedbackDate.getDate())); 
            statement.setString(3, this.feedbackText);
            statement.setInt(4, this.rating);
            statement.executeUpdate();
            System.out.println("Feedback inserted successfully.");
        } catch (SQLException e) {
            System.err.println("Error inserting feedback: " + e.getMessage());
        }
    }

  
    public void updateFeedback() {
        String sql = "UPDATE feedback SET feedback_text = ?, rating = ? WHERE feedback_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, this.feedbackText);
            statement.setInt(2, this.rating);
            statement.setInt(3, this.feedbackId);
            statement.executeUpdate();
            System.out.println("Feedback updated successfully.");
        } catch (SQLException e) {
            System.err.println("Error updating feedback: " + e.getMessage());
        }
    }

    
    public static void deleteFeedback(int feedbackId) {
        String sql = "DELETE FROM feedback WHERE feedback_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, feedbackId);
            statement.executeUpdate();
            System.out.println("Feedback deleted successfully.");
        } catch (SQLException e) {
            System.err.println("Error deleting feedback: " + e.getMessage());
        }
    }

    public static Feedback getFeedback(int feedbackId) {
        String sql = "SELECT * FROM feedback WHERE feedback_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, feedbackId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Feedback feedback = new Feedback();
                feedback.setFeedbackId(resultSet.getInt("feedback_id"));
                feedback.setCustomerId(resultSet.getInt("customer_id"));
                feedback.setFeedbackDate(resultSet.getDate("feedback_date"));
                feedback.setFeedbackText(resultSet.getString("feedback_text"));
                feedback.setRating(resultSet.getInt("rating"));
                return feedback;
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving feedback: " + e.getMessage());
        }
        return null;
    }
}

