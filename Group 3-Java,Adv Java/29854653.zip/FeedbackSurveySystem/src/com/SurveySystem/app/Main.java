package com.SurveySystem.app;

import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;

public class Main {
	
	private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Manage Customers");
            System.out.println("2. Manage Feedback");
            System.out.println("3. Manage Surveys");
            System.out.println("4. Manage Survey Responses");
            System.out.println("5. Analysis and Reporting");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

	            switch (choice) {
	                case 1:
	                	manageCustomers();
	                    break;
	                case 2:
	                    manageFeedback();
	                    break;
	                case 3:
	                    manageSurveys();
	                    break;
	                case 4:
	                	manageSurveyResponses();
	                    break;
	                case 5:
	                    analyzeAndReport();
	                    break;
	                case 6:
	                    System.exit(0);
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }
	    }
	 
	 private static void manageCustomers() {
	        System.out.println("Customer Management:");
	        System.out.println("1. Insert New Customer");
	        System.out.println("2. Update Customer Details");
	        System.out.println("3. Delete Customer");
	        System.out.print("Enter your choice: ");
	        int customerChoice = scanner.nextInt();
	        scanner.nextLine(); 

	        switch (customerChoice) {
	            case 1:
	                insertCustomer();
	                break;
	            case 2:
	                updateCustomer();
	                break;
	            case 3:
	                deleteCustomer();
	                break;
	            default:
	                System.out.println("Invalid choice. Please try again.");
	        }
	    }

	    private static void insertCustomer() {
	        System.out.print("Enter customer name: ");
	        String customerName = scanner.nextLine();
	        System.out.print("Enter customer email: ");
	        String customerEmail = scanner.nextLine();

	        Customer newCustomer = new Customer(customerName, customerEmail);
	        newCustomer.insert();
	    }

	    private static void updateCustomer() {
	        System.out.print("Enter customer ID to update: ");
	        int customerId = scanner.nextInt();
	        scanner.nextLine(); 

	        Customer customerToUpdate = Customer.getCustomer(customerId);
	        if (customerToUpdate != null) {
	            System.out.print("Enter new customer name: ");
	            String newCustomerName = scanner.nextLine();
	            System.out.print("Enter new customer email: ");
	            String newCustomerEmail = scanner.nextLine();

	            customerToUpdate.setCustomerName(newCustomerName);
	            customerToUpdate.setCustomerEmail(newCustomerEmail);
	            customerToUpdate.update();
	        } else {
	            System.out.println("Customer not found.");
	        }
	    }

	    private static void deleteCustomer() {
	        System.out.print("Enter customer ID to delete: ");
	        int customerId = scanner.nextInt();
	        scanner.nextLine(); 

	        Customer customerToDelete = Customer.getCustomer(customerId);
	        if (customerToDelete != null) {
	            customerToDelete.delete();
	        } else {
	            System.out.println("Customer not found.");
	        }
	    }
	 
	    private static void manageFeedback() {
	        System.out.println("Feedback Management:");
	        System.out.println("1. Insert New Feedback");
	        System.out.println("2. View Feedback");
	        System.out.println("3. Update Feedback");
	        System.out.println("4. Delete Feedback");
	        System.out.print("Enter your choice: ");
	        int feedbackChoice = scanner.nextInt();
	        scanner.nextLine(); 

	        switch (feedbackChoice) {
	            case 1:
	                insertFeedback();
	                break;
	            case 2:
	                viewFeedback();
	                break;
	            case 3:
	                updateFeedback();
	                break;
	            case 4:
	                deleteFeedback();
	                break;
	            default:
	                System.out.println("Invalid choice. Please try again.");
	        }
	    }

	    private static void insertFeedback() {
	        System.out.print("Enter customer ID: ");
	        int customerId = scanner.nextInt();
	        scanner.nextLine(); 
	       
	        Customer customer = Customer.getCustomer(customerId);
	        if (customer == null) {
	            System.out.println("Customer not found. Please enter customer details.");
	            insertCustomer();
	            customer = Customer.getCustomer(customerId); 
	        }

	        System.out.print("Enter feedback text: ");
	        String feedbackText = scanner.nextLine();
	        System.out.print("Enter rating: ");
	        int rating = scanner.nextInt();
	        scanner.nextLine();

	        Feedback feedback = new Feedback();
	        feedback.setCustomerId(customerId);
	        feedback.setFeedbackDate(new java.sql.Date(System.currentTimeMillis())); 
	        feedback.setFeedbackText(feedbackText);
	        feedback.setRating(rating);
	        feedback.insertFeedback();
	    }

	    private static void viewFeedback() {
	        System.out.print("Enter feedback ID to view: ");
	        int feedbackId = scanner.nextInt();
	        scanner.nextLine(); 

	        Feedback feedback = Feedback.getFeedback(feedbackId);
	        if (feedback != null) {
	            System.out.println("Feedback ID: " + feedback.getFeedbackId());
	            System.out.println("Customer ID: " + feedback.getCustomerId());
	            System.out.println("Feedback Date: " + feedback.getFeedbackDate());
	            System.out.println("Feedback Text: " + feedback.getFeedbackText());
	            System.out.println("Rating: " + feedback.getRating());
	        } else {
	            System.out.println("Feedback not found.");
	        }
	    }

	    private static void updateFeedback() {
	        System.out.print("Enter feedback ID to update: ");
	        int feedbackId = scanner.nextInt();
	        scanner.nextLine(); 

	        Feedback feedbackToUpdate = Feedback.getFeedback(feedbackId);
	        if (feedbackToUpdate != null) {
	            System.out.print("Enter new feedback text: ");
	            String newFeedbackText = scanner.nextLine();
	            System.out.print("Enter new rating: ");
	            int newRating = scanner.nextInt();
	            scanner.nextLine();

	            feedbackToUpdate.setFeedbackText(newFeedbackText);
	            feedbackToUpdate.setRating(newRating);
	            feedbackToUpdate.updateFeedback();
	        } else {
	            System.out.println("Feedback not found.");
	        }
	    }

	    private static void deleteFeedback() {
	        System.out.print("Enter feedback ID to delete: ");
	        int feedbackId = scanner.nextInt();
	        scanner.nextLine(); 

	        Feedback.deleteFeedback(feedbackId);
	    }    
	        
	        private static void manageSurveys() {
	            System.out.println("1. Create new survey");
	            System.out.println("2. View survey details");
	            System.out.println("3. Update survey information");
	            System.out.println("4. Delete survey");
	            System.out.print("Enter your choice: ");
	            int surveyChoice = scanner.nextInt();
	            scanner.nextLine(); 

	            switch (surveyChoice) {
	                case 1:
	                    insertSurvey();
	                    break;
	                case 2:
	                	viewSurvey();
	                    break;
	                case 3:
	                	updateSurvey();
	                    break;
	                    
	                case 4:
	                    deleteSurvey(); 
	                    break;    
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }

	        private static void insertSurvey() {
	            System.out.print("Enter survey name: ");
	            String surveyName = scanner.nextLine();
	            System.out.print("Enter survey description: ");
	            String surveyDescription = scanner.nextLine();
	            System.out.print("Enter survey status: ");
	            String surveyStatus = scanner.nextLine();

	            Survey survey = new Survey();
	            survey.setSurveyName(surveyName);
	            survey.setSurveyDescription(surveyDescription);
	            survey.setStatus(surveyStatus);
	            survey.insertSurvey();
	        }
	        
	        private static void viewSurvey() {
	        	System.out.print("Enter survey ID: ");
	        	int surveyId = scanner.nextInt();
	        	scanner.nextLine();
	        	Survey sv = Survey.getSurvey(surveyId);
	        	if (sv != null) {
	        		System.out.println(sv);
	        	} else {
	        		System.out.println("Survey not found.");
	        	}
	        }

	        private static void updateSurvey() {
	            System.out.print("Enter survey ID to update: ");
	            int surveyId = scanner.nextInt();
	            scanner.nextLine(); // Consume newline

	            Survey surveyToUpdate = Survey.getSurvey(surveyId);
	            if (surveyToUpdate != null) {
	                System.out.print("Enter new survey name: ");
	                String newSurveyName = scanner.nextLine();
	                System.out.print("Enter new survey description: ");
	                String newSurveyDescription = scanner.nextLine();
	                System.out.print("Enter new survey status: ");
	                String newSurveyStatus = scanner.nextLine();

	                surveyToUpdate.setSurveyName(newSurveyName);
	                surveyToUpdate.setSurveyDescription(newSurveyDescription);
	                surveyToUpdate.setStatus(newSurveyStatus);
	                surveyToUpdate.updateSurvey();
	            } else {
	                System.out.println("Survey not found.");
	            }
	        }

	        private static void deleteSurvey() {
	            System.out.print("Enter survey ID to delete: ");
	            int surveyId = scanner.nextInt();
	            scanner.nextLine(); 

	            Survey.deleteSurvey(surveyId);
	        }
	        
	        private static void manageSurveyResponses() {
	            System.out.println("Survey Response Management:");
	            System.out.println("1. Insert New Survey Response");
	            System.out.println("2. Update Survey Response");
	            System.out.println("3. Delete Survey Response");
	            System.out.print("Enter your choice: ");
	            int responseChoice = scanner.nextInt();
	            scanner.nextLine(); // Consume newline

	            switch (responseChoice) {
	                case 1:
	                    insertSurveyResponse();
	                    break;
	                case 2:
	                    updateSurveyResponse();
	                    break;
	                case 3:
	                    deleteSurveyResponse();
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }

	        private static void insertSurveyResponse() {
	            System.out.print("Enter survey ID: ");
	            int surveyId = scanner.nextInt();
	            scanner.nextLine(); 

	            System.out.print("Enter customer ID: ");
	            int customerId = scanner.nextInt();
	            scanner.nextLine(); 

	            System.out.print("Enter response text: ");
	            String responseText = scanner.nextLine();

	            SurveyResponse response = new SurveyResponse();
	            response.setSurveyId(surveyId);
	            response.setCustomerId(customerId);
	            response.setResponseDate(new java.sql.Date(System.currentTimeMillis())); 
	            response.setResponseText(responseText);
	            response.insertResponse();
	        }

	        private static void updateSurveyResponse() {
	            System.out.print("Enter response ID to update: ");
	            int responseId = scanner.nextInt();
	            scanner.nextLine(); 

	            SurveyResponse responseToUpdate = SurveyResponse.getResponse(responseId);
	            if (responseToUpdate != null) {
	                System.out.print("Enter new response text: ");
	                String newResponseText = scanner.nextLine();
	                responseToUpdate.setResponseText(newResponseText);
	                responseToUpdate.updateResponse();
	            } else {
	                System.out.println("Survey response not found.");
	            }
	        }

	        private static void deleteSurveyResponse() {
	            System.out.print("Enter response ID to delete: ");
	            int responseId = scanner.nextInt();
	            scanner.nextLine(); 

	            SurveyResponse.deleteResponse(responseId);
	        }
	        
	        private static void analyzeAndReport() {
	            System.out.println("1. Analyze Feedback");
	            System.out.println("2. Analyze Survey Responses");
	            System.out.println("3. Export Reports to CSV");
	            System.out.print("Enter your choice: ");
	            int choice = scanner.nextInt();
	            scanner.nextLine(); 

	            switch (choice) {
	                case 1:
	                    analyzeFeedback();
	                    break;
	                case 2:
	                    analyzeSurveyResponses();
	                    break;
	                case 3:
	                    exportReportsToCSV();
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }

	        private static void analyzeFeedback() {
	            try (Connection conn = DBConnection.getConnection();
	                 PreparedStatement statement = conn.prepareStatement("SELECT COUNT(*) AS total_feedback, AVG(rating) AS avg_rating FROM Feedback");
	                 ResultSet resultSet = statement.executeQuery()) {

	                if (resultSet.next()) {
	                    int totalFeedback = resultSet.getInt("total_feedback");
	                    double avgRating = resultSet.getDouble("avg_rating");

	                    System.out.println("Total Feedback: " + totalFeedback);
	                    System.out.println("Average Rating: " + avgRating);
	                }
	            } catch (SQLException e) {
	                System.err.println("Error analyzing feedback: " + e.getMessage());
	            }
	        }

	        private static void analyzeSurveyResponses() {
	            try (Connection conn = DBConnection.getConnection();
	                 PreparedStatement statement = conn.prepareStatement("SELECT survey_id, COUNT(*) AS total_responses FROM Survey_Response GROUP BY survey_id");
	                 ResultSet resultSet = statement.executeQuery()) {

	                while (resultSet.next()) {
	                    int surveyId = resultSet.getInt("survey_id");
	                    int totalResponses = resultSet.getInt("total_responses");

	                    System.out.println("Survey ID: " + surveyId + ", Total Responses: " + totalResponses);
	                }
	            } catch (SQLException e) {
	                System.err.println("Error analyzing survey responses: " + e.getMessage());
	            }
	        }

	        private static void exportReportsToCSV() {
	            try (Connection conn = DBConnection.getConnection();
	                 PreparedStatement statement = conn.prepareStatement("SELECT * FROM Feedback");
	                 ResultSet resultSet = statement.executeQuery();
	                 FileWriter writer = new FileWriter("feedback_report.csv")) {

	                // Write CSV header
	                writer.append("Feedback ID, Customer ID, Feedback Date, Feedback Text, Rating\n");

	                // Write data rows
	                while (resultSet.next()) {
	                    int feedbackId = resultSet.getInt("feedback_id");
	                    int customerId = resultSet.getInt("customer_id");
	                    String feedbackDate = resultSet.getString("feedback_date");
	                    String feedbackText = resultSet.getString("feedback_text");
	                    int rating = resultSet.getInt("rating");

	                    writer.append(String.format("%d, %d, %s, %s, %d\n", feedbackId, customerId, feedbackDate, feedbackText, rating));
	                }

	                System.out.println("CSV report generated successfully.");
	            } catch (SQLException | IOException e) {
	                System.err.println("Error exporting reports: " + e.getMessage());
	            }  

	        }
}
	        
	  
