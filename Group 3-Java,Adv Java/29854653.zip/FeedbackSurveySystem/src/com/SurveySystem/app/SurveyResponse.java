package com.SurveySystem.app;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SurveyResponse {
    private int responseId;
    private int surveyId;
    private int customerId;
    private Date responseDate;
    private String responseText;



    public int getResponseId() {
        return responseId;
    }

    public void setResponseId(int responseId) {
        this.responseId = responseId;
    }

    public int getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(int surveyId) {
        this.surveyId = surveyId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public Date getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Date responseDate) {
        this.responseDate = responseDate;
    }

    public String getResponseText() {
        return responseText;
    }

    public void setResponseText(String responseText) {
        this.responseText = responseText;
    }



    public void insertResponse() {
        String sql = "INSERT INTO Survey_Response (survey_id, customer_id, response_date, response_text) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, this.surveyId);
            stmt.setInt(2, this.customerId);
            stmt.setDate(3, this.responseDate);
            stmt.setString(4, this.responseText);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error inserting survey response: " + e.getMessage());
        }
    }

    public static SurveyResponse getResponse(int responseId) {
        String sql = "SELECT * FROM Survey_Response WHERE response_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, responseId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                SurveyResponse response = new SurveyResponse();
                response.setResponseId(rs.getInt("response_id"));
                response.setSurveyId(rs.getInt("survey_id"));
                response.setCustomerId(rs.getInt("customer_id"));
                response.setResponseDate(rs.getDate("response_date"));
                response.setResponseText(rs.getString("response_text"));
                return response;
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving survey response: " + e.getMessage());
        }
        return null;
    }

    public void updateResponse() {
        String sql = "UPDATE Survey_Response SET survey_id = ?, customer_id = ?, response_date = ?, response_text = ? WHERE response_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, this.surveyId);
            stmt.setInt(2, this.customerId);
            stmt.setDate(3, this.responseDate);
            stmt.setString(4, this.responseText);
            stmt.setInt(5, this.responseId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating survey response: " + e.getMessage());
        }
    }

    public static void deleteResponse(int responseId) {
        String sql = "DELETE FROM Survey_Response WHERE response_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, responseId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error deleting survey response: " + e.getMessage());
        }
    }
}

