package com.SurveySystem.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Survey {
    private int surveyId;
    private String surveyName;
    private String surveyDescription;
    private String status;

   
    public int getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(int surveyId) {
        this.surveyId = surveyId;
    }

    public String getSurveyName() {
        return surveyName;
    }

    public void setSurveyName(String surveyName) {
        this.surveyName = surveyName;
    }

    public String getSurveyDescription() {
        return surveyDescription;
    }

    public void setSurveyDescription(String surveyDescription) {
        this.surveyDescription = surveyDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

  
    public void insertSurvey() {
        String sql = "INSERT INTO Survey (survey_name, survey_description, status) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, this.getSurveyName());
            statement.setString(2, this.getSurveyDescription());
            statement.setString(3, this.getStatus());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error inserting survey: " + e.getMessage());
        }
    }

    public void updateSurvey() {
        String sql = "UPDATE Survey SET survey_name = ?, survey_description = ?, status = ? WHERE survey_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, this.getSurveyName());
            statement.setString(2, this.getSurveyDescription());
            statement.setString(3, this.getStatus());
            statement.setInt(4, this.getSurveyId());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating survey: " + e.getMessage());
        }
    }

    public static void deleteSurvey(int surveyId) {
        String sql = "DELETE FROM Survey WHERE survey_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, surveyId);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error deleting survey: " + e.getMessage());
        }
    }

    public static Survey getSurvey(int surveyId) {
        String sql = "SELECT * FROM Survey WHERE survey_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, surveyId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Survey survey = new Survey();
                    survey.setSurveyId(resultSet.getInt("survey_id"));
                    survey.setSurveyName(resultSet.getString("survey_name"));
                    survey.setSurveyDescription(resultSet.getString("survey_description"));
                    survey.setStatus(resultSet.getString("status"));
                    return survey;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error reading survey: " + e.getMessage());
        }
        return null;
    }

    @Override
    public String toString() {
        return "Survey{" +
                "surveyId=" + surveyId +
                ", surveyName='" + surveyName + '\'' +
                ", surveyDescription='" + surveyDescription + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}

