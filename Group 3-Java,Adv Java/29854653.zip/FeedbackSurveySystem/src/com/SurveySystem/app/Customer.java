package com.SurveySystem.app;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Customer {
    private int customerId; 
    private String customerName;
    private String customerEmail;

    // Constructor
    public Customer(String customerName, String customerEmail) {
        this.customerName = customerName;
        this.customerEmail = customerEmail;
    }

    
    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    
    public void insert() {
        String sql = "INSERT INTO customer (customer_name, customer_email) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, this.customerName);
            statement.setString(2, this.customerEmail);
            statement.executeUpdate();
            System.out.println("Customer inserted successfully.");
        } catch (SQLException e) {
            System.err.println("Error inserting customer: " + e.getMessage());
        }
    }


    public void update() {
        String sql = "UPDATE customer SET customer_name = ?, customer_email = ? WHERE customer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, this.customerName);
            statement.setString(2, this.customerEmail);
            statement.setInt(3, this.customerId);
            statement.executeUpdate();
            System.out.println("Customer updated successfully.");
        } catch (SQLException e) {
            System.err.println("Error updating customer: " + e.getMessage());
        }
    }


    public void delete() {
        String sql = "DELETE FROM customer WHERE customer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, this.customerId);
            statement.executeUpdate();
            System.out.println("Customer deleted successfully.");
        } catch (SQLException e) {
            System.err.println("Error deleting customer: " + e.getMessage());
        }
    }

    
    public static Customer getCustomer(int customerId) {
        String sql = "SELECT * FROM customer WHERE customer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, customerId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String customerName = resultSet.getString("customer_name");
                String customerEmail = resultSet.getString("customer_email");
                Customer customer = new Customer(customerName, customerEmail);
                customer.customerId = customerId; 
                return customer;
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving customer: " + e.getMessage());
        }
        return null; 
    }
}


