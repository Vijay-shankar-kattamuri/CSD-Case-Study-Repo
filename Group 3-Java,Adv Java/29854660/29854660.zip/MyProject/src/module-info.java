/**
 * 
 */
/**
 * 
 */
module MyProject {
	requires java.sql;
}