CREATE database research_Lab;
USE research_Lab;

CREATE TABLE Researchers (
    researcher_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone_number VARCHAR(15),
    specialization VARCHAR(100)
);

CREATE TABLE Experiments (
    experiment_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE
);

CREATE TABLE Samples (
    sample_id INT AUTO_INCREMENT PRIMARY KEY,
    experiment_id INT,
    name VARCHAR(150) NOT NULL,
    type VARCHAR(50),
    quantity INT
    -- FOREIGN KEY (experiment_id) REFERENCES Experiments(experiment_id)
);

