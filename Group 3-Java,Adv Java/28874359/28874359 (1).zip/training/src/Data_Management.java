import java.sql.*;
import java.util.Scanner;

public class Data_Management {
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    // Load the MySQL JDBC driver
    private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/research_Lab";
    private static final String USER = "root";
    private static final String PASS = "Priyanshu";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        while (true) {
            System.out.println("Life Sciences Lab Management System");
            System.out.println("1. Manage Researchers");
            System.out.println("2. Manage Experiments");
            System.out.println("3. Manage Samples");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    manageResearchers(sc);
                    break;
                case 2:
                    manageExperiments(sc);
                    break;
                case 3:
                    manageSamples(sc);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageResearchers(Scanner scanner) {
        while (true) {
            System.out.println("Manage Researchers");
            System.out.println("1. Add Researcher");
            System.out.println("2. View Researchers");
            System.out.println("3. Update Researcher");
            System.out.println("4. Delete Researcher");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addResearcher(scanner);
                    break;
                case 2:
                    viewResearchers();
                    break;
                case 3:
                    updateResearcher(scanner);
                    break;
                case 4:
                    deleteResearcher(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageExperiments(Scanner scanner) {
        while (true) {
            System.out.println("Manage Experiments");
            System.out.println("1. Add Experiment");
            System.out.println("2. View Experiments");
            System.out.println("3. Update Experiment");
            System.out.println("4. Delete Experiment");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addExperiment(scanner);
                    break;
                case 2:
                    viewExperiments();
                    break;
                case 3:
                    updateExperiment(scanner);
                    break;
                case 4:
                    deleteExperiment(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageSamples(Scanner scanner) {
        while (true) {
            System.out.println("Manage Samples");
            System.out.println("1. Add Sample");
            System.out.println("2. View Samples");
            System.out.println("3. Update Sample");
            System.out.println("4. Delete Sample");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addSample(scanner);
                    break;
                case 2:
                    viewSamples();
                    break;
                case 3:
                    updateSample(scanner);
                    break;
                case 4:
                    deleteSample(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addResearcher(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Researchers (name, email, phone_number, specialization) VALUES (?, ?, ?, ?)")) {

            System.out.print("Enter Researcher Name: ");
            scanner.nextLine(); // Consume newline
            String name = scanner.nextLine();
            System.out.print("Enter Researcher Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter Researcher Phone Number: ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter Researcher Specialization: ");
            String specialization = scanner.nextLine();

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, specialization);
            pstmt.executeUpdate();

            System.out.println("Researcher added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewResearchers() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Researchers")) {

            while (rs.next()) {
                int id = rs.getInt("researcher_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phoneNumber = rs.getString("phone_number");
                String specialization = rs.getString("specialization");

                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email + ", Phone: " + phoneNumber + ", Specialization: " + specialization);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateResearcher(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Researchers SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE researcher_id = ?")) {

            System.out.print("Enter Researcher ID to Update: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter New Researcher Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter New Researcher Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter New Researcher Phone Number: ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter New Researcher Specialization: ");
            String specialization = scanner.nextLine();

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, specialization);
            pstmt.setInt(5, id);
            pstmt.executeUpdate();

            System.out.println("Researcher updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteResearcher(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Researchers WHERE researcher_id = ?")) {

            System.out.print("Enter Researcher ID to Delete: ");
            int id = scanner.nextInt();

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

            System.out.println("Researcher deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addExperiment(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Experiments (name, description, start_date, end_date) VALUES (?, ?, ?, ?)")) {

            System.out.print("Enter Experiment Name: ");
            scanner.nextLine(); // Consume newline
            String name = scanner.nextLine();
            System.out.print("Enter Experiment Description: ");
            String description = scanner.nextLine();
            System.out.print("Enter Start Date (YYYY-MM-DD): ");
            String startDate = scanner.nextLine();
            System.out.print("Enter End Date (YYYY-MM-DD): ");
            String endDate = scanner.nextLine();

            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setDate(3, Date.valueOf(startDate));
            pstmt.setDate(4, Date.valueOf(endDate));
            pstmt.executeUpdate();

            System.out.println("Experiment added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewExperiments() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Experiments")) {

            while (rs.next()) {
                int id = rs.getInt("experiment_id");
                String name = rs.getString("name");
                String description = rs.getString("description");
                Date startDate = rs.getDate("start_date");
                Date endDate = rs.getDate("end_date");

                System.out.println("ID: " + id + ", Name: " + name + ", Description: " + description + ", Start Date: " + startDate + ", End Date: " + endDate);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateExperiment(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Experiments SET name = ?, description = ?, start_date = ?, end_date = ? WHERE experiment_id = ?")) {

            System.out.print("Enter Experiment ID to Update: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter New Experiment Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter New Experiment Description: ");
            String description = scanner.nextLine();
            System.out.print("Enter New Start Date (YYYY-MM-DD): ");
            String startDate = scanner.nextLine();
            System.out.print("Enter New End Date (YYYY-MM-DD): ");
            String endDate = scanner.nextLine();

            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setDate(3, Date.valueOf(startDate));
            pstmt.setDate(4, Date.valueOf(endDate));
            pstmt.setInt(5, id);
            pstmt.executeUpdate();

            System.out.println("Experiment updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteExperiment(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Experiments WHERE experiment_id = ?")) {

            System.out.print("Enter Experiment ID to Delete: ");
            int id = scanner.nextInt();

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

            System.out.println("Experiment deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addSample(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Samples (experiment_id, name, type, quantity) VALUES (?, ?, ?, ?)")) {

            System.out.print("Enter Experiment ID: ");
            int experimentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter Sample Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Sample Type: ");
            String type = scanner.nextLine();
            System.out.print("Enter Sample Quantity: ");
            int quantity = scanner.nextInt();

            pstmt.setInt(1, experimentId);
            pstmt.setString(2, name);
            pstmt.setString(3, type);
            pstmt.setInt(4, quantity);
            pstmt.executeUpdate();

            System.out.println("Sample added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewSamples() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Samples")) {

            while (rs.next()) {
                int id = rs.getInt("sample_id");
                int experimentId = rs.getInt("experiment_id");
                String name = rs.getString("name");
                String type = rs.getString("type");
                int quantity = rs.getInt("quantity");

                System.out.println("ID: " + id + ", Experiment ID: " + experimentId + ", Name: " + name + ", Type: " + type + ", Quantity: " + quantity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateSample(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Samples SET experiment_id = ?, name = ?, type = ?, quantity = ? WHERE sample_id = ?")) {

            System.out.print("Enter Sample ID to Update: ");
            int id = scanner.nextInt();
            System.out.print("Enter New Experiment ID: ");
            int experimentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter New Sample Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter New Sample Type: ");
            String type = scanner.nextLine();
            System.out.print("Enter New Sample Quantity: ");
            int quantity = scanner.nextInt();

            pstmt.setInt(1, experimentId);
            pstmt.setString(2, name);
            pstmt.setString(3, type);
            pstmt.setInt(4, quantity);
            pstmt.setInt(5, id);
            pstmt.executeUpdate();

            System.out.println("Sample updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteSample(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Samples WHERE sample_id = ?")) {

            System.out.print("Enter Sample ID to Delete: ");
            int id = scanner.nextInt();

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

            System.out.println("Sample deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
