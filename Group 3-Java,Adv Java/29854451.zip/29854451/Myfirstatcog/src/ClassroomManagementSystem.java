import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ClassroomManagementSystem {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            // Display the main menu
            System.out.println("---------------------------------------------------");
            System.out.println("Classroom Management System");
            System.out.println("1. Course Management");
            System.out.println("2. Student Management");
            System.out.println("3. Grade Management");
            System.out.println("4. Calculate CGPA");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            System.out.println("---------------------------------------------------");
            scanner.nextLine(); // consume newline

            // Database connection
            try {
                // Load MySQL JDBC driver
                Class.forName("com.mysql.jdbc.Driver");
                // Establish the connection
                Connection connection = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/course_management_system", "root", "Sumanth@1710");

                // Handle the user's choice
                switch (choice) {
                    case 1:
                        courseManagement(connection);
                        break;
                    case 2:
                        studentManagement(connection);
                        break;
                    case 3:
                        gradeManagement(connection);
                        break;
                    case 4:
                        calculateCGPA(connection);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        connection.close(); // Close the connection
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException | ClassNotFoundException e) {
                System.out.println("Error connecting to the database: " + e.getMessage());
            }
        }
    }

    // Course management menu
    private static void courseManagement(Connection connection) {
        System.out.println("Course Management");
        System.out.println("1. Add Course");
        System.out.println("2. View Course");
        System.out.println("3. Update Course");
        System.out.println("4. Delete Course");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                addCourse(connection);
                break;
            case 2:
                viewCourse(connection);
                break;
            case 3:
                updateCourse(connection);
                break;
            case 4:
                deleteCourse(connection);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    // Student management menu
    private static void studentManagement(Connection connection) {
        System.out.println("Student Management");
        System.out.println("1. Register Student");
        System.out.println("2. View Student");
        System.out.println("3. Update Student");
        System.out.println("4. Delete Student");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                registerStudent(connection);
                break;
            case 2:
                viewStudent(connection);
                break;
            case 3:
                updateStudent(connection);
                break;
            case 4:
                deleteStudent(connection);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    // Grade management menu
    private static void gradeManagement(Connection connection) {
        System.out.println("Grade Management");
        System.out.println("1. Assign Grade");
        System.out.println("2. View Grades");
        System.out.println("3. Update Grade");
        System.out.println("4. Remove Grade");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                assignGrade(connection);
                break;
            case 2:
                viewGrades(connection);
                break;
            case 3:
                updateGrade(connection);
                break;
            case 4:
                removeGrade(connection);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    // Add a new course
    private static void addCourse(Connection connection) {
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter course title: ");
        String title = scanner.nextLine();
        System.out.print("Enter course instructor: ");
        String instructor = scanner.nextLine();
        System.out.print("Enter course schedule: ");
        String schedule = scanner.nextLine();
        System.out.print("Enter course credits: ");
        int credits = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        String sql = "INSERT INTO Course (course_id, title, instructor, schedule, credits) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, courseId);
            statement.setString(2, title);
            statement.setString(3, instructor);
            statement.setString(4, schedule);
            statement.setInt(5, credits);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new course was inserted successfully!");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // View course details
    private static void viewCourse(Connection connection) {
        System.out.println("---------------------------------------------------");

        String sql = "SELECT * FROM Course";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet result = statement.executeQuery();
            boolean hasResults = false; // Track if any results are found
            while (result.next()) {
                hasResults = true; // Set to true if results are found
                System.out.println("Course ID: " + result.getInt("course_id"));
                System.out.println("Title: " + result.getString("title"));
                System.out.println("Instructor: " + result.getString("instructor"));
                System.out.println("Schedule: " + result.getString("schedule"));
                System.out.println("Credits: " + result.getInt("credits"));
                System.out.println("------------------------------------------------------");
            }
            if (!hasResults) {
                System.out.println("No courses found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Update course information
    private static void updateCourse(Connection connection) {
        System.out.print("Enter course ID to update: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new course title: ");
        String title = scanner.nextLine();
        System.out.print("Enter new course instructor: ");
        String instructor = scanner.nextLine();
        System.out.print("Enter new course schedule: ");
        String schedule = scanner.nextLine();
        System.out.print("Enter new course credits: ");
        int credits = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        String sql = "UPDATE Course SET title = ?, instructor = ?, schedule = ?, credits = ? WHERE course_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, title);
            statement.setString(2, instructor);
            statement.setString(3, schedule);
            statement.setInt(4, credits);
            statement.setInt(5, courseId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Course updated successfully!");
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Delete a course
    private static void deleteCourse(Connection connection) {
        System.out.print("Enter course ID to delete: ");
        int courseId = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        // Delete corresponding grades first
        String deleteGradesSql = "DELETE FROM Grade WHERE course_id = ?";
        String deleteCourseSql = "DELETE FROM Course WHERE course_id = ?";

        try (PreparedStatement deleteGradesStatement = connection.prepareStatement(deleteGradesSql);
             PreparedStatement deleteCourseStatement = connection.prepareStatement(deleteCourseSql)) {

            // Delete grades first
            deleteGradesStatement.setInt(1, courseId);
            deleteGradesStatement.executeUpdate();

            // Then delete the course
            deleteCourseStatement.setInt(1, courseId);
            int rowsDeleted = deleteCourseStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Course deleted successfully!");
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Register a new student
    private static void registerStudent(Connection connection) {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter student email: ");
        String email = scanner.nextLine();
        System.out.print("Enter student phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter student address: ");
        String address = scanner.nextLine();
        System.out.println("---------------------------------------------------");

        String sql = "INSERT INTO Student (student_id, name, email, phone_number, address) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, studentId);
            statement.setString(2, name);
            statement.setString(3, email);
            statement.setString(4, phoneNumber);
            statement.setString(5, address);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new student was registered successfully!");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // View student details
    private static void viewStudent(Connection connection) {
        System.out.println("---------------------------------------------------");

        String sql = "SELECT * FROM Student";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet result = statement.executeQuery();
            boolean hasResults = false; // Track if any results are found
            while (result.next()) {
                hasResults = true; // Set to true if results are found
                System.out.println("Student ID: " + result.getInt("student_id"));
                System.out.println("Name: " + result.getString("name"));
                System.out.println("Email: " + result.getString("email"));
                System.out.println("Phone Number: " + result.getString("phone_number"));
                System.out.println("Address: " + result.getString("address"));
                System.out.println("------------------------------------------------------");
            }
            if (!hasResults) {
                System.out.println("No students found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Update student information
    private static void updateStudent(Connection connection) {
        System.out.print("Enter student ID to update: ");
        int studentId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new student email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new student phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter new student address: ");
        String address = scanner.nextLine();
        System.out.println("---------------------------------------------------");

        String sql = "UPDATE Student SET name = ?, email = ?, phone_number = ?, address = ? WHERE student_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);
            statement.setString(4, address);
            statement.setInt(5, studentId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Student information updated successfully!");
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Delete a student
    private static void deleteStudent(Connection connection) {
        System.out.print("Enter student ID to delete: ");
        int studentId = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        // Delete corresponding grades first
        String deleteGradesSql = "DELETE FROM Grade WHERE student_id = ?";
        String deleteStudentSql = "DELETE FROM Student WHERE student_id = ?";

        try (PreparedStatement deleteGradesStatement = connection.prepareStatement(deleteGradesSql);
             PreparedStatement deleteStudentStatement = connection.prepareStatement(deleteStudentSql)) {

            // Delete grades first
            deleteGradesStatement.setInt(1, studentId);
            deleteGradesStatement.executeUpdate();

            // Then delete the student
            deleteStudentStatement.setInt(1, studentId);
            int rowsDeleted = deleteStudentStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Student deleted successfully!");
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Assign a grade to a student for a course
    private static void assignGrade(Connection connection) {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        System.out.print("Enter grade (0-100): ");
        int grade = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        String sql = "INSERT INTO Grade (student_id, course_id, grade) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, studentId);
            statement.setInt(2, courseId);
            statement.setInt(3, grade);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Grade assigned successfully!");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // View grades for all students
    private static void viewGrades(Connection connection) {
        System.out.println("---------------------------------------------------");

        String sql = "SELECT * FROM Grade";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet result = statement.executeQuery();
            boolean hasResults = false; // Track if any results are found
            while (result.next()) {
                hasResults = true; // Set to true if results are found
                System.out.println("Student ID: " + result.getInt("student_id"));
                System.out.println("Course ID: " + result.getInt("course_id"));
                System.out.println("Grade: " + result.getInt("grade"));
                System.out.println("------------------------------------------------------");
            }
            if (!hasResults) {
                System.out.println("No grades found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Update grade for a student in a course
    private static void updateGrade(Connection connection) {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        System.out.print("Enter new grade (0-100): ");
        int newGrade = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        String sql = "UPDATE Grade SET grade = ? WHERE student_id = ? AND course_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, newGrade);
            statement.setInt(2, studentId);
            statement.setInt(3, courseId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Grade updated successfully!");
            } else {
                System.out.println("Grade not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Remove grade for a student in a course
    private static void removeGrade(Connection connection) {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        String sql = "DELETE FROM Grade WHERE student_id = ? AND course_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, studentId);
            statement.setInt(2, courseId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Grade removed successfully!");
            } else {
                System.out.println("Grade not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Calculate CGPA for a student
    private static void calculateCGPA(Connection connection) {
        System.out.print("Enter student ID to calculate CGPA: ");
        int studentId = scanner.nextInt();
        System.out.println("---------------------------------------------------");

        // Calculate total marks and total subjects for the student
        String totalMarksSql = "SELECT SUM(grade) AS total_marks, COUNT(*) AS total_subjects FROM Grade WHERE student_id = ?";
        try (PreparedStatement totalMarksStatement = connection.prepareStatement(totalMarksSql)) {
            totalMarksStatement.setInt(1, studentId);
            ResultSet totalMarksResult = totalMarksStatement.executeQuery();
            if (totalMarksResult.next()) {
                int totalMarks = totalMarksResult.getInt("total_marks");
                int totalSubjects = totalMarksResult.getInt("total_subjects");

                // Calculate CGPA
                double cgpa = (double) totalMarks / totalSubjects / 10.0;

                System.out.println("CGPA for student with ID " + studentId + " is: " + cgpa);
            } else {
                System.out.println("Student not found or no grades found for the student.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}