package com.cts.DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cts.model.Delivery;
import com.cts.util.DatabaseConnection;

public class DeliveryDAO {
	
	public void addDelivery(Delivery delivery) throws SQLException {
        String sql = "INSERT INTO Delivery (parcel_id, customer_id, delivery_date, delivery_status, delivery_cost) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, delivery.getParcelID());
            pstmt.setInt(2, delivery.getCustomerID());
            pstmt.setDate(3, delivery.getDeliveryDate());
            pstmt.setString(4, delivery.getDeliveryStatus());
            pstmt.setDouble(5, delivery.getDeliveryCost());
            pstmt.executeUpdate();
        }
    }

    public List<Delivery> getAllDeliveries() throws SQLException {
        String sql = "SELECT * FROM Delivery";
        List<Delivery> deliveries = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
        	 PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery(sql)) {
            while (rs.next()) {
                Delivery delivery = new Delivery();
                delivery.setDeliveryID(rs.getInt("delivery_id"));
                delivery.setParcelID(rs.getInt("parcel_id"));
                delivery.setCustomerID(rs.getInt("customer_id"));
                delivery.setDeliveryDate(rs.getDate("delivery_date"));
                delivery.setDeliveryStatus(rs.getString("delivery_status"));
                delivery.setDeliveryCost(rs.getDouble("delivery_cost"));
                deliveries.add(delivery);
            }
        }
        return deliveries;
    }
    
    public double calculateDeliveryCost(int parcelID) throws SQLException {
        String sql = "SELECT weight FROM Parcel WHERE parcel_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, parcelID);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double weight = rs.getDouble("weight");
                    return 100 + (weight * 10);  
                } else {
                    throw new SQLException("Parcel not found with ID: " + parcelID);
                }
            }
        }
    }
    
    public Delivery getDeliveryById(int deliveryID) throws SQLException {
        String sql = "SELECT * FROM Delivery WHERE delivery_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, deliveryID);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Delivery delivery = new Delivery();
                    delivery.setDeliveryID(rs.getInt("delivery_id"));
                    delivery.setParcelID(rs.getInt("parcel_id"));
                    delivery.setCustomerID(rs.getInt("customer_id"));
                    delivery.setDeliveryDate(rs.getDate("delivery_date"));
                    delivery.setDeliveryStatus(rs.getString("delivery_status"));
                    delivery.setDeliveryCost(rs.getDouble("delivery_cost"));
                    return delivery;
                } else {
                    throw new SQLException("Delivery not found with ID: " + deliveryID);
                }
            }
        }
    }


    public void updateDelivery(Delivery delivery) throws SQLException {
        String sql = "UPDATE Delivery SET delivery_status = ?, delivery_cost = ? WHERE delivery_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, delivery.getDeliveryStatus());
            pstmt.setDouble(2, calculateDeliveryCost(delivery.getParcelID()));
            pstmt.setInt(3, delivery.getDeliveryID());
            pstmt.executeUpdate();
        }
    }

    public void deleteDelivery(int deliveryID) throws SQLException {
        String sql = "DELETE FROM Delivery WHERE delivery_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, deliveryID);
            pstmt.executeUpdate();
        }
    }
}
